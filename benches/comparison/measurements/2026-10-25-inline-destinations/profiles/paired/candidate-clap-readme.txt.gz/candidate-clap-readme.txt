Analysis of sampling candidate (pid 19465) every 1 millisecond
Process:         candidate [19465]
Path:            /private/tmp/*/candidate
Load Address:    0x1040c4000
Identifier:      candidate
Version:         0
Code Type:       ARM64
Platform:        macOS
Parent Process:  python3.13 [19421]
Target Type:     live task

Date/Time:       2026-10-25 11:34:48.460 +1300
Launch Time:     2026-10-25 11:34:47.924 +1300
OS Version:      macOS 27.0.1 (26A434)
Report Version:  7
Analysis Tool:   /usr/bin/sample

Physical footprint:         2080K
Physical footprint (peak):  2080K
Idle exit:                  untracked
----

Call graph:
    2433 Thread_43564746   DispatchQueue_1: com.apple.main-thread  (serial)
      2433 start  (in dyld) + 6688  [0x1842f7e80]
        2433 main  (in candidate) + 52  [0x1040e7c20]
          2433 _RNvNtCs1coMeGJvsuS_3std2rt19lang_start_internal  (in candidate) + 936  [0x1041d6130]
            2433 _RNCINvNtCs1coMeGJvsuS_3std2rt10lang_startuE0CseVgRDH8534i_19markdown_comparison  (in candidate) + 16  [0x1040fa6d4]
              2433 _RINvNtNtCs1coMeGJvsuS_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECseVgRDH8534i_19markdown_comparison  (in candidate) + 12  [0x1040fb000]
                2416 _RNvCseVgRDH8534i_19markdown_comparison4main  (in candidate) + 1380  [0x1040e6264]
                + 2414 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in candidate) + 9268  [0x1040e52ac]
                + ! 1823 _RNvCs8seiryzelau_13core_markdown20to_html_with_options  (in candidate) + 216  [0x1041ab894]
                + ! : 594 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 8228,6808,...  [0x1041869ac,0x104186420,...]
                + ! : 473 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 6348  [0x104186254]
                + ! : | 226 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in candidate) + 1240,4688,...  [0x104179e40,0x10417abb8,...]
                + ! : | 64 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in candidate) + 6556  [0x10417b304]
                + ! : | + 63 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in candidate) + 60  [0x1041f9184]
                + ! : | + ! 62 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 92  [0x1041f94c4]
                + ! : | + ! : 57 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | + ! : | 56 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | + ! : | + 31 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | + ! : | + ! 23 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | + ! : | + ! : 22 mach_absolute_time  (in libsystem_kernel.dylib) + 108,112,...  [0x1846890f8,0x1846890fc,...]
                + ! : | + ! : | + ! : 1 DYLD-STUB$$mach_absolute_time  (in libsystem_malloc.dylib) + 12  [0x18450a8ac]
                + ! : | + ! : | + ! 6 _xzm_free  (in libsystem_malloc.dylib) + 564,284,...  [0x1844ec934,0x1844ec81c,...]
                + ! : | + ! : | + ! 2 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 172,280  [0x1844ed730,0x1844ed79c]
                + ! : | + ! : | + 14 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | + ! : | + ! 14 _platform_memmove  (in libsystem_platform.dylib) + 180,204  [0x1846d7e14,0x1846d7e2c]
                + ! : | + ! : | + 6 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 400,24,...  [0x1844e51a0,0x1844e5028,...]
                + ! : | + ! : | + 5 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | + ! : | +   4 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 88,256,...  [0x1844e8aa4,0x1844e8b4c,...]
                + ! : | + ! : | +   1 _xzm_malloc  (in libsystem_malloc.dylib) + 512  [0x1844e7ff4]
                + ! : | + ! : | 1 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 124  [0x1844f4b14]
                + ! : | + ! : 3 _realloc  (in libsystem_malloc.dylib) + 20,248,...  [0x1844f51a4,0x1844f5288,...]
                + ! : | + ! : 2 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | + ! :   2 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 136,200  [0x1844e438c,0x1844e43cc]
                + ! : | + ! 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 68  [0x1041f94ac]
                + ! : | + 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 168  [0x1041f9510]
                + ! : | 57 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in candidate) + 3932  [0x10417a8c4]
                + ! : | + 57 _RNvNtCs8seiryzelau_13core_markdown13inline_parser8resource  (in candidate) + 568,660,...  [0x104184500,0x10418455c,...]
                + ! : | 39 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in candidate) + 3972  [0x10417a8ec]
                + ! : | + 34 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser4LinkE8grow_oneBQ_  (in candidate) + 60  [0x1041f924c]
                + ! : | + ! 29 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 92  [0x1041f94c4]
                + ! : | + ! : 23 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | + ! : | 21 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | + ! : | + 10 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | + ! : | + ! 7 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | + ! : | + ! : 6 mach_absolute_time  (in libsystem_kernel.dylib) + 108,112  [0x1846890f8,0x1846890fc]
                + ! : | + ! : | + ! : 1 DYLD-STUB$$mach_absolute_time  (in libsystem_malloc.dylib) + 12  [0x18450a8ac]
                + ! : | + ! : | + ! 3 _xzm_free  (in libsystem_malloc.dylib) + 80,284,...  [0x1844ec750,0x1844ec81c,...]
                + ! : | + ! : | + 5 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 236,248,...  [0x1844e50fc,0x1844e5108,...]
                + ! : | + ! : | + 4 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | + ! : | + ! 3 _platform_memmove  (in libsystem_platform.dylib) + 36,180,...  [0x1846d7d84,0x1846d7e14,...]
                + ! : | + ! : | + ! 1 DYLD-STUB$$_platform_memmove  (in libsystem_malloc.dylib) + 12  [0x18450a5ac]
                + ! : | + ! : | + 1 _xzm_free  (in libsystem_malloc.dylib) + 1836  [0x1844ece2c]
                + ! : | + ! : | + 1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | + ! : | +   1 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 256  [0x1844e8b4c]
                + ! : | + ! : | 2 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 48,144  [0x1844f4ac8,0x1844f4b28]
                + ! : | + ! : 3 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | + ! : | 3 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 0,268,...  [0x1844e4304,0x1844e4410,...]
                + ! : | + ! : 1 DYLD-STUB$$realloc  (in candidate) + 4  [0x1041ff398]
                + ! : | + ! : 1 _RNvCsjVqd8RsBhQu_7___rustc13___rdl_realloc  (in candidate) + 0  [0x1041c8c28]
                + ! : | + ! : 1 _realloc  (in libsystem_malloc.dylib) + 36  [0x1844f51b4]
                + ! : | + ! 2 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 120  [0x1041f94e0]
                + ! : | + ! : 1 _malloc_zone_malloc  (in libsystem_malloc.dylib) + 80  [0x1844f4540]
                + ! : | + ! : 1 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 192  [0x1844efa50]
                + ! : | + ! 2 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 36,40  [0x1041f948c,0x1041f9490]
                + ! : | + ! 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 108  [0x1041f94d4]
                + ! : | + !   1 _RNvCsjVqd8RsBhQu_7___rustc35___rust_no_alloc_shim_is_unstable_v2  (in candidate) + 0  [0x1040fe1f8]
                + ! : | + 3 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser4LinkE8grow_oneBQ_  (in candidate) + 68,60  [0x1041f9254,0x1041f924c]
                + ! : | + 2 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 168  [0x1041f9510]
                + ! : | 33 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in candidate) + 9612  [0x10417bef4]
                + ! : | + 16 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_EB7_  (in candidate) + 32,0,...  [0x104181748,0x104181728,...]
                + ! : | + 14 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_EB7_  (in candidate) + 848  [0x104181a78]
                + ! : | + ! 14 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in candidate) + 60  [0x1041f9184]
                + ! : | + !   13 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 92  [0x1041f94c4]
                + ! : | + !   : 11 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | + !   : | 8 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | + !   : | + 3 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | + !   : | + ! 2 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 268,640  [0x1844e8b58,0x1844e8ccc]
                + ! : | + !   : | + ! 1 _xzm_malloc  (in libsystem_malloc.dylib) + 108  [0x1844e7e60]
                + ! : | + !   : | + 2 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | + !   : | + ! 2 _xzm_free  (in libsystem_malloc.dylib) + 364,744  [0x1844ec86c,0x1844ec9e8]
                + ! : | + !   : | + 2 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 400,904  [0x1844e51a0,0x1844e5398]
                + ! : | + !   : | + 1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | + !   : | +   1 _platform_memmove  (in libsystem_platform.dylib) + 180  [0x1846d7e14]
                + ! : | + !   : | 3 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 48,124,...  [0x1844f4ac8,0x1844f4b14,...]
                + ! : | + !   : 2 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | + !   :   2 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 92,268  [0x1844e4360,0x1844e4410]
                + ! : | + !   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 36  [0x1041f948c]
                + ! : | + 3 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_EB7_  (in candidate) + 1384  [0x104181c90]
                + ! : | +   3 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown8document6NodeIdE8grow_oneBQ_  (in candidate) + 60  [0x1041f9440]
                + ! : | +     2 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 108  [0x1041f94d4]
                + ! : | +     : 2 _RNvCsjVqd8RsBhQu_7___rustc35___rust_no_alloc_shim_is_unstable_v2  (in candidate) + 0  [0x1040fe1f8]
                + ! : | +     1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 120  [0x1041f94e0]
                + ! : | +       1 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 144  [0x1844efa20]
                + ! : | 21 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in candidate) + 7692  [0x10417b774]
                + ! : | + 21 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in candidate) + 60  [0x1041f9184]
                + ! : | +   21 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 92  [0x1041f94c4]
                + ! : | +     18 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | +     ! 16 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | +     ! : 8 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | +     ! : | 6 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | +     ! : | + 6 mach_absolute_time  (in libsystem_kernel.dylib) + 108,16,...  [0x1846890f8,0x18468909c,...]
                + ! : | +     ! : | 2 _xzm_free  (in libsystem_malloc.dylib) + 28,348  [0x1844ec71c,0x1844ec85c]
                + ! : | +     ! : 4 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | +     ! : | 3 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 88,244,...  [0x1844e8aa4,0x1844e8b40,...]
                + ! : | +     ! : | 1 _xzm_malloc  (in libsystem_malloc.dylib) + 0  [0x1844e7df4]
                + ! : | +     ! : 4 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | +     ! :   4 _platform_memmove  (in libsystem_platform.dylib) + 180  [0x1846d7e14]
                + ! : | +     ! 2 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 24,48  [0x1844f4ab0,0x1844f4ac8]
                + ! : | +     2 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | +     ! 2 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 460,496  [0x1844e44d0,0x1844e44f4]
                + ! : | +     1 _realloc  (in libsystem_malloc.dylib) + 20  [0x1844f51a4]
                + ! : | 9 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_EB7_  (in candidate) + 1464  [0x104181ce0]
                + ! : | 7 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in candidate) + 1280  [0x104179e68]
                + ! : | + 7 _RNvNtNtCs8seiryzelau_13core_markdown13inline_parser8autolink3web  (in candidate) + 0,24,...  [0x1041b3160,0x1041b3178,...]
                + ! : | 5 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in candidate) + 4052  [0x10417a93c]
                + ! : | + 5 _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser18suppress_autolinks  (in candidate) + 40,0,...  [0x10418356c,0x104183544,...]
                + ! : | 4 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in candidate) + 6184  [0x10417b190]
                + ! : | + 4 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser9DelimiterE8grow_oneBQ_  (in candidate) + 60  [0x1041f9378]
                + ! : | +   3 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 120  [0x1041f94e0]
                + ! : | +   ! 1 _RNvCsjVqd8RsBhQu_7___rustc11___rdl_alloc  (in candidate) + 0  [0x1041c8bb0]
                + ! : | +   ! 1 _malloc_zone_malloc  (in libsystem_malloc.dylib) + 120  [0x1844f4568]
                + ! : | +   ! 1 xzm_malloc_zone_malloc_type_malloc_tc  (in libsystem_malloc.dylib) + 0  [0x1844ef3cc]
                + ! : | +   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 108  [0x1041f94d4]
                + ! : | +     1 _RNvCsjVqd8RsBhQu_7___rustc35___rust_no_alloc_shim_is_unstable_v2  (in candidate) + 0  [0x1040fe1f8]
                + ! : | 4 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in candidate) + 6656  [0x10417b368]
                + ! : | + 3 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser4TickE8grow_oneBQ_  (in candidate) + 60  [0x1041f92b0]
                + ! : | + ! 2 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 120  [0x1041f94e0]
                + ! : | + ! : 2 _malloc_zone_malloc  (in libsystem_malloc.dylib) + 12  [0x1844f44fc]
                + ! : | + ! 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 36  [0x1041f948c]
                + ! : | + 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 168  [0x1041f9510]
                + ! : | 2 _RNvNtNtCs8seiryzelau_13core_markdown13inline_parser8autolink3web  (in candidate) + 1928  [0x1041b38e8]
                + ! : | 1 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in candidate) + 120  [0x1041799e0]
                + ! : | + 1 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in candidate) + 60  [0x1041f9184]
                + ! : | +   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 120  [0x1041f94e0]
                + ! : | +     1 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 0  [0x1844ef990]
                + ! : | 1 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in candidate) + 4028  [0x10417a924]
                + ! : |   1 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_EB7_  (in candidate) + 20  [0x10418173c]
                + ! : 175 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 22720  [0x10418a248]
                + ! : | 116 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in candidate) + 844,836,...  [0x1041aa02c,0x1041aa024,...]
                + ! : | 47 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in candidate) + 2556  [0x1041aa6dc]
                + ! : | + 47 _RINvNvMs2_NtCs3vUkWdPtNor_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs8seiryzelau_13core_markdown  (in candidate) + 108  [0x1041f902c]
                + ! : | +   47 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 92  [0x1041f94c4]
                + ! : | +     46 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | +     ! 43 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | +     ! : 22 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | +     ! : | 19 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | +     ! : | + 19 mach_absolute_time  (in libsystem_kernel.dylib) + 108,16  [0x1846890f8,0x18468909c]
                + ! : | +     ! : | 2 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 28,56  [0x1844ed6a0,0x1844ed6bc]
                + ! : | +     ! : | 1 _xzm_free  (in libsystem_malloc.dylib) + 28  [0x1844ec71c]
                + ! : | +     ! : 13 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | +     ! : | 13 _platform_memmove  (in libsystem_platform.dylib) + 180,204  [0x1846d7e14,0x1846d7e2c]
                + ! : | +     ! : 7 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | +     ! : | 6 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 404,524,...  [0x1844e8be0,0x1844e8c58,...]
                + ! : | +     ! : | 1 _xzm_malloc  (in libsystem_malloc.dylib) + 108  [0x1844e7e60]
                + ! : | +     ! : 1 _xzm_free  (in libsystem_malloc.dylib) + 972  [0x1844ecacc]
                + ! : | +     ! 3 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 124,48  [0x1844f4b14,0x1844f4ac8]
                + ! : | +     1 DYLD-STUB$$realloc  (in candidate) + 4  [0x1041ff398]
                + ! : | 10 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in candidate) + 2364  [0x1041aa61c]
                + ! : | + 9 _platform_memmove  (in libsystem_platform.dylib) + 452,428,...  [0x1846d7f24,0x1846d7f0c,...]
                + ! : | + 1 DYLD-STUB$$memcpy  (in candidate) + 4  [0x1041ff26c]
                + ! : | 2 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in candidate) + 1400  [0x1041aa258]
                + ! : |   2 _platform_memmove  (in libsystem_platform.dylib) + 136,204  [0x1846d7de8,0x1846d7e2c]
                + ! : 104 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 23128  [0x10418a3e0]
                + ! : | 92 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in candidate) + 836,844,...  [0x1041aa024,0x1041aa02c,...]
                + ! : | 12 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in candidate) + 2364  [0x1041aa61c]
                + ! : |   11 _platform_memmove  (in libsystem_platform.dylib) + 452,12,...  [0x1846d7f24,0x1846d7d6c,...]
                + ! : |   1 DYLD-STUB$$memcpy  (in candidate) + 4  [0x1041ff26c]
                + ! : 103 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 12852  [0x104187bbc]
                + ! : | 63 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in candidate) + 232,352,...  [0x10418e3cc,0x10418e444,...]
                + ! : | 40 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in candidate) + 652  [0x10418e570]
                + ! : |   35 _platform_memmove  (in libsystem_platform.dylib) + 452,428,...  [0x1846d7f24,0x1846d7f0c,...]
                + ! : |   5 DYLD-STUB$$memcpy  (in candidate) + 4  [0x1041ff26c]
                + ! : 98 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 1768  [0x104185070]
                + ! : | 73 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in candidate) + 320,228,...  [0x1041aed40,0x1041aece4,...]
                + ! : | 19 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in candidate) + 1100  [0x1041af04c]
                + ! : | + 19 _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in candidate) + 304,0,...  [0x1041ae7fc,0x1041ae6cc,...]
                + ! : | 4 _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in candidate) + 828,832  [0x1041aea08,0x1041aea0c]
                + ! : | 2 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in candidate) + 588  [0x1041aee4c]
                + ! : |   2 _RNvNtNtCs8seiryzelau_13core_markdown4util19character_reference4scan  (in candidate) + 136,500  [0x1041b6dfc,0x1041b6f68]
                + ! : 67 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 24752  [0x10418aa38]
                + ! : | 67 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown6stream9EventKindEBF_  (in candidate) + 36,0,...  [0x10418e08c,0x10418e068,...]
                + ! : 38 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 34868  [0x10418d1bc]
                + ! : | 20 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown12event_parser11EventParserEBF_  (in candidate) + 52  [0x10418dc70]
                + ! : | + 15 _xzm_xzone_free_freelist  (in libsystem_malloc.dylib) + 720  [0x1844edef8]
                + ! : | + ! 13 mach_absolute_time  (in libsystem_kernel.dylib) + 108,16  [0x1846890f8,0x18468909c]
                + ! : | + ! 2 DYLD-STUB$$mach_absolute_time  (in libsystem_malloc.dylib) + 12  [0x18450a8ac]
                + ! : | + 3 _xzm_xzone_free_freelist  (in libsystem_malloc.dylib) + 128,376,...  [0x1844edca8,0x1844edda0,...]
                + ! : | + 2 _free  (in libsystem_malloc.dylib) + 36  [0x1844f5134]
                + ! : | 9 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown13inline_parser12InlineParserEBF_  (in candidate) + 148  [0x10418deb8]
                + ! : | + 4 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | + ! 4 mach_absolute_time  (in libsystem_kernel.dylib) + 108,112  [0x1846890f8,0x1846890fc]
                + ! : | + 2 _free  (in libsystem_malloc.dylib) + 0,76  [0x1844f5110,0x1844f515c]
                + ! : | + 2 _xzm_free_tc  (in libsystem_malloc.dylib) + 260  [0x1844f197c]
                + ! : | + 1 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 124  [0x1844ed700]
                + ! : | 6 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown13inline_parser12InlineParserEBF_  (in candidate) + 44  [0x10418de50]
                + ! : | + 3 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | + ! 3 mach_absolute_time  (in libsystem_kernel.dylib) + 108  [0x1846890f8]
                + ! : | + 2 _xzm_free_tc  (in libsystem_malloc.dylib) + 40,156  [0x1844f18a0,0x1844f1914]
                + ! : | + 1 _free  (in libsystem_malloc.dylib) + 56  [0x1844f5148]
                + ! : | 1 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown12event_parser11EventParserEBF_  (in candidate) + 80  [0x10418dc8c]
                + ! : | + 1 _xzm_free_tc  (in libsystem_malloc.dylib) + 156  [0x1844f1914]
                + ! : | 1 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown12event_parser11EventParserEBF_  (in candidate) + 24  [0x10418dc54]
                + ! : | 1 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown13inline_parser12InlineParserEBF_  (in candidate) + 68  [0x10418de68]
                + ! : |   1 _xzm_free_tc  (in libsystem_malloc.dylib) + 204  [0x1844f1944]
                + ! : 27 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 11536  [0x104187698]
                + ! : | 13 _RINvNtNtCs8seiryzelau_13core_markdown4util9tagfilter14write_filteredNtNtB6_6stream11StreamErrorNCINvMNtB6_19event_html_rendererINtB1B_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9event_refKb0_E0EB6_  (in candidate) + 3292  [0x1041b2bbc]
                + ! : | + 7 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in candidate) + 652  [0x10418e570]
                + ! : | + ! 5 _platform_memmove  (in libsystem_platform.dylib) + 420,0,...  [0x1846d7f04,0x1846d7d60,...]
                + ! : | + ! 2 DYLD-STUB$$memcpy  (in candidate) + 4  [0x1041ff26c]
                + ! : | + 6 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in candidate) + 664,12,...  [0x10418e57c,0x10418e2f0,...]
                + ! : | 13 _RINvNtNtCs8seiryzelau_13core_markdown4util9tagfilter14write_filteredNtNtB6_6stream11StreamErrorNCINvMNtB6_19event_html_rendererINtB1B_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9event_refKb0_E0EB6_  (in candidate) + 432,116,...  [0x1041b2090,0x1041b1f54,...]
                + ! : | 1 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in candidate) + 732  [0x10418e5c0]
                + ! : 25 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in candidate) + 732,736  [0x10418e5c0,0x10418e5c4]
                + ! : 23 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown6stream9EventKindEBF_  (in candidate) + 96  [0x10418e0c8]
                + ! : 17 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 23688  [0x10418a610]
                + ! : | 16 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser9DelimiterE8grow_oneBQ_  (in candidate) + 60  [0x1041f9378]
                + ! : | + 14 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 92  [0x1041f94c4]
                + ! : | + ! 11 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | + ! : 8 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | + ! : | 5 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | + ! : | + 5 _xzm_free  (in libsystem_malloc.dylib) + 348,404,...  [0x1844ec85c,0x1844ec894,...]
                + ! : | + ! : | 1 default_zone_realloc  (in libsystem_malloc.dylib) + 4  [0x1844b8cfc]
                + ! : | + ! : | 1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | + ! : | + 1 _xzm_malloc  (in libsystem_malloc.dylib) + 108  [0x1844e7e60]
                + ! : | + ! : | 1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 296  [0x1844e5138]
                + ! : | + ! : 3 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 0,48,...  [0x1844f4a98,0x1844f4ac8,...]
                + ! : | + ! 3 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | + !   3 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 0,460,...  [0x1844e4304,0x1844e44d0,...]
                + ! : | + 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 108  [0x1041f94d4]
                + ! : | + ! 1 _RNvCsjVqd8RsBhQu_7___rustc35___rust_no_alloc_shim_is_unstable_v2  (in candidate) + 0  [0x1040fe1f8]
                + ! : | + 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 120  [0x1041f94e0]
                + ! : | +   1 DYLD-STUB$$malloc  (in candidate) + 4  [0x1041ff254]
                + ! : | 1 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser9DelimiterE8grow_oneBQ_  (in candidate) + 60  [0x1041f9378]
                + ! : 12 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in candidate) + 2300,2292,...  [0x1041aa5dc,0x1041aa5d4,...]
                + ! : 8 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in candidate) + 1168,1176  [0x1041af090,0x1041af098]
                + ! : 7 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 23068  [0x10418a3a4]
                + ! : | 7 _RNvMNtCs8seiryzelau_13core_markdown6streamNtB2_4Text7resolve  (in candidate) + 0,76,...  [0x1041ac3c4,0x1041ac410,...]
                + ! : 6 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 64  [0x1041849c8]
                + ! : | 6 _platform_memmove  (in libsystem_platform.dylib) + 180,144  [0x1846d7e14,0x1846d7df0]
                + ! : 5 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 11904  [0x104187808]
                + ! : | 3 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 11904  [0x104187808]
                + ! : | + 3 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9terminateB4_  (in candidate) + 84,152,...  [0x104191290,0x1041912d4,...]
                + ! : | 2 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9terminateB4_  (in candidate) + 0,336  [0x10419123c,0x10419138c]
                + ! : 4 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 24692  [0x10418a9fc]
                + ! : | 3 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in candidate) + 652  [0x10418e570]
                + ! : | + 2 _platform_memmove  (in libsystem_platform.dylib) + 420,436  [0x1846d7f04,0x1846d7f14]
                + ! : | + 1 DYLD-STUB$$memcpy  (in candidate) + 4  [0x1041ff26c]
                + ! : | 1 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in candidate) + 664  [0x10418e57c]
                + ! : 3 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 5676  [0x104185fb4]
                + ! : | 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser5value  (in candidate) + 0,24  [0x1041aa874,0x1041aa88c]
                + ! : | 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser5value  (in candidate) + 216  [0x1041aa94c]
                + ! : |   1 _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in candidate) + 24  [0x1041ae6e4]
                + ! : 3 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 6020  [0x10418610c]
                + ! : | 2 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in candidate) + 1100  [0x1041af04c]
                + ! : | + 2 _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in candidate) + 0,304  [0x1041ae6cc,0x1041ae7fc]
                + ! : | 1 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in candidate) + 164  [0x1041aeca4]
                + ! : 3 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 22640  [0x10418a1f8]
                + ! : | 3 _RNvMNtCs8seiryzelau_13core_markdown6streamNtB2_4Text7resolve  (in candidate) + 20,76  [0x1041ac3d8,0x1041ac410]
                + ! : 3 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 22656  [0x10418a208]
                + ! : | 3 _RNvMNtCs9nEiEE0E2Vj_4core6resultINtB2_6ResultReNtNtCs8seiryzelau_13core_markdown6stream11StreamErrorE6expectBN_  (in candidate) + 12,32  [0x104191410,0x104191424]
                + ! : 3 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 23084  [0x10418a3b4]
                + ! : | 3 _RNvMNtCs9nEiEE0E2Vj_4core6resultINtB2_6ResultReNtNtCs8seiryzelau_13core_markdown6stream11StreamErrorE6expectBN_  (in candidate) + 12,32  [0x104191410,0x104191424]
                + ! : 3 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 24476  [0x10418a924]
                + ! : | 2 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in candidate) + 196,232  [0x10418e3a8,0x10418e3cc]
                + ! : | 1 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in candidate) + 652  [0x10418e570]
                + ! : |   1 _platform_memmove  (in libsystem_platform.dylib) + 452  [0x1846d7f24]
                + ! : 3 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 25588  [0x10418ad7c]
                + ! : | 3 _platform_memmove  (in libsystem_platform.dylib) + 444,428  [0x1846d7f1c,0x1846d7f0c]
                + ! : 2 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 5960  [0x1041860d0]
                + ! : | 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser5value  (in candidate) + 216  [0x1041aa94c]
                + ! : |   2 _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in candidate) + 304,324  [0x1041ae7fc,0x1041ae810]
                + ! : 2 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 12404  [0x1041879fc]
                + ! : | 2 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9terminateB4_  (in candidate) + 0,8  [0x10419123c,0x104191244]
                + ! : 2 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 13596  [0x104187ea4]
                + ! : | 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 13596  [0x104187ea4]
                + ! : | + 1 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9terminateB4_  (in candidate) + 84  [0x104191290]
                + ! : | 1 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9terminateB4_  (in candidate) + 288  [0x10419135c]
                + ! : |   1 _platform_memmove  (in libsystem_platform.dylib) + 428  [0x1846d7f0c]
                + ! : 2 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 25796  [0x10418ae4c]
                + ! : | 2 _platform_memmove  (in libsystem_platform.dylib) + 452  [0x1846d7f24]
                + ! : 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser17document_boundary  (in candidate) + 172  [0x1041f95c4]
                + ! : 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 4480  [0x104185b08]
                + ! : | 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser17document_boundary  (in candidate) + 68  [0x1041f955c]
                + ! : 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 7776  [0x1041867e8]
                + ! : | 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser9separator  (in candidate) + 36  [0x1041aaa70]
                + ! : 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate) + 9096  [0x104186d10]
                + ! : | 1 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9footnotesB4_  (in candidate) + 36  [0x10418e7f0]
                + ! : 1 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in candidate) + 9744  [0x10417bf78]
                + ! : 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser5value  (in candidate) + 304  [0x1041aa9a4]
                + ! : 1 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser9DelimiterE8grow_oneBQ_  (in candidate) + 80  [0x1041f938c]
                + ! 588 _RNvCs8seiryzelau_13core_markdown20to_html_with_options  (in candidate) + 200  [0x1041ab884]
                + ! : 587 _RNvMNtCs8seiryzelau_13core_markdown12event_parserNtB2_11EventParser7prepare  (in candidate) + 44  [0x1041aa75c]
                + ! : | 158 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 1168,1000,...  [0x1041975c8,0x104197520,...]
                + ! : | 78 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 6664  [0x104198b40]
                + ! : | + 71 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in candidate) + 76  [0x1041966a8]
                + ! : | + ! 71 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4NodeE8grow_oneBQ_  (in candidate) + 60  [0x1041f91e8]
                + ! : | + !   70 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 92  [0x1041f94c4]
                + ! : | + !   : 66 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | + !   : | 65 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | + !   : | + 29 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | + !   : | + ! 23 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | + !   : | + ! : 23 mach_absolute_time  (in libsystem_kernel.dylib) + 108,16,...  [0x1846890f8,0x18468909c,...]
                + ! : | + !   : | + ! 3 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 96,128,...  [0x1844ed6e4,0x1844ed704,...]
                + ! : | + !   : | + ! 3 _xzm_free  (in libsystem_malloc.dylib) + 848,348  [0x1844eca50,0x1844ec85c]
                + ! : | + !   : | + 23 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | + !   : | + ! 23 _platform_memmove  (in libsystem_platform.dylib) + 180,0  [0x1846d7e14,0x1846d7d60]
                + ! : | + !   : | + 8 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | + !   : | + ! 6 _xzm_malloc  (in libsystem_malloc.dylib) + 0,492,...  [0x1844e7df4,0x1844e7fe0,...]
                + ! : | + !   : | + ! 2 _xzm_xzone_malloc_small_freelist  (in libsystem_malloc.dylib) + 868  [0x1844e91b0]
                + ! : | + !   : | + 3 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 248,376  [0x1844e5108,0x1844e5188]
                + ! : | + !   : | + 2 _xzm_free  (in libsystem_malloc.dylib) + 960,972  [0x1844ecac0,0x1844ecacc]
                + ! : | + !   : | 1 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 124  [0x1844f4b14]
                + ! : | + !   : 2 _realloc  (in libsystem_malloc.dylib) + 20,228  [0x1844f51a4,0x1844f5274]
                + ! : | + !   : 1 DYLD-STUB$$realloc  (in candidate) + 4  [0x1041ff398]
                + ! : | + !   : 1 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | + !   :   1 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 116  [0x1844e4378]
                + ! : | + !   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 40  [0x1041f9490]
                + ! : | + 7 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in candidate) + 116,20,...  [0x1041966d0,0x104196670,...]
                + ! : | 41 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 6048  [0x1041988d8]
                + ! : | + 37 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10table_head  (in candidate) + 36  [0x104195c64]
                + ! : | + ! 12 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in candidate) + 72  [0x1041961a8]
                + ! : | + ! : 12 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in candidate) + 272,180,...  [0x1041b1514,0x1041b14b8,...]
                + ! : | + ! 12 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in candidate) + 40,112,...  [0x104196188,0x1041961d0,...]
                + ! : | + ! 6 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in candidate) + 112  [0x1041961d0]
                + ! : | + ! : 6 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in candidate) + 12,136,...  [0x1041956c4,0x104195740,...]
                + ! : | + ! 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in candidate) + 644  [0x10419593c]
                + ! : | + ! 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in candidate) + 400  [0x1041962f0]
                + ! : | + !   2 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in candidate) + 64,172  [0x1041b0b30,0x1041b0b9c]
                + ! : | + !   1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in candidate) + 492  [0x1041b0cdc]
                + ! : | + !     1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in candidate) + 8  [0x1041b0990]
                + ! : | + 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in candidate) + 436,428  [0x104196314,0x10419630c]
                + ! : | 38 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 8428  [0x104199224]
                + ! : | + 32 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser4htmlNtB2_4Html6closed  (in candidate) + 1476  [0x1041a3ba0]
                + ! : | + ! 30 _RNvNtCsglYb6d7nGNF_6memchr6memmem4find  (in candidate) + 184,252,...  [0x1041a3ff8,0x1041a403c,...]
                + ! : | + ! 2 _RNvNtCsglYb6d7nGNF_6memchr6memmem4find  (in candidate) + 232  [0x1041a4028]
                + ! : | + !   2 _RNvNtNtNtCsglYb6d7nGNF_6memchr4arch3all9rabinkarp12is_equal_raw  (in candidate) + 0,72  [0x1041fa554,0x1041fa59c]
                + ! : | + 3 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser4htmlNtB2_4Html6closed  (in candidate) + 0,1748  [0x1041a35dc,0x1041a3cb0]
                + ! : | + 3 _RNvNtCsglYb6d7nGNF_6memchr6memmem4find  (in candidate) + 764  [0x1041a423c]
                + ! : | 33 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 4640  [0x104198358]
                + ! : | + 20 _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in candidate) + 1024,432,...  [0x1041b50b0,0x1041b4e60,...]
                + ! : | + 13 _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in candidate) + 64  [0x1041b4cf0]
                + ! : | +   12 _RNvXNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fnINtB2_6FromFnNCNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB17_7Builder20definition_fragments0ENtNtNtB6_6traits8iterator8Iterator4nextB19_  (in candidate) + 280  [0x1041b8178]
                + ! : | +   : 12 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in candidate) + 280,120,...  [0x1041b151c,0x1041b147c,...]
                + ! : | +   1 _RNvXNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fnINtB2_6FromFnNCNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB17_7Builder20definition_fragments0ENtNtNtB6_6traits8iterator8Iterator4nextB19_  (in candidate) + 56  [0x1041b8098]
                + ! : | 25 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 656  [0x1041973c8]
                + ! : | + 25 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in candidate) + 68,0,...  [0x1041956fc,0x1041956b8,...]
                + ! : | 24 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 6620  [0x104198b14]
                + ! : | + 24 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in candidate) + 272,424,...  [0x1041b1514,0x1041b15ac,...]
                + ! : | 22 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 7124  [0x104198d0c]
                + ! : | + 13 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in candidate) + 72  [0x1041961a8]
                + ! : | + ! 13 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in candidate) + 272,120,...  [0x1041b1514,0x1041b147c,...]
                + ! : | + 5 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in candidate) + 112  [0x1041961d0]
                + ! : | + ! 5 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in candidate) + 12,68,...  [0x1041956c4,0x1041956fc,...]
                + ! : | + 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in candidate) + 72,192  [0x1041961a8,0x104196220]
                + ! : | + 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in candidate) + 400  [0x1041962f0]
                + ! : | +   1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in candidate) + 0  [0x1041b0af0]
                + ! : | 18 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 6712  [0x104198b70]
                + ! : | + 18 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in candidate) + 68,12,...  [0x1041956fc,0x1041956c4,...]
                + ! : | 16 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in candidate) + 192,196,...  [0x10419671c,0x104196720,...]
                + ! : | 14 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 5068  [0x104198504]
                + ! : | + 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in candidate) + 564  [0x104196980]
                + ! : | + ! 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in candidate) + 72,136  [0x104195700,0x104195740]
                + ! : | + 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in candidate) + 948  [0x104196b00]
                + ! : | + ! 3 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners23scan_closing_code_fence  (in candidate) + 20,48  [0x1041b18a0,0x1041b18bc]
                + ! : | + 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in candidate) + 276  [0x104196860]
                + ! : | + ! 2 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in candidate) + 60  [0x1041f9184]
                + ! : | + !   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 120  [0x1041f94e0]
                + ! : | + !   : 1 _malloc_zone_malloc  (in libsystem_malloc.dylib) + 44  [0x1844f451c]
                + ! : | + !   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 4  [0x1041f946c]
                + ! : | + 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in candidate) + 376  [0x1041968c4]
                + ! : | + ! 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in candidate) + 20  [0x104196670]
                + ! : | + 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in candidate) + 1384,1488  [0x104196cb4,0x104196d1c]
                + ! : | + 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in candidate) + 144  [0x1041967dc]
                + ! : | + ! 1 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in candidate) + 156  [0x1041b14a0]
                + ! : | + 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in candidate) + 972  [0x104196b18]
                + ! : | +   1 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in candidate) + 424  [0x1041b15ac]
                + ! : | 13 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 8160  [0x104199118]
                + ! : | + 13 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in candidate) + 460,0,...  [0x1041b15d0,0x1041b1404,...]
                + ! : | 12 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 8468  [0x10419924c]
                + ! : | + 12 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in candidate) + 136,12,...  [0x104195740,0x1041956c4,...]
                + ! : | 11 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 9276  [0x104199574]
                + ! : | + 11 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown8document6NodeIdE8grow_oneBQ_  (in candidate) + 60  [0x1041f9440]
                + ! : | +   11 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 92  [0x1041f94c4]
                + ! : | +     10 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | +     ! 10 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | +     !   5 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 248,332,...  [0x1844e5108,0x1844e515c,...]
                + ! : | +     !   3 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | +     !   : 3 _xzm_malloc  (in libsystem_malloc.dylib) + 0,108,...  [0x1844e7df4,0x1844e7e60,...]
                + ! : | +     !   1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | +     !   : 1 _platform_memmove  (in libsystem_platform.dylib) + 460  [0x1846d7f2c]
                + ! : | +     !   1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | +     !     1 _xzm_free  (in libsystem_malloc.dylib) + 80  [0x1844ec750]
                + ! : | +     1 _RNvCsjVqd8RsBhQu_7___rustc13___rdl_realloc  (in candidate) + 0  [0x1041c8c28]
                + ! : | 8 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 6488  [0x104198a90]
                + ! : | + 8 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in candidate) + 24,244,...  [0x104195f08,0x104195fe4,...]
                + ! : | 8 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 6516  [0x104198aac]
                + ! : | + 8 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in candidate) + 20,0,...  [0x104196670,0x10419665c,...]
                + ! : | 7 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in candidate) + 644,648  [0x10419593c,0x104195940]
                + ! : | 7 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 7224  [0x104198d70]
                + ! : | + 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10interrupts  (in candidate) + 348,416,...  [0x104195acc,0x104195b10,...]
                + ! : | + 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15list_interrupts  (in candidate) + 72  [0x10419607c]
                + ! : | + ! 2 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in candidate) + 52,148  [0x1041b0b24,0x1041b0b84]
                + ! : | + ! 1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in candidate) + 492  [0x1041b0cdc]
                + ! : | + !   1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in candidate) + 180  [0x1041b0a3c]
                + ! : | + 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15list_interrupts  (in candidate) + 196  [0x1041960f8]
                + ! : | 6 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 9244  [0x104199554]
                + ! : | + 6 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in candidate) + 116,20,...  [0x1041966d0,0x104196670,...]
                + ! : | 5 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 7264  [0x104198d98]
                + ! : | + 5 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10interrupts  (in candidate) + 4,20,...  [0x104195974,0x104195984,...]
                + ! : | 4 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 128  [0x1041971b8]
                + ! : | + 3 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 92,248,...  [0x1844ef9ec,0x1844efa88,...]
                + ! : | + 1 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 520  [0x1844e8c54]
                + ! : | 4 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 10328  [0x104199990]
                + ! : | + 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_html  (in candidate) + 12,184  [0x104195de0,0x104195e8c]
                + ! : | 3 _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in candidate) + 3208,3196  [0x1041b5938,0x1041b592c]
                + ! : | 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10table_head  (in candidate) + 356  [0x104195da4]
                + ! : | 3 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 1820  [0x104197854]
                + ! : | + 3 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in candidate) + 20,128,...  [0x1041b0b04,0x1041b0b70,...]
                + ! : | 3 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 5692  [0x104198774]
                + ! : | + 3 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in candidate) + 0,88,...  [0x1041b1404,0x1041b145c,...]
                + ! : | 3 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 7196  [0x104198d54]
                + ! : | + 3 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners19scan_setext_heading  (in candidate) + 112,228,...  [0x1041b179c,0x1041b1810,...]
                + ! : | 3 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 7308  [0x104198dc4]
                + ! : | + 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15list_interrupts  (in candidate) + 72  [0x10419607c]
                + ! : | +   2 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in candidate) + 492  [0x1041b0cdc]
                + ! : | +   ! 2 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in candidate) + 8,132  [0x1041b0990,0x1041b0a0c]
                + ! : | +   1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in candidate) + 32  [0x1041b0b10]
                + ! : | 2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 5016  [0x1041984d0]
                + ! : | + 2 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners15scan_code_fence  (in candidate) + 44  [0x1041b1628]
                + ! : | 2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 5352  [0x104198620]
                + ! : | + 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in candidate) + 148,244  [0x104195f84,0x104195fe4]
                + ! : | 2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 5660  [0x104198754]
                + ! : | + 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in candidate) + 24  [0x104195f08]
                + ! : | 2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 8384  [0x1041991f8]
                + ! : | + 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in candidate) + 60,116  [0x104196698,0x1041966d0]
                + ! : | 2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 10484  [0x104199a2c]
                + ! : | + 1 _RINvMs_NtCs3vUkWdPtNor_5alloc3vecINtB5_3VecjE8dedup_byNCNvMNtCs8seiryzelau_13core_markdown11definitionsNtBV_11Definitions6finishs_0EBX_  (in candidate) + 344  [0x1041a7e7c]
                + ! : | + 1 _RNvMNtCs8seiryzelau_13core_markdown11definitionsNtB2_11Definitions6finish  (in candidate) + 32  [0x1041ac140]
                + ! : | 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in candidate) + 1604  [0x104196d90]
                + ! : | 1 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 2568  [0x104197b40]
                + ! : | + 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in candidate) + 244  [0x104195fe4]
                + ! : | 1 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 5044  [0x1041984ec]
                + ! : | + 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in candidate) + 192  [0x104195fb0]
                + ! : | 1 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 5324  [0x104198604]
                + ! : | + 1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser4htmlNtB2_4Html5start  (in candidate) + 64  [0x1041a2ee4]
                + ! : | 1 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 5412  [0x10419865c]
                + ! : | + 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in candidate) + 156  [0x1041966f8]
                + ! : | 1 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 9336  [0x1041995b0]
                + ! : | + 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in candidate) + 60  [0x104196698]
                + ! : | 1 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate) + 10564  [0x104199a7c]
                + ! : |   1 _xzm_free_tc  (in libsystem_malloc.dylib) + 312  [0x1844f19b0]
                + ! : 1 _RNvMNtCs8seiryzelau_13core_markdown12event_parserNtB2_11EventParser7prepare  (in candidate) + 260  [0x1041aa834]
                + ! 2 _RNvCs8seiryzelau_13core_markdown20to_html_with_options  (in candidate) + 72  [0x1041ab804]
                + ! : 1 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 0  [0x1844ef990]
                + ! : 1 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 88  [0x1844e8aa4]
                + ! 1 _RNvCs8seiryzelau_13core_markdown20to_html_with_options  (in candidate) + 224  [0x1041ab89c]
                + !   1 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueINtNtCs8seiryzelau_13core_markdown19event_html_renderer17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringEEBG_  (in candidate) + 48  [0x1041ab188]
                + !     1 _free  (in libsystem_malloc.dylib) + 0  [0x1844f5110]
                + 2 _RNvCseVgRDH8534i_19markdown_comparison4main  (in candidate) + 1400  [0x1040e6278]
                10 _RNvCseVgRDH8534i_19markdown_comparison4main  (in candidate) + 1420  [0x1040e628c]
                + 8 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! 8 mach_absolute_time  (in libsystem_kernel.dylib) + 108,112  [0x1846890f8,0x1846890fc]
                + 1 _free  (in libsystem_malloc.dylib) + 76  [0x1844f515c]
                + 1 _xzm_free_tc  (in libsystem_malloc.dylib) + 0  [0x1844f1878]
                7 _RNvCseVgRDH8534i_19markdown_comparison4main  (in candidate) + 1348  [0x1040e6244]
                  6 _RNvMNtCs1coMeGJvsuS_3std4timeNtB2_7Instant7elapsed  (in candidate) + 28  [0x1041c8e9c]
                  ! 5 _RNvMNtNtNtNtCs1coMeGJvsuS_3std3sys3pal4unix4timeNtB2_8Timespec3now  (in candidate) + 24  [0x1041c97bc]
                  ! : 3 clock_gettime  (in libsystem_c.dylib) + 60  [0x184564100]
                  ! : | 2 clock_gettime_nsec_np  (in libsystem_c.dylib) + 384  [0x1845561ac]
                  ! : | + 2 mach_absolute_time  (in libsystem_kernel.dylib) + 36,108  [0x1846890b0,0x1846890f8]
                  ! : | 1 clock_gettime_nsec_np  (in libsystem_c.dylib) + 316  [0x184556168]
                  ! : 1 DYLD-STUB$$clock_gettime  (in candidate) + 0  [0x1041ff19c]
                  ! : 1 clock_gettime  (in libsystem_c.dylib) + 64  [0x184564104]
                  ! 1 _RNvMNtNtNtNtCs1coMeGJvsuS_3std3sys3pal4unix4timeNtB2_8Timespec3now  (in candidate) + 8  [0x1041c97ac]
                  1 _RNvMNtCs1coMeGJvsuS_3std4timeNtB2_7Instant7elapsed  (in candidate) + 76  [0x1041c8ecc]

Total number in stack (recursive counted multiple, when >=5):
        18       _platform_memmove  (in libsystem_platform.dylib) + 0  [0x1846d7d60]
        11       _xzm_free  (in libsystem_malloc.dylib) + 0  [0x1844ec700]
        10       mach_absolute_time  (in libsystem_kernel.dylib) + 0  [0x18468908c]
        9       _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 0  [0x1041f9468]
        8       _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in candidate) + 0  [0x1041956b8]
        8       _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in candidate) + 0  [0x10419665c]
        8       _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 92  [0x1041f94c4]
        8       _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in candidate) + 0  [0x1041b1404]
        8       __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
        8       _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
        8       _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
        8       xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
        8       xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
        7       _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate) + 120  [0x1041f94e0]
        7       _malloc_zone_realloc  (in libsystem_malloc.dylib) + 0  [0x1844f4a98]
        7       _xzm_malloc  (in libsystem_malloc.dylib) + 0  [0x1844e7df4]
        7       _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 0  [0x1844e8a4c]
        7       xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
        6       _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in candidate) + 0  [0x10418e2e4]
        6       _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
        6       _xzm_free_tc  (in libsystem_malloc.dylib) + 0  [0x1844f1878]
        6       xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 0  [0x1844e5010]
        6       xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 0  [0x1844e4304]
        5       DYLD-STUB$$memcpy  (in candidate) + 0  [0x1041ff268]
        5       _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in candidate) + 0  [0x1041ae6cc]
        5       _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in candidate) + 0  [0x1041b0af0]
        5       _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in candidate) + 0  [0x104195ef0]
        5       _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in candidate) + 60  [0x1041f9184]
        5       _free  (in libsystem_malloc.dylib) + 0  [0x1844f5110]
        5       _xzm_malloc_tc  (in libsystem_malloc.dylib) + 0  [0x1844ef990]

Sort by top of stack, same collapsed (when >= 5):
        _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in candidate)        594
        _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in candidate)        227
        _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in candidate)        220
        _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in candidate)        158
        _platform_memmove  (in libsystem_platform.dylib)        136
        mach_absolute_time  (in libsystem_kernel.dylib)        106
        _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in candidate)        98
        _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown6stream9EventKindEBF_  (in candidate)        90
        _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in candidate)        82
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in candidate)        80
        _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in candidate)        79
        _RNvNtCs8seiryzelau_13core_markdown13inline_parser8resource  (in candidate)        57
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in candidate)        43
        _RNvNtCsglYb6d7nGNF_6memchr6memmem4find  (in candidate)        33
        _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in candidate)        28
        _xzm_free  (in libsystem_malloc.dylib)        27
        _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_EB7_  (in candidate)        26
        _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in candidate)        23
        xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib)        22
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in candidate)        19
        _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib)        18
        _malloc_zone_realloc  (in libsystem_malloc.dylib)        15
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in candidate)        14
        _xzm_malloc  (in libsystem_malloc.dylib)        14
        _RINvNtNtCs8seiryzelau_13core_markdown4util9tagfilter14write_filteredNtNtB6_6stream11StreamErrorNCINvMNtB6_19event_html_rendererINtB1B_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9event_refKb0_E0EB6_  (in candidate)        13
        xzm_malloc_zone_size  (in libsystem_malloc.dylib)        13
        _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in candidate)        11
        DYLD-STUB$$memcpy  (in candidate)        10
        _RNvMNtCs8seiryzelau_13core_markdown6streamNtB2_4Text7resolve  (in candidate)        10
        _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in candidate)        9
        _RNvNtNtCs8seiryzelau_13core_markdown13inline_parser8autolink3web  (in candidate)        9
        _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9terminateB4_  (in candidate)        8
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10interrupts  (in candidate)        8
        __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib)        8
        _xzm_free_tc  (in libsystem_malloc.dylib)        8
        _free  (in libsystem_malloc.dylib)        7
        _realloc  (in libsystem_malloc.dylib)        7
        _xzm_malloc_tc  (in libsystem_malloc.dylib)        7
        _RNvMNtCs9nEiEE0E2Vj_4core6resultINtB2_6ResultReNtNtCs8seiryzelau_13core_markdown6stream11StreamErrorE6expectBN_  (in candidate)        6
        _RNvCsjVqd8RsBhQu_7___rustc35___rust_no_alloc_shim_is_unstable_v2  (in candidate)        5
        _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser18suppress_autolinks  (in candidate)        5
        _malloc_zone_malloc  (in libsystem_malloc.dylib)        5

Binary Images:
       0x1040c4000 -        0x10428a86f +candidate (0) <E7B5473D-59DA-363A-AA82-032D1AA11ECF> /tmp/*/candidate
       0x184244000 -        0x1842935f7  libobjc.A.dylib (973.1) <C0680DF6-9900-3C29-A071-95A031686EF8> /usr/lib/libobjc.A.dylib
       0x184294000 -        0x18429e23f  libsharedcache.dylib (0) <BBF95357-BEBF-3D89-8900-2BBB14A667C5> /usr/lib/libsharedcache.dylib
       0x18429f000 -        0x1842c5d3b  libdyld.dylib (27062) <62863BCA-DD60-3D32-A9DB-89099BA6F3D7> /usr/lib/system/libdyld.dylib
       0x1842c6000 -        0x1843856e3  dyld (1.0.0 - 27062) <D341DDCB-7969-3A9C-8E03-0CF4751398A9> /usr/lib/dyld
       0x184386000 -        0x18438901f  libsystem_blocks.dylib (98.1) <6F304731-D95D-3501-B4AD-F2934F7F2446> /usr/lib/system/libsystem_blocks.dylib
       0x18438a000 -        0x1843df0df  libxpc.dylib (3298.1.1) <0791121F-B5FC-3F84-BF04-115E86D2D882> /usr/lib/system/libxpc.dylib
       0x1843e0000 -        0x1843ffc13  libsystem_trace.dylib (1966.1.1) <B48A8E3E-A12A-3342-8321-428B555E965E> /usr/lib/system/libsystem_trace.dylib
       0x184400000 -        0x1844b4f27  libcorecrypto.dylib (2109.0.22) <807AA6C9-5D8A-3CA5-B4CE-FACE5296EF6A> /usr/lib/system/libcorecrypto.dylib
       0x1844b5000 -        0x18450ac5f  libsystem_malloc.dylib (886.0.8) <2339CB57-FE5A-3154-A206-A76059C749EB> /usr/lib/system/libsystem_malloc.dylib
       0x18450b000 -        0x18455119f  libdispatch.dylib (1605.0.2) <022BF08F-0B3A-3225-9E65-16D1553CE90D> /usr/lib/system/libdispatch.dylib
       0x184552000 -        0x184554d2b  libsystem_featureflags.dylib (108) <20C1CAB2-1F13-3426-8146-9CAE9FF2A33D> /usr/lib/system/libsystem_featureflags.dylib
       0x184555000 -        0x1845d7ca3  libsystem_c.dylib (1786.0.3) <FBA7B23E-AA60-3A90-9AA4-A7A2E0AD63EE> /usr/lib/system/libsystem_c.dylib
       0x1845d8000 -        0x18466d033  libc++.1.dylib (2200.27) <1E9BA4AA-B5DA-3CF3-80AC-4B880049573F> /usr/lib/libc++.1.dylib
       0x18466e000 -        0x184687eff  libc++abi.dylib (2200.27) <A21743EE-6E1C-3E74-97EA-7AF793DE4BDF> /usr/lib/libc++abi.dylib
       0x184688000 -        0x1846c69ab  libsystem_kernel.dylib (13432.1.9) <F63BF418-8F75-34A4-AAF1-8CAF2B9B6A05> /usr/lib/system/libsystem_kernel.dylib
       0x1846c7000 -        0x1846d391b  libsystem_pthread.dylib (553.0.1) <5A1828C3-CBC2-3B85-BD07-C8ED10021A41> /usr/lib/system/libsystem_pthread.dylib
       0x1846d4000 -        0x1846dd4f3  libsystem_platform.dylib (402.0.1.0.1) <080E4444-A0FB-3913-9756-4E470015F32F> /usr/lib/system/libsystem_platform.dylib
       0x1846de000 -        0x18470c903  libsystem_info.dylib (603) <BC387AEB-1CEF-3513-92D7-D7F913596711> /usr/lib/system/libsystem_info.dylib
       0x188836000 -        0x18883fb13  libsystem_darwin.dylib (1786.0.3) <4E66C888-993C-3E6A-A8DA-A949C01C5B67> /usr/lib/system/libsystem_darwin.dylib
       0x188c90000 -        0x188ca1b8b  libsystem_notify.dylib (368) <58FD36D8-37A7-311C-80F2-8E64DD8710CF> /usr/lib/system/libsystem_notify.dylib
       0x18aded000 -        0x18ae07d93  libsystem_networkextension.dylib (2340.1.2) <22E1D190-486F-324F-ABA4-F36AB841BFE9> /usr/lib/system/libsystem_networkextension.dylib
       0x18ae95000 -        0x18aeac247  libsystem_asl.dylib (409) <B4D449B7-A821-3A9A-8019-E917B291F10A> /usr/lib/system/libsystem_asl.dylib
       0x18be40000 -        0x18be40f2f  libobjcMsgSend.dylib (973.1) <41179EDE-DC97-3BBE-8848-6400D12C1436> /usr/lib/objc/libobjcMsgSend.dylib
       0x18cf8c000 -        0x18cf93edf  libsystem_symptoms.dylib (2394.0.4) <60EE7884-9F4E-3184-A6AC-FA40A7A0297D> /usr/lib/system/libsystem_symptoms.dylib
       0x191324000 -        0x19135eaeb  libsystem_containermanager.dylib (833.0.8.0.1) <08A57205-555D-3792-8931-9D5B585AF326> /usr/lib/system/libsystem_containermanager.dylib
       0x192977000 -        0x19297b317  libsystem_configuration.dylib (1446) <F3EB66A7-7A24-3AE5-B6E8-9A37BB00F119> /usr/lib/system/libsystem_configuration.dylib
       0x19297c000 -        0x192982e03  libsystem_sandbox.dylib (3051.0.52) <1E892B56-092E-3832-BDE3-DCE356D7A4FA> /usr/lib/system/libsystem_sandbox.dylib
       0x193e40000 -        0x193e40f2f  libobjcMsgSend1.dylib (973.1) <B40D9B2A-E1EE-37ED-8004-711A1F263DE1> /usr/lib/objc/libobjcMsgSend1.dylib
       0x194560000 -        0x194562f93  libquarantine.dylib (217.0.4) <7FD4AE22-86EF-382B-83F5-ADF9336C1160> /usr/lib/system/libquarantine.dylib
       0x194c72000 -        0x194c781e7  libsystem_coreservices.dylib (203) <57248E07-11A5-3857-918E-4A3A63B69FE8> /usr/lib/system/libsystem_coreservices.dylib
       0x19523a000 -        0x195277b27  libsystem_m.dylib (3326.0.1) <A3FB340F-3ED5-30F4-8B64-9D5860F64D35> /usr/lib/system/libsystem_m.dylib
       0x195279000 -        0x19527c4f7  libmacho.dylib (27062) <50DEADEC-3E99-3519-AFC3-4A3FEB3F14C3> /usr/lib/system/libmacho.dylib
       0x195296000 -        0x1952a2707  libcommonCrypto.dylib (600041) <41C99F45-C5E6-39DB-B1F2-A1BEA9D242A4> /usr/lib/system/libcommonCrypto.dylib
       0x1952a3000 -        0x1952acc87  libunwind.dylib (2200.5) <3070AB81-B082-39E8-8A00-EF88DDE9AC47> /usr/lib/system/libunwind.dylib
       0x1952b4000 -        0x1952be7eb  libcopyfile.dylib (260.0.3) <72D95AF9-BF5E-3A84-81A6-BCC5BDB99857> /usr/lib/system/libcopyfile.dylib
       0x1952bf000 -        0x1952c28bf  libcompiler_rt.dylib (103.4) <DFB5CE7F-A36E-36AA-BECE-1392D3D43607> /usr/lib/system/libcompiler_rt.dylib
       0x1952c3000 -        0x1952c8077  libsystem_collections.dylib (1786.0.3) <1E8022D4-5A37-3A7A-8936-603E6FA88358> /usr/lib/system/libsystem_collections.dylib
       0x1952c9000 -        0x1952cbf1f  libsystem_secinit.dylib (182) <DE037464-4C5D-3E96-A33F-2A4557CC6A20> /usr/lib/system/libsystem_secinit.dylib
       0x1952cc000 -        0x1952ce97f  libremovefile.dylib (96) <E6E6DFCF-6B2C-3F30-A59D-816CAB1190CE> /usr/lib/system/libremovefile.dylib
       0x1952cf000 -        0x1952cfe27  libkeymgr.dylib (31) <5EC997EF-3ADA-360B-9FCD-5F940C83FA4E> /usr/lib/system/libkeymgr.dylib
       0x1952d0000 -        0x1952d8af7  libsystem_dnssd.dylib (3111.0.5.0.1) <DE22096F-1E5B-3D6E-8164-771582DD6391> /usr/lib/system/libsystem_dnssd.dylib
       0x1952d9000 -        0x1952ddf1b  libcache.dylib (95) <80BAE197-E285-3F6E-A1EE-B77FE37D7E5D> /usr/lib/system/libcache.dylib
       0x1952de000 -        0x1952df8f3  libSystem.B.dylib (1359) <4FDC9AA6-B344-37FE-B8C6-A4C94A038F57> /usr/lib/libSystem.B.dylib
       0x19be40000 -        0x19be40f2f  libobjcMsgSend2.dylib (973.1) <BD27A84B-C9AE-3282-BBEA-3B6119837B5A> /usr/lib/objc/libobjcMsgSend2.dylib
       0x1a3e40000 -        0x1a3e40f2f  libobjcMsgSend3.dylib (973.1) <C0860D68-DDFC-3BD7-8B06-DB0645CBBED4> /usr/lib/objc/libobjcMsgSend3.dylib
       0x1abe40000 -        0x1abe40f2f  libobjcMsgSend4.dylib (973.1) <A6153BF5-622B-3B01-81B6-F64A365EF613> /usr/lib/objc/libobjcMsgSend4.dylib
       0x1b3e40000 -        0x1b3e40f2f  libobjcMsgSend5.dylib (973.1) <3913A71C-B29A-3AEA-820B-BEC40AC1861A> /usr/lib/objc/libobjcMsgSend5.dylib
       0x1bbe40000 -        0x1bbe40f2f  libobjcMsgSend6.dylib (973.1) <9BC523A3-E167-3F6C-8CAE-0F3EBA671791> /usr/lib/objc/libobjcMsgSend6.dylib
       0x1c3e40000 -        0x1c3e40f2f  libobjcMsgSend7.dylib (973.1) <248B7BCE-5B4C-34C7-A340-43D5228628C5> /usr/lib/objc/libobjcMsgSend7.dylib
       0x1cbe40000 -        0x1cbe40f2f  libobjcMsgSend8.dylib (973.1) <3E041BAD-A8E8-3069-B741-78CD1A45B176> /usr/lib/objc/libobjcMsgSend8.dylib
       0x1d3e40000 -        0x1d3e40f2f  libobjcMsgSend9.dylib (973.1) <34A67969-21A0-39D6-BB81-8FDA5A2409DB> /usr/lib/objc/libobjcMsgSend9.dylib
       0x1dbe40000 -        0x1dbe40f2f  libobjcMsgSend10.dylib (973.1) <678186C0-8EAD-3B35-8CBB-00285B41E4A0> /usr/lib/objc/libobjcMsgSend10.dylib
       0x1e3e40000 -        0x1e3e40f2f  libobjcMsgSend11.dylib (973.1) <E05CB08C-E956-36FA-8967-AE8E346A8D2C> /usr/lib/objc/libobjcMsgSend11.dylib
       0x20be40000 -        0x20be40f2f  libobjcMsgSend12.dylib (973.1) <10AB03AA-FF1F-3FDC-9DFB-BFC40042C501> /usr/lib/objc/libobjcMsgSend12.dylib
       0x213e40000 -        0x213e40f2f  libobjcMsgSend13.dylib (973.1) <ABF53427-FA6F-3D0D-8F9D-7AD795CA5C92> /usr/lib/objc/libobjcMsgSend13.dylib
       0x21be40000 -        0x21be40f2f  libobjcMsgSend14.dylib (973.1) <9A844C46-A6DA-34D4-8EBF-2AD775C30684> /usr/lib/objc/libobjcMsgSend14.dylib
       0x223e40000 -        0x223e40f2f  libobjcMsgSend15.dylib (973.1) <7C995666-2B2D-3284-AA0A-EBF7C922838E> /usr/lib/objc/libobjcMsgSend15.dylib
       0x22be40000 -        0x22be40f2f  libobjcMsgSend16.dylib (973.1) <B6C0E14B-53AE-3E22-9ED5-1729C49F46F2> /usr/lib/objc/libobjcMsgSend16.dylib
       0x233e40000 -        0x233e40f2f  libobjcMsgSend17.dylib (973.1) <07B4CF85-251B-301B-832B-20B315A59E19> /usr/lib/objc/libobjcMsgSend17.dylib
       0x23be40000 -        0x23be40f2f  libobjcMsgSend18.dylib (973.1) <43E575B7-04DB-3999-A633-1A3B638BA6E3> /usr/lib/objc/libobjcMsgSend18.dylib
       0x243e40000 -        0x243e40f2f  libobjcMsgSend19.dylib (973.1) <736F4D85-76F7-3B28-8D87-C07E8F7A0EF4> /usr/lib/objc/libobjcMsgSend19.dylib
       0x24be40000 -        0x24be40f2f  libobjcMsgSend20.dylib (973.1) <74E67C8B-6BCA-3184-A18E-A97F370052C6> /usr/lib/objc/libobjcMsgSend20.dylib
       0x253e40000 -        0x253e40f2f  libobjcMsgSend21.dylib (973.1) <CC0D732F-98E7-3888-9E15-70984DA2FB04> /usr/lib/objc/libobjcMsgSend21.dylib
       0x25be40000 -        0x25be40f2f  libobjcMsgSend22.dylib (973.1) <85A60286-5DE3-32BA-B18C-2A498B065C88> /usr/lib/objc/libobjcMsgSend22.dylib
       0x263e40000 -        0x263e40f2f  libobjcMsgSend23.dylib (973.1) <5452A0D2-6B19-39BE-ADDD-80B7BCDE3A98> /usr/lib/objc/libobjcMsgSend23.dylib
       0x26be40000 -        0x26be40f2f  libobjcMsgSend24.dylib (973.1) <94BBF2D6-722B-350D-8557-4D25A8E8D53A> /usr/lib/objc/libobjcMsgSend24.dylib
       0x273e40000 -        0x273e40f2f  libobjcMsgSend25.dylib (973.1) <35481387-5A8E-3AE4-86A6-94CEB3CC8726> /usr/lib/objc/libobjcMsgSend25.dylib
       0x28be40000 -        0x28be40f2f  libobjcMsgSend26.dylib (973.1) <9E0C8664-E7F4-39D1-AAFC-BD92B255E4E8> /usr/lib/objc/libobjcMsgSend26.dylib
       0x293e40000 -        0x293e40f2f  libobjcMsgSend27.dylib (973.1) <FD424935-55A9-3650-955A-EED3441A1D19> /usr/lib/objc/libobjcMsgSend27.dylib
       0x29be40000 -        0x29be40f2f  libobjcMsgSend28.dylib (973.1) <09BA7B97-7DF7-3C7F-932A-B6847662FC49> /usr/lib/objc/libobjcMsgSend28.dylib
       0x2a3e40000 -        0x2a3e40f2f  libobjcMsgSend29.dylib (973.1) <36D5BA3F-2139-30B0-8558-556764BE9813> /usr/lib/objc/libobjcMsgSend29.dylib
       0x2abe40000 -        0x2abe40f2f  libobjcMsgSend30.dylib (973.1) <9F05564A-9D12-372C-98FC-E9F0E6BE4F04> /usr/lib/objc/libobjcMsgSend30.dylib
       0x2b0b5a000 -        0x2b0b60fe5  libRosetta.dylib (385) <E359944B-D230-33F9-A04E-0C3B17C3326E> /usr/lib/libRosetta.dylib
       0x2b1549000 -        0x2b154c75b  libsystem_darwindirectory.dylib (129.0.1) <61264923-2AA5-3658-B8C4-550C71E9D4B3> /usr/lib/system/libsystem_darwindirectory.dylib
       0x2b154d000 -        0x2b1557d9b  libsystem_eligibility.dylib (446.1.3) <EDDE8E9C-A2CF-3931-BBB3-321CB852EB30> /usr/lib/system/libsystem_eligibility.dylib
       0x2b1558000 -        0x2b156142b  libsystem_sanitizers.dylib (32) <7138ED99-7AA0-34EA-B35B-20EF6ADB1EED> /usr/lib/system/libsystem_sanitizers.dylib
       0x2b1562000 -        0x2b1562a13  libsystem_trial.dylib (511) <6AE48824-EC44-3A8C-B501-BE57DBE892E7> /usr/lib/system/libsystem_trial.dylib
       0x2b3e40000 -        0x2b3e40f2f  libobjcMsgSend31.dylib (973.1) <0985E20F-78C3-3466-A2B2-DBB95F7104A3> /usr/lib/objc/libobjcMsgSend31.dylib
       0x2bbe40000 -        0x2bbe40f2f  libobjcMsgSend32.dylib (973.1) <0D309D58-D576-3E5D-AD4B-6D55AB491702> /usr/lib/objc/libobjcMsgSend32.dylib
       0x2c3e40000 -        0x2c3e40f2f  libobjcMsgSend33.dylib (973.1) <346E0484-48FA-369B-8A64-93B5F5341CFE> /usr/lib/objc/libobjcMsgSend33.dylib
       0x2cbe40000 -        0x2cbe40f2f  libobjcMsgSend34.dylib (973.1) <6A31F809-BCBE-3E01-A367-E91FDACCE324> /usr/lib/objc/libobjcMsgSend34.dylib
