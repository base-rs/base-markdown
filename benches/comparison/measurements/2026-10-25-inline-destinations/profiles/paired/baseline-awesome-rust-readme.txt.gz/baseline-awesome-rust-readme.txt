Analysis of sampling baseline (pid 19447) every 1 millisecond
Process:         baseline [19447]
Path:            /private/tmp/*/baseline
Load Address:    0x1026dc000
Identifier:      baseline
Version:         0
Code Type:       ARM64
Platform:        macOS
Parent Process:  python3.13 [19421]
Target Type:     live task

Date/Time:       2026-10-25 11:34:41.256 +1300
Launch Time:     2026-10-25 11:34:40.720 +1300
OS Version:      macOS 27.0.1 (26A434)
Report Version:  7
Analysis Tool:   /usr/bin/sample

Physical footprint:         4768K
Physical footprint (peak):  4768K
Idle exit:                  untracked
----

Call graph:
    2504 Thread_43564586   DispatchQueue_1: com.apple.main-thread  (serial)
      2504 start  (in dyld) + 6688  [0x1842f7e80]
        2504 main  (in baseline) + 52  [0x1026ffc20]
          2504 _RNvNtCs1coMeGJvsuS_3std2rt19lang_start_internal  (in baseline) + 936  [0x1027ee030]
            2504 _RNCINvNtCs1coMeGJvsuS_3std2rt10lang_startuE0CseVgRDH8534i_19markdown_comparison  (in baseline) + 16  [0x1027126d4]
              2504 _RINvNtNtCs1coMeGJvsuS_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECseVgRDH8534i_19markdown_comparison  (in baseline) + 12  [0x102713000]
                2504 _RNvCseVgRDH8534i_19markdown_comparison4main  (in baseline) + 1380  [0x1026fe264]
                  2504 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 9268  [0x1026fd2ac]
                    1947 _RNvCs8seiryzelau_13core_markdown20to_html_with_options  (in baseline) + 216  [0x1027c3794]
                    + 812 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 6348  [0x10279e140]
                    + ! 499 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 3932  [0x1027928c4]
                    + ! : 499 _RNvNtCs8seiryzelau_13core_markdown13inline_parser8resource  (in baseline) + 424,460,...  [0x10279c470,0x10279c494,...]
                    + ! 280 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 4580,6900,...  [0x102792b4c,0x10279345c,...]
                    + ! 9 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 4052  [0x10279293c]
                    + ! : 9 _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser18suppress_autolinks  (in baseline) + 40,48,...  [0x10279b56c,0x10279b574,...]
                    + ! 8 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_EB7_  (in baseline) + 1464  [0x102799ce0]
                    + ! 3 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 1716  [0x10279201c]
                    + ! : 3 _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser11index_ticks  (in baseline) + 1204,1324  [0x10279a668,0x10279a6e0]
                    + ! 3 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 4028  [0x102792924]
                    + ! : 3 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_EB7_  (in baseline) + 32,44  [0x102799748,0x102799754]
                    + ! 3 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 9612  [0x102793ef4]
                    + ! : 3 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_EB7_  (in baseline) + 24,32,...  [0x102799740,0x102799748,...]
                    + ! 2 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 1280  [0x102791e68]
                    + ! : 2 _RNvNtNtCs8seiryzelau_13core_markdown13inline_parser8autolink3web  (in baseline) + 280,536  [0x1027cb178,0x1027cb278]
                    + ! 2 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 4884  [0x102792c7c]
                    + ! : 2 _RNvNtNtCs8seiryzelau_13core_markdown4util4char8classify  (in baseline) + 28,104  [0x1027c6078,0x1027c60c4]
                    + ! 2 _RNvNtNtCs8seiryzelau_13core_markdown13inline_parser8autolink3web  (in baseline) + 1928  [0x1027cb7e8]
                    + ! 1 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 3972  [0x1027928ec]
                    + !   1 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser4LinkE8grow_oneBQ_  (in baseline) + 60  [0x10281114c]
                    + !     1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x1028113c4]
                    + !       1 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                    + !         1 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                    + !           1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                    + !             1 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                    + !               1 mach_absolute_time  (in libsystem_kernel.dylib) + 108  [0x1846890f8]
                    + 437 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 8228,1304,...  [0x10279e898,0x10279cd8c,...]
                    + 247 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 12852  [0x10279faa8]
                    + ! 206 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in baseline) + 252,132,...  [0x1027a62cc,0x1027a6254,...]
                    + ! 40 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in baseline) + 652  [0x1027a645c]
                    + ! : 37 _platform_memmove  (in libsystem_platform.dylib) + 452,428,...  [0x1846d7f24,0x1846d7f0c,...]
                    + ! : 3 DYLD-STUB$$memcpy  (in baseline) + 4  [0x10281716c]
                    + ! 1 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in baseline) + 704  [0x1027a6490]
                    + !   1 _RINvNtNtCs8seiryzelau_13core_markdown4util6encode13write_escapedNtNtCs3vUkWdPtNor_5alloc6string6StringEB6_  (in baseline) + 164  [0x1027cda40]
                    + 155 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 23128  [0x1027a22cc]
                    + ! 134 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in baseline) + 836,844,...  [0x1027c1f24,0x1027c1f2c,...]
                    + ! 19 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in baseline) + 2364  [0x1027c251c]
                    + ! : 17 _platform_memmove  (in libsystem_platform.dylib) + 428,452,...  [0x1846d7f0c,0x1846d7f24,...]
                    + ! : 2 DYLD-STUB$$memcpy  (in baseline) + 4  [0x10281716c]
                    + ! 2 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in baseline) + 2556  [0x1027c25dc]
                    + !   2 _RINvNvMs2_NtCs3vUkWdPtNor_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs8seiryzelau_13core_markdown  (in baseline) + 108  [0x102810f2c]
                    + !     2 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x1028113c4]
                    + !       2 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                    + !         2 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                    + !           1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 740  [0x1844e52f4]
                    + !           | 1 xzm_segment_group_try_realloc_large_chunk  (in libsystem_malloc.dylib) + 444  [0x1844ca0f0]
                    + !           |   1 _xzm_segment_group_span_mark_smaller  (in libsystem_malloc.dylib) + 324  [0x1844ca470]
                    + !           |     1 xzm_reclaim_mark_free_locked  (in libsystem_malloc.dylib) + 120  [0x1844c7cfc]
                    + !           |       1 mach_vm_reclaim_try_enter  (in libsystem_kernel.dylib) + 316  [0x18469c53c]
                    + !           |         1 mach_absolute_time  (in libsystem_kernel.dylib) + 108  [0x1846890f8]
                    + !           1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                    + !             1 _platform_memmove  (in libsystem_platform.dylib) + 100  [0x1846d7dc4]
                    + 134 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 1768  [0x10279cf5c]
                    + ! 105 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in baseline) + 340,328,...  [0x1027c6c54,0x1027c6c48,...]
                    + ! 26 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in baseline) + 1100  [0x1027c6f4c]
                    + ! : 26 _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in baseline) + 48,0,...  [0x1027c65fc,0x1027c65cc,...]
                    + ! 3 _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in baseline) + 828,832  [0x1027c6908,0x1027c690c]
                    + 52 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 24752  [0x1027a2924]
                    + ! 52 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown6stream9EventKindEBF_  (in baseline) + 36,12,...  [0x1027a5f78,0x1027a5f60,...]
                    + 44 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 22720  [0x1027a2134]
                    + ! 42 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in baseline) + 836,856,...  [0x1027c1f24,0x1027c1f38,...]
                    + ! 2 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in baseline) + 2364  [0x1027c251c]
                    + !   2 _platform_memmove  (in libsystem_platform.dylib) + 204,428  [0x1846d7e2c,0x1846d7f0c]
                    + 15 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown6stream9EventKindEBF_  (in baseline) + 96  [0x1027a5fb4]
                    + 8 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 23068  [0x1027a2290]
                    + ! 8 _RNvMNtCs8seiryzelau_13core_markdown6streamNtB2_4Text7resolve  (in baseline) + 0,68,...  [0x1027c42c4,0x1027c4308,...]
                    + 8 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in baseline) + 732,736  [0x1027a64ac,0x1027a64b0]
                    + 7 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 11904  [0x10279f6f4]
                    + ! 4 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9terminateB4_  (in baseline) + 288  [0x1027a9248]
                    + ! : 3 _platform_memmove  (in libsystem_platform.dylib) + 0,428,...  [0x1846d7d60,0x1846d7f0c,...]
                    + ! : 1 DYLD-STUB$$memcpy  (in baseline) + 4  [0x10281716c]
                    + ! 2 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9terminateB4_  (in baseline) + 332  [0x1027a9274]
                    + ! 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 11904  [0x10279f6f4]
                    + !   1 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9terminateB4_  (in baseline) + 152  [0x1027a91c0]
                    + 5 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 9736  [0x102793f70]
                    + 5 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in baseline) + 2292,2300,...  [0x1027c24d4,0x1027c24dc,...]
                    + 5 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in baseline) + 1168,1164,...  [0x1027c6f90,0x1027c6f8c,...]
                    + 2 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 19544  [0x1027a14cc]
                    + ! 1 DYLD-STUB$$memcpy  (in baseline) + 4  [0x10281716c]
                    + ! 1 _platform_memmove  (in libsystem_platform.dylib) + 452  [0x1846d7f24]
                    + 2 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 23084  [0x1027a22a0]
                    + ! 2 _RNvMNtCs9nEiEE0E2Vj_4core6resultINtB2_6ResultReNtNtCs8seiryzelau_13core_markdown6stream11StreamErrorE6expectBN_  (in baseline) + 12  [0x1027a92fc]
                    + 2 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 34868  [0x1027a50a8]
                    + ! 1 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown12event_parser11EventParserEBF_  (in baseline) + 52  [0x1027a5b5c]
                    + ! : 1 xzm_segment_group_free_chunk  (in libsystem_malloc.dylib) + 848  [0x1844c97a8]
                    + ! :   1 _xzm_segment_group_span_mark_free  (in libsystem_malloc.dylib) + 28  [0x1844c9ed0]
                    + ! 1 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown13inline_parser12InlineParserEBF_  (in baseline) + 96  [0x1027a5d70]
                    + !   1 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                    + !     1 mach_absolute_time  (in libsystem_kernel.dylib) + 108  [0x1846890f8]
                    + 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 15072  [0x1027a0354]
                    + ! 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 15072  [0x1027a0354]
                    + !   1 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9terminateB4_  (in baseline) + 152  [0x1027a91c0]
                    + 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 22640  [0x1027a20e4]
                    + ! 1 _RNvMNtCs8seiryzelau_13core_markdown6streamNtB2_4Text7resolve  (in baseline) + 20  [0x1027c42d8]
                    + 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 23688  [0x1027a24fc]
                    + ! 1 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser9DelimiterE8grow_oneBQ_  (in baseline) + 60  [0x102811278]
                    + !   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x1028113c4]
                    + !     1 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                    + !       1 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                    + !         1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                    + !           1 _platform_memmove  (in libsystem_platform.dylib) + 24  [0x1846d7d78]
                    + 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 25588  [0x1027a2c68]
                    + ! 1 DYLD-STUB$$memcpy  (in baseline) + 4  [0x10281716c]
                    + 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 25796  [0x1027a2d38]
                    + ! 1 _platform_memmove  (in libsystem_platform.dylib) + 452  [0x1846d7f24]
                    + 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 34256  [0x1027a4e44]
                    + ! 1 _RINvNvMs2_NtCs3vUkWdPtNor_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs8seiryzelau_13core_markdown  (in baseline) + 108  [0x102810f2c]
                    + !   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x1028113c4]
                    + !     1 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                    + !       1 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                    + !         1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                    + !           1 _platform_memmove  (in libsystem_platform.dylib) + 88  [0x1846d7db8]
                    + 1 _RNvMNtCs9nEiEE0E2Vj_4core6resultINtB2_6ResultReNtNtCs8seiryzelau_13core_markdown6stream11StreamErrorE6expectBN_  (in baseline) + 36  [0x1027a9314]
                    557 _RNvCs8seiryzelau_13core_markdown20to_html_with_options  (in baseline) + 200  [0x1027c3784]
                      557 _RNvMNtCs8seiryzelau_13core_markdown12event_parserNtB2_11EventParser7prepare  (in baseline) + 44  [0x1027c265c]
                        133 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 4424,4544,...  [0x1027b0180,0x1027b01f8,...]
                        116 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 7124  [0x1027b0c0c]
                        ! 86 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 72  [0x1027ae0a8]
                        ! : 86 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 420,272,...  [0x1027c94a8,0x1027c9414,...]
                        ! 27 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 112  [0x1027ae0d0]
                        ! : 27 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 304,572,...  [0x1027ad6e8,0x1027ad7f4,...]
                        ! 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 192,324  [0x1027ae120,0x1027ae1a4]
                        ! 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 644  [0x1027ad83c]
                        94 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 4640  [0x1027b0258]
                        ! 52 _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in baseline) + 64  [0x1027ccbf0]
                        ! : 47 _RNvXNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fnINtB2_6FromFnNCNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB17_7Builder20definition_fragments0ENtNtNtB6_6traits8iterator8Iterator4nextB19_  (in baseline) + 280  [0x1027d0078]
                        ! : | 47 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 420,272,...  [0x1027c94a8,0x1027c9414,...]
                        ! : 5 _RNvXNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fnINtB2_6FromFnNCNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB17_7Builder20definition_fragments0ENtNtNtB6_6traits8iterator8Iterator4nextB19_  (in baseline) + 44,56  [0x1027cff8c,0x1027cff98]
                        ! 37 _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in baseline) + 644,784,...  [0x1027cce34,0x1027ccec0,...]
                        ! 5 _RNvXNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fnINtB2_6FromFnNCNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB17_7Builder20definition_fragments0ENtNtNtB6_6traits8iterator8Iterator4nextB19_  (in baseline) + 688,680  [0x1027d0210,0x1027d0208]
                        74 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6048  [0x1027b07d8]
                        ! 72 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10table_head  (in baseline) + 36  [0x1027adb64]
                        ! : 40 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 72  [0x1027ae0a8]
                        ! : | 40 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 420,272,...  [0x1027c94a8,0x1027c9414,...]
                        ! : 26 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 112  [0x1027ae0d0]
                        ! : | 26 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 196,136,...  [0x1027ad67c,0x1027ad640,...]
                        ! : 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 40  [0x1027ae088]
                        ! : 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 644  [0x1027ad83c]
                        ! 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 436  [0x1027ae214]
                        30 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 7264  [0x1027b0c98]
                        ! 21 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15list_interrupts  (in baseline) + 72  [0x1027adf7c]
                        ! : 12 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 20,128,...  [0x1027c8a04,0x1027c8a70,...]
                        ! : 9 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 492  [0x1027c8bdc]
                        ! :   9 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline) + 104,20,...  [0x1027c88f0,0x1027c889c,...]
                        ! 6 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10interrupts  (in baseline) + 272,4,...  [0x1027ad980,0x1027ad874,...]
                        ! 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15list_interrupts  (in baseline) + 40,136  [0x1027adf5c,0x1027adfbc]
                        ! 1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 672  [0x1027c8c90]
                        18 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6712  [0x1027b0a70]
                        ! 18 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 152,196,...  [0x1027ad650,0x1027ad67c,...]
                        17 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 1820  [0x1027af754]
                        ! 9 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 52,128,...  [0x1027c8a24,0x1027c8a70,...]
                        ! 8 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 492  [0x1027c8bdc]
                        !   8 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline) + 8,20,...  [0x1027c8890,0x1027c889c,...]
                        15 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 656  [0x1027af2c8]
                        ! 15 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 140,136,...  [0x1027ad644,0x1027ad640,...]
                        14 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6620  [0x1027b0a14]
                        ! 14 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 272,280,...  [0x1027c9414,0x1027c941c,...]
                        8 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6516  [0x1027b09ac]
                        ! 8 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 116,20,...  [0x1027ae5d0,0x1027ae570,...]
                        6 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 192  [0x1027ae61c]
                        5 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5692  [0x1027b0674]
                        ! 5 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 100,120,...  [0x1027c9368,0x1027c937c,...]
                        4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 644,648  [0x1027ad83c,0x1027ad840]
                        4 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6664  [0x1027b0a40]
                        ! 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 60,20,...  [0x1027ae598,0x1027ae570,...]
                        3 _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in baseline) + 3208,3196  [0x1027cd838,0x1027cd82c]
                        2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10table_head  (in baseline) + 356  [0x1027adca4]
                        2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15list_interrupts  (in baseline) + 236  [0x1027ae020]
                        2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 2636  [0x1027afa84]
                        ! 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 12,60  [0x1027ae568,0x1027ae598]
                        2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 2728  [0x1027afae0]
                        ! 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 20,116  [0x1027ae570,0x1027ae5d0]
                        2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6488  [0x1027b0990]
                        ! 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline) + 24  [0x1027ade08]
                        2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 7308  [0x1027b0cc4]
                        ! 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15list_interrupts  (in baseline) + 72  [0x1027adf7c]
                        !   1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 492  [0x1027c8bdc]
                        !   : 1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline) + 144  [0x1027c8918]
                        !   1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 180  [0x1027c8aa4]
                        1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 672  [0x1027c8c90]
                        1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 436  [0x1027ae214]
                        1 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 2760  [0x1027afb00]
                        ! 1 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown8document6NodeIdE8grow_oneBQ_  (in baseline) + 60  [0x102811340]
                        !   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x1028113c4]
                        !     1 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                        !       1 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                        !         1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                        !           1 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                        !             1 mach_absolute_time  (in libsystem_kernel.dylib) + 16  [0x18468909c]
                        1 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 9336  [0x1027b14b0]
                          1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 20  [0x1027ae570]

Total number in stack (recursive counted multiple, when >=5):
        9       _platform_memmove  (in libsystem_platform.dylib) + 0  [0x1846d7d60]
        7       _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 0  [0x1027ad5b8]
        6       _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 0  [0x1027ae55c]
        5       DYLD-STUB$$memcpy  (in baseline) + 0  [0x102817168]
        5       _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 0  [0x1027c89f0]
        5       _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x1028113c4]
        5       _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 0  [0x1027c9304]
        5       _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
        5       _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]

Sort by top of stack, same collapsed (when >= 5):
        _RNvNtCs8seiryzelau_13core_markdown13inline_parser8resource  (in baseline)        499
        _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline)        437
        _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline)        285
        _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in baseline)        214
        _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline)        192
        _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in baseline)        181
        _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline)        133
        _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in baseline)        110
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline)        93
        _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown6stream9EventKindEBF_  (in baseline)        67
        _platform_memmove  (in libsystem_platform.dylib)        64
        _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in baseline)        40
        _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in baseline)        29
        _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline)        24
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline)        23
        _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline)        18
        _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_EB7_  (in baseline)        14
        _RNvXNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fnINtB2_6FromFnNCNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB17_7Builder20definition_fragments0ENtNtNtB6_6traits8iterator8Iterator4nextB19_  (in baseline)        10
        _RNvMNtCs8seiryzelau_13core_markdown6streamNtB2_4Text7resolve  (in baseline)        9
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline)        9
        _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser18suppress_autolinks  (in baseline)        9
        DYLD-STUB$$memcpy  (in baseline)        8
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10interrupts  (in baseline)        6

Binary Images:
       0x1026dc000 -        0x1028a266f +baseline (0) <769F5531-DB9E-306E-999A-643EE6A203C3> /tmp/*/baseline
       0x184244000 -        0x1842935f7  libobjc.A.dylib (973.1) <C0680DF6-9900-3C29-A071-95A031686EF8> /usr/lib/libobjc.A.dylib
       0x184294000 -        0x18429e23f  libsharedcache.dylib (0) <BBF95357-BEBF-3D89-8900-2BBB14A667C5> /usr/lib/libsharedcache.dylib
       0x18429f000 -        0x1842c5d3b  libdyld.dylib (27062) <62863BCA-DD60-3D32-A9DB-89099BA6F3D7> /usr/lib/system/libdyld.dylib
       0x1842c6000 -        0x1843856e3  dyld (1.0.0 - 27062) <D341DDCB-7969-3A9C-8E03-0CF4751398A9> /usr/lib/dyld
       0x184386000 -        0x18438901f  libsystem_blocks.dylib (98.1) <6F304731-D95D-3501-B4AD-F2934F7F2446> /usr/lib/system/libsystem_blocks.dylib
       0x18438a000 -        0x1843df0df  libxpc.dylib (3298.1.1) <0791121F-B5FC-3F84-BF04-115E86D2D882> /usr/lib/system/libxpc.dylib
       0x1843e0000 -        0x1843ffc13  libsystem_trace.dylib (1966.1.1) <B48A8E3E-A12A-3342-8321-428B555E965E> /usr/lib/system/libsystem_trace.dylib
       0x184400000 -        0x1844b4f27  libcorecrypto.dylib (2109.0.22) <807AA6C9-5D8A-3CA5-B4CE-FACE5296EF6A> /usr/lib/system/libcorecrypto.dylib
       0x1844b5000 -        0x18450ac5f  libsystem_malloc.dylib (886.0.8) <2339CB57-FE5A-3154-A206-A76059C749EB> /usr/lib/system/libsystem_malloc.dylib
       0x18450b000 -        0x18455119f  libdispatch.dylib (1605.0.2) <022BF08F-0B3A-3225-9E65-16D1553CE90D> /usr/lib/system/libdispatch.dylib
       0x184552000 -        0x184554d2b  libsystem_featureflags.dylib (108) <20C1CAB2-1F13-3426-8146-9CAE9FF2A33D> /usr/lib/system/libsystem_featureflags.dylib
       0x184555000 -        0x1845d7ca3  libsystem_c.dylib (1786.0.3) <FBA7B23E-AA60-3A90-9AA4-A7A2E0AD63EE> /usr/lib/system/libsystem_c.dylib
       0x1845d8000 -        0x18466d033  libc++.1.dylib (2200.27) <1E9BA4AA-B5DA-3CF3-80AC-4B880049573F> /usr/lib/libc++.1.dylib
       0x18466e000 -        0x184687eff  libc++abi.dylib (2200.27) <A21743EE-6E1C-3E74-97EA-7AF793DE4BDF> /usr/lib/libc++abi.dylib
       0x184688000 -        0x1846c69ab  libsystem_kernel.dylib (13432.1.9) <F63BF418-8F75-34A4-AAF1-8CAF2B9B6A05> /usr/lib/system/libsystem_kernel.dylib
       0x1846c7000 -        0x1846d391b  libsystem_pthread.dylib (553.0.1) <5A1828C3-CBC2-3B85-BD07-C8ED10021A41> /usr/lib/system/libsystem_pthread.dylib
       0x1846d4000 -        0x1846dd4f3  libsystem_platform.dylib (402.0.1.0.1) <080E4444-A0FB-3913-9756-4E470015F32F> /usr/lib/system/libsystem_platform.dylib
       0x1846de000 -        0x18470c903  libsystem_info.dylib (603) <BC387AEB-1CEF-3513-92D7-D7F913596711> /usr/lib/system/libsystem_info.dylib
       0x188836000 -        0x18883fb13  libsystem_darwin.dylib (1786.0.3) <4E66C888-993C-3E6A-A8DA-A949C01C5B67> /usr/lib/system/libsystem_darwin.dylib
       0x188c90000 -        0x188ca1b8b  libsystem_notify.dylib (368) <58FD36D8-37A7-311C-80F2-8E64DD8710CF> /usr/lib/system/libsystem_notify.dylib
       0x18aded000 -        0x18ae07d93  libsystem_networkextension.dylib (2340.1.2) <22E1D190-486F-324F-ABA4-F36AB841BFE9> /usr/lib/system/libsystem_networkextension.dylib
       0x18ae95000 -        0x18aeac247  libsystem_asl.dylib (409) <B4D449B7-A821-3A9A-8019-E917B291F10A> /usr/lib/system/libsystem_asl.dylib
       0x18be40000 -        0x18be40f2f  libobjcMsgSend.dylib (973.1) <41179EDE-DC97-3BBE-8848-6400D12C1436> /usr/lib/objc/libobjcMsgSend.dylib
       0x18cf8c000 -        0x18cf93edf  libsystem_symptoms.dylib (2394.0.4) <60EE7884-9F4E-3184-A6AC-FA40A7A0297D> /usr/lib/system/libsystem_symptoms.dylib
       0x191324000 -        0x19135eaeb  libsystem_containermanager.dylib (833.0.8.0.1) <08A57205-555D-3792-8931-9D5B585AF326> /usr/lib/system/libsystem_containermanager.dylib
       0x192977000 -        0x19297b317  libsystem_configuration.dylib (1446) <F3EB66A7-7A24-3AE5-B6E8-9A37BB00F119> /usr/lib/system/libsystem_configuration.dylib
       0x19297c000 -        0x192982e03  libsystem_sandbox.dylib (3051.0.52) <1E892B56-092E-3832-BDE3-DCE356D7A4FA> /usr/lib/system/libsystem_sandbox.dylib
       0x193e40000 -        0x193e40f2f  libobjcMsgSend1.dylib (973.1) <B40D9B2A-E1EE-37ED-8004-711A1F263DE1> /usr/lib/objc/libobjcMsgSend1.dylib
       0x194560000 -        0x194562f93  libquarantine.dylib (217.0.4) <7FD4AE22-86EF-382B-83F5-ADF9336C1160> /usr/lib/system/libquarantine.dylib
       0x194c72000 -        0x194c781e7  libsystem_coreservices.dylib (203) <57248E07-11A5-3857-918E-4A3A63B69FE8> /usr/lib/system/libsystem_coreservices.dylib
       0x19523a000 -        0x195277b27  libsystem_m.dylib (3326.0.1) <A3FB340F-3ED5-30F4-8B64-9D5860F64D35> /usr/lib/system/libsystem_m.dylib
       0x195279000 -        0x19527c4f7  libmacho.dylib (27062) <50DEADEC-3E99-3519-AFC3-4A3FEB3F14C3> /usr/lib/system/libmacho.dylib
       0x195296000 -        0x1952a2707  libcommonCrypto.dylib (600041) <41C99F45-C5E6-39DB-B1F2-A1BEA9D242A4> /usr/lib/system/libcommonCrypto.dylib
       0x1952a3000 -        0x1952acc87  libunwind.dylib (2200.5) <3070AB81-B082-39E8-8A00-EF88DDE9AC47> /usr/lib/system/libunwind.dylib
       0x1952b4000 -        0x1952be7eb  libcopyfile.dylib (260.0.3) <72D95AF9-BF5E-3A84-81A6-BCC5BDB99857> /usr/lib/system/libcopyfile.dylib
       0x1952bf000 -        0x1952c28bf  libcompiler_rt.dylib (103.4) <DFB5CE7F-A36E-36AA-BECE-1392D3D43607> /usr/lib/system/libcompiler_rt.dylib
       0x1952c3000 -        0x1952c8077  libsystem_collections.dylib (1786.0.3) <1E8022D4-5A37-3A7A-8936-603E6FA88358> /usr/lib/system/libsystem_collections.dylib
       0x1952c9000 -        0x1952cbf1f  libsystem_secinit.dylib (182) <DE037464-4C5D-3E96-A33F-2A4557CC6A20> /usr/lib/system/libsystem_secinit.dylib
       0x1952cc000 -        0x1952ce97f  libremovefile.dylib (96) <E6E6DFCF-6B2C-3F30-A59D-816CAB1190CE> /usr/lib/system/libremovefile.dylib
       0x1952cf000 -        0x1952cfe27  libkeymgr.dylib (31) <5EC997EF-3ADA-360B-9FCD-5F940C83FA4E> /usr/lib/system/libkeymgr.dylib
       0x1952d0000 -        0x1952d8af7  libsystem_dnssd.dylib (3111.0.5.0.1) <DE22096F-1E5B-3D6E-8164-771582DD6391> /usr/lib/system/libsystem_dnssd.dylib
       0x1952d9000 -        0x1952ddf1b  libcache.dylib (95) <80BAE197-E285-3F6E-A1EE-B77FE37D7E5D> /usr/lib/system/libcache.dylib
       0x1952de000 -        0x1952df8f3  libSystem.B.dylib (1359) <4FDC9AA6-B344-37FE-B8C6-A4C94A038F57> /usr/lib/libSystem.B.dylib
       0x19be40000 -        0x19be40f2f  libobjcMsgSend2.dylib (973.1) <BD27A84B-C9AE-3282-BBEA-3B6119837B5A> /usr/lib/objc/libobjcMsgSend2.dylib
       0x1a3e40000 -        0x1a3e40f2f  libobjcMsgSend3.dylib (973.1) <C0860D68-DDFC-3BD7-8B06-DB0645CBBED4> /usr/lib/objc/libobjcMsgSend3.dylib
       0x1abe40000 -        0x1abe40f2f  libobjcMsgSend4.dylib (973.1) <A6153BF5-622B-3B01-81B6-F64A365EF613> /usr/lib/objc/libobjcMsgSend4.dylib
       0x1b3e40000 -        0x1b3e40f2f  libobjcMsgSend5.dylib (973.1) <3913A71C-B29A-3AEA-820B-BEC40AC1861A> /usr/lib/objc/libobjcMsgSend5.dylib
       0x1bbe40000 -        0x1bbe40f2f  libobjcMsgSend6.dylib (973.1) <9BC523A3-E167-3F6C-8CAE-0F3EBA671791> /usr/lib/objc/libobjcMsgSend6.dylib
       0x1c3e40000 -        0x1c3e40f2f  libobjcMsgSend7.dylib (973.1) <248B7BCE-5B4C-34C7-A340-43D5228628C5> /usr/lib/objc/libobjcMsgSend7.dylib
       0x1cbe40000 -        0x1cbe40f2f  libobjcMsgSend8.dylib (973.1) <3E041BAD-A8E8-3069-B741-78CD1A45B176> /usr/lib/objc/libobjcMsgSend8.dylib
       0x1d3e40000 -        0x1d3e40f2f  libobjcMsgSend9.dylib (973.1) <34A67969-21A0-39D6-BB81-8FDA5A2409DB> /usr/lib/objc/libobjcMsgSend9.dylib
       0x1dbe40000 -        0x1dbe40f2f  libobjcMsgSend10.dylib (973.1) <678186C0-8EAD-3B35-8CBB-00285B41E4A0> /usr/lib/objc/libobjcMsgSend10.dylib
       0x1e3e40000 -        0x1e3e40f2f  libobjcMsgSend11.dylib (973.1) <E05CB08C-E956-36FA-8967-AE8E346A8D2C> /usr/lib/objc/libobjcMsgSend11.dylib
       0x20be40000 -        0x20be40f2f  libobjcMsgSend12.dylib (973.1) <10AB03AA-FF1F-3FDC-9DFB-BFC40042C501> /usr/lib/objc/libobjcMsgSend12.dylib
       0x213e40000 -        0x213e40f2f  libobjcMsgSend13.dylib (973.1) <ABF53427-FA6F-3D0D-8F9D-7AD795CA5C92> /usr/lib/objc/libobjcMsgSend13.dylib
       0x21be40000 -        0x21be40f2f  libobjcMsgSend14.dylib (973.1) <9A844C46-A6DA-34D4-8EBF-2AD775C30684> /usr/lib/objc/libobjcMsgSend14.dylib
       0x223e40000 -        0x223e40f2f  libobjcMsgSend15.dylib (973.1) <7C995666-2B2D-3284-AA0A-EBF7C922838E> /usr/lib/objc/libobjcMsgSend15.dylib
       0x22be40000 -        0x22be40f2f  libobjcMsgSend16.dylib (973.1) <B6C0E14B-53AE-3E22-9ED5-1729C49F46F2> /usr/lib/objc/libobjcMsgSend16.dylib
       0x233e40000 -        0x233e40f2f  libobjcMsgSend17.dylib (973.1) <07B4CF85-251B-301B-832B-20B315A59E19> /usr/lib/objc/libobjcMsgSend17.dylib
       0x23be40000 -        0x23be40f2f  libobjcMsgSend18.dylib (973.1) <43E575B7-04DB-3999-A633-1A3B638BA6E3> /usr/lib/objc/libobjcMsgSend18.dylib
       0x243e40000 -        0x243e40f2f  libobjcMsgSend19.dylib (973.1) <736F4D85-76F7-3B28-8D87-C07E8F7A0EF4> /usr/lib/objc/libobjcMsgSend19.dylib
       0x24be40000 -        0x24be40f2f  libobjcMsgSend20.dylib (973.1) <74E67C8B-6BCA-3184-A18E-A97F370052C6> /usr/lib/objc/libobjcMsgSend20.dylib
       0x253e40000 -        0x253e40f2f  libobjcMsgSend21.dylib (973.1) <CC0D732F-98E7-3888-9E15-70984DA2FB04> /usr/lib/objc/libobjcMsgSend21.dylib
       0x25be40000 -        0x25be40f2f  libobjcMsgSend22.dylib (973.1) <85A60286-5DE3-32BA-B18C-2A498B065C88> /usr/lib/objc/libobjcMsgSend22.dylib
       0x263e40000 -        0x263e40f2f  libobjcMsgSend23.dylib (973.1) <5452A0D2-6B19-39BE-ADDD-80B7BCDE3A98> /usr/lib/objc/libobjcMsgSend23.dylib
       0x26be40000 -        0x26be40f2f  libobjcMsgSend24.dylib (973.1) <94BBF2D6-722B-350D-8557-4D25A8E8D53A> /usr/lib/objc/libobjcMsgSend24.dylib
       0x273e40000 -        0x273e40f2f  libobjcMsgSend25.dylib (973.1) <35481387-5A8E-3AE4-86A6-94CEB3CC8726> /usr/lib/objc/libobjcMsgSend25.dylib
       0x28be40000 -        0x28be40f2f  libobjcMsgSend26.dylib (973.1) <9E0C8664-E7F4-39D1-AAFC-BD92B255E4E8> /usr/lib/objc/libobjcMsgSend26.dylib
       0x293e40000 -        0x293e40f2f  libobjcMsgSend27.dylib (973.1) <FD424935-55A9-3650-955A-EED3441A1D19> /usr/lib/objc/libobjcMsgSend27.dylib
       0x29be40000 -        0x29be40f2f  libobjcMsgSend28.dylib (973.1) <09BA7B97-7DF7-3C7F-932A-B6847662FC49> /usr/lib/objc/libobjcMsgSend28.dylib
       0x2a3e40000 -        0x2a3e40f2f  libobjcMsgSend29.dylib (973.1) <36D5BA3F-2139-30B0-8558-556764BE9813> /usr/lib/objc/libobjcMsgSend29.dylib
       0x2abe40000 -        0x2abe40f2f  libobjcMsgSend30.dylib (973.1) <9F05564A-9D12-372C-98FC-E9F0E6BE4F04> /usr/lib/objc/libobjcMsgSend30.dylib
       0x2b0b5a000 -        0x2b0b60fe5  libRosetta.dylib (385) <E359944B-D230-33F9-A04E-0C3B17C3326E> /usr/lib/libRosetta.dylib
       0x2b1549000 -        0x2b154c75b  libsystem_darwindirectory.dylib (129.0.1) <61264923-2AA5-3658-B8C4-550C71E9D4B3> /usr/lib/system/libsystem_darwindirectory.dylib
       0x2b154d000 -        0x2b1557d9b  libsystem_eligibility.dylib (446.1.3) <EDDE8E9C-A2CF-3931-BBB3-321CB852EB30> /usr/lib/system/libsystem_eligibility.dylib
       0x2b1558000 -        0x2b156142b  libsystem_sanitizers.dylib (32) <7138ED99-7AA0-34EA-B35B-20EF6ADB1EED> /usr/lib/system/libsystem_sanitizers.dylib
       0x2b1562000 -        0x2b1562a13  libsystem_trial.dylib (511) <6AE48824-EC44-3A8C-B501-BE57DBE892E7> /usr/lib/system/libsystem_trial.dylib
       0x2b3e40000 -        0x2b3e40f2f  libobjcMsgSend31.dylib (973.1) <0985E20F-78C3-3466-A2B2-DBB95F7104A3> /usr/lib/objc/libobjcMsgSend31.dylib
       0x2bbe40000 -        0x2bbe40f2f  libobjcMsgSend32.dylib (973.1) <0D309D58-D576-3E5D-AD4B-6D55AB491702> /usr/lib/objc/libobjcMsgSend32.dylib
       0x2c3e40000 -        0x2c3e40f2f  libobjcMsgSend33.dylib (973.1) <346E0484-48FA-369B-8A64-93B5F5341CFE> /usr/lib/objc/libobjcMsgSend33.dylib
       0x2cbe40000 -        0x2cbe40f2f  libobjcMsgSend34.dylib (973.1) <6A31F809-BCBE-3E01-A367-E91FDACCE324> /usr/lib/objc/libobjcMsgSend34.dylib
