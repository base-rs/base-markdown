Analysis of sampling baseline (pid 9901) every 1 millisecond
Process:         baseline [9901]
Path:            /private/tmp/*/baseline
Load Address:    0x100b38000
Identifier:      baseline
Version:         0
Code Type:       ARM64
Platform:        macOS
Parent Process:  python3.13 [9888]
Target Type:     live task

Date/Time:       2026-10-25 11:29:25.109 +1300
Launch Time:     2026-10-25 11:29:24.573 +1300
OS Version:      macOS 27.0.1 (26A434)
Report Version:  7
Analysis Tool:   /usr/bin/sample

Physical footprint:         1792K
Physical footprint (peak):  1792K
Idle exit:                  untracked
----

Call graph:
    2473 Thread_43524498   DispatchQueue_1: com.apple.main-thread  (serial)
      2473 start  (in dyld) + 6688  [0x1842f7e80]
        2473 main  (in baseline) + 52  [0x100b5bc20]
          2473 _RNvNtCs1coMeGJvsuS_3std2rt19lang_start_internal  (in baseline) + 936  [0x100c4a030]
            2473 _RNCINvNtCs1coMeGJvsuS_3std2rt10lang_startuE0CseVgRDH8534i_19markdown_comparison  (in baseline) + 16  [0x100b6e6d4]
              2473 _RINvNtNtCs1coMeGJvsuS_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECseVgRDH8534i_19markdown_comparison  (in baseline) + 12  [0x100b6f000]
                2446 _RNvCseVgRDH8534i_19markdown_comparison4main  (in baseline) + 1380  [0x100b5a264]
                + 2370 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 332  [0x100b56fc4]
                + ! 2366 _RNvMNtCs8seiryzelau_13core_markdown12event_parserNtB2_11EventParser7prepare  (in baseline) + 44  [0x100c1e65c]
                + ! : 658 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 2008,1000,...  [0x100c0b810,0x100c0b420,...]
                + ! : 352 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6664  [0x100c0ca40]
                + ! : | 315 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 76  [0x100c0a5a8]
                + ! : | + 310 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4NodeE8grow_oneBQ_  (in baseline) + 60  [0x100c6d0e8]
                + ! : | + ! 306 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x100c6d3c4]
                + ! : | + ! : 286 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | + ! : | 282 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | + ! : | + 131 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | + ! : | + ! 130 _platform_memmove  (in libsystem_platform.dylib) + 180,0,...  [0x1846d7e14,0x1846d7d60,...]
                + ! : | + ! : | + ! 1 DYLD-STUB$$_platform_memmove  (in libsystem_malloc.dylib) + 12  [0x18450a5ac]
                + ! : | + ! : | + 104 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | + ! : | + ! 80 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | + ! : | + ! : 79 mach_absolute_time  (in libsystem_kernel.dylib) + 108,16,...  [0x1846890f8,0x18468909c,...]
                + ! : | + ! : | + ! : 1 DYLD-STUB$$mach_absolute_time  (in libsystem_malloc.dylib) + 12  [0x18450a8ac]
                + ! : | + ! : | + ! 13 _xzm_free  (in libsystem_malloc.dylib) + 28,80,...  [0x1844ec71c,0x1844ec750,...]
                + ! : | + ! : | + ! 11 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 124,96,...  [0x1844ed700,0x1844ed6e4,...]
                + ! : | + ! : | + 26 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | + ! : | + ! 12 _xzm_malloc  (in libsystem_malloc.dylib) + 108,208,...  [0x1844e7e60,0x1844e7ec4,...]
                + ! : | + ! : | + ! 7 _xzm_xzone_malloc_small_freelist  (in libsystem_malloc.dylib) + 92,252,...  [0x1844e8ea8,0x1844e8f48,...]
                + ! : | + ! : | + ! 7 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 672,16,...  [0x1844e8cec,0x1844e8a5c,...]
                + ! : | + ! : | + 14 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 400,268,...  [0x1844e51a0,0x1844e511c,...]
                + ! : | + ! : | + 4 _xzm_free  (in libsystem_malloc.dylib) + 968,972  [0x1844ecac8,0x1844ecacc]
                + ! : | + ! : | + 3 default_zone_realloc  (in libsystem_malloc.dylib) + 32  [0x1844b8d18]
                + ! : | + ! : | 4 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 24,40,...  [0x1844f4ab0,0x1844f4ac0,...]
                + ! : | + ! : 8 _realloc  (in libsystem_malloc.dylib) + 20,248,...  [0x1844f51a4,0x1844f5288,...]
                + ! : | + ! : 7 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | + ! : | 7 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 0,24,...  [0x1844e4304,0x1844e431c,...]
                + ! : | + ! : 3 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 708  [0x1844e45c8]
                + ! : | + ! : 1 DYLD-STUB$$realloc  (in baseline) + 4  [0x100c73298]
                + ! : | + ! : 1 _RNvCsjVqd8RsBhQu_7___rustc13___rdl_realloc  (in baseline) + 0  [0x100c3cb28]
                + ! : | + ! 4 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 40,12  [0x100c6d390,0x100c6d374]
                + ! : | + 4 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4NodeE8grow_oneBQ_  (in baseline) + 0,20,...  [0x100c6d0ac,0x100c6d0c0,...]
                + ! : | + 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 168  [0x100c6d410]
                + ! : | 37 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 116,60,...  [0x100c0a5d0,0x100c0a598,...]
                + ! : 183 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 4640  [0x100c0c258]
                + ! : | 97 _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in baseline) + 64  [0x100c28bf0]
                + ! : | + 73 _RNvXNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fnINtB2_6FromFnNCNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB17_7Builder20definition_fragments0ENtNtNtB6_6traits8iterator8Iterator4nextB19_  (in baseline) + 280  [0x100c2c078]
                + ! : | + ! 73 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 280,292,...  [0x100c2541c,0x100c25428,...]
                + ! : | + 23 _RNvXNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fnINtB2_6FromFnNCNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB17_7Builder20definition_fragments0ENtNtNtB6_6traits8iterator8Iterator4nextB19_  (in baseline) + 56,4,...  [0x100c2bf98,0x100c2bf64,...]
                + ! : | + 1 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 184  [0x100c253bc]
                + ! : | 80 _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in baseline) + 636,704,...  [0x100c28e2c,0x100c28e70,...]
                + ! : | 6 _RNvXNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fnINtB2_6FromFnNCNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB17_7Builder20definition_fragments0ENtNtNtB6_6traits8iterator8Iterator4nextB19_  (in baseline) + 684,688,...  [0x100c2c20c,0x100c2c210,...]
                + ! : 165 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6048  [0x100c0c7d8]
                + ! : | 151 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10table_head  (in baseline) + 36  [0x100c09b64]
                + ! : | + 66 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 72  [0x100c0a0a8]
                + ! : | + ! 66 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 272,120,...  [0x100c25414,0x100c2537c,...]
                + ! : | + 40 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 40,112,...  [0x100c0a088,0x100c0a0d0,...]
                + ! : | + 28 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 112  [0x100c0a0d0]
                + ! : | + ! 28 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 12,140,...  [0x100c095c4,0x100c09644,...]
                + ! : | + 10 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 644  [0x100c0983c]
                + ! : | + 7 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 400  [0x100c0a1f0]
                + ! : | +   6 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 20,180,...  [0x100c24a04,0x100c24aa4,...]
                + ! : | +   1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 492  [0x100c24bdc]
                + ! : | +     1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline) + 260  [0x100c2498c]
                + ! : | 9 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 436  [0x100c0a214]
                + ! : | 5 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10table_head  (in baseline) + 8,36,...  [0x100c09b48,0x100c09b64,...]
                + ! : 120 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6620  [0x100c0ca14]
                + ! : | 120 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 272,120,...  [0x100c25414,0x100c2537c,...]
                + ! : 111 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 7124  [0x100c0cc0c]
                + ! : | 53 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 72  [0x100c0a0a8]
                + ! : | + 53 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 272,156,...  [0x100c25414,0x100c253a0,...]
                + ! : | 21 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 112  [0x100c0a0d0]
                + ! : | + 21 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 136,12,...  [0x100c09640,0x100c095c4,...]
                + ! : | 20 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 72,360,...  [0x100c0a0a8,0x100c0a1c8,...]
                + ! : | 13 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 400  [0x100c0a1f0]
                + ! : | + 9 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 64,180,...  [0x100c24a30,0x100c24aa4,...]
                + ! : | + 4 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 492  [0x100c24bdc]
                + ! : | +   4 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline) + 80,8,...  [0x100c248d8,0x100c24890,...]
                + ! : | 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 644  [0x100c0983c]
                + ! : | 1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 672  [0x100c24c90]
                + ! : 96 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 8428  [0x100c0d124]
                + ! : | 87 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser4htmlNtB2_4Html6closed  (in baseline) + 1476  [0x100c17aa0]
                + ! : | + 84 _RNvNtCsglYb6d7nGNF_6memchr6memmem4find  (in baseline) + 184,252,...  [0x100c17ef8,0x100c17f3c,...]
                + ! : | + 3 _RNvNtCsglYb6d7nGNF_6memchr6memmem4find  (in baseline) + 232  [0x100c17f28]
                + ! : | +   3 _RNvNtNtNtCsglYb6d7nGNF_6memchr4arch3all9rabinkarp12is_equal_raw  (in baseline) + 0,60  [0x100c6e454,0x100c6e490]
                + ! : | 5 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser4htmlNtB2_4Html6closed  (in baseline) + 1748,0,...  [0x100c17bb0,0x100c174dc,...]
                + ! : | 4 _RNvNtCsglYb6d7nGNF_6memchr6memmem4find  (in baseline) + 764  [0x100c1813c]
                + ! : 63 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 192,184,...  [0x100c0a61c,0x100c0a614,...]
                + ! : 60 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5068  [0x100c0c404]
                + ! : | 16 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 948,1260,...  [0x100c0aa00,0x100c0ab38,...]
                + ! : | 13 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 948  [0x100c0aa00]
                + ! : | + 13 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners23scan_closing_code_fence  (in baseline) + 72,0,...  [0x100c257d4,0x100c2578c,...]
                + ! : | 12 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 276  [0x100c0a760]
                + ! : | + 9 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in baseline) + 60  [0x100c6d084]
                + ! : | + ! 7 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 120  [0x100c6d3e0]
                + ! : | + ! : 3 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 92,260,...  [0x1844ef9ec,0x1844efa94,...]
                + ! : | + ! : 2 _malloc_zone_malloc  (in libsystem_malloc.dylib) + 12,120  [0x1844f44fc,0x1844f4568]
                + ! : | + ! : 1 DYLD-STUB$$malloc  (in baseline) + 4  [0x100c73154]
                + ! : | + ! : 1 _RNvCsjVqd8RsBhQu_7___rustc11___rdl_alloc  (in baseline) + 0  [0x100c3cab0]
                + ! : | + ! 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 108  [0x100c6d3d4]
                + ! : | + ! : 1 _RNvCsjVqd8RsBhQu_7___rustc35___rust_no_alloc_shim_is_unstable_v2  (in baseline) + 0  [0x100b721f8]
                + ! : | + ! 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 40  [0x100c6d390]
                + ! : | + 3 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 168  [0x100c6d410]
                + ! : | 11 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 564  [0x100c0a880]
                + ! : | + 11 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 68,76,...  [0x100c095fc,0x100c09604,...]
                + ! : | 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 144  [0x100c0a6dc]
                + ! : | + 3 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 180,120  [0x100c253b8,0x100c2537c]
                + ! : | 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 972  [0x100c0aa18]
                + ! : | + 3 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 88,216  [0x100c2535c,0x100c253dc]
                + ! : | 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 192  [0x100c0a61c]
                + ! : | 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 1020  [0x100c0aa48]
                + ! : |   1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 116  [0x100c0a5d0]
                + ! : 54 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 9276  [0x100c0d474]
                + ! : | 51 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown8document6NodeIdE8grow_oneBQ_  (in baseline) + 60  [0x100c6d340]
                + ! : | + 48 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x100c6d3c4]
                + ! : | + ! 41 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | + ! : 38 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | + ! : | 13 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | + ! : | + 13 _xzm_malloc  (in libsystem_malloc.dylib) + 108,208,...  [0x1844e7e60,0x1844e7ec4,...]
                + ! : | + ! : | 11 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | + ! : | + 7 _platform_memmove  (in libsystem_platform.dylib) + 428,420,...  [0x1846d7f0c,0x1846d7f04,...]
                + ! : | + ! : | + 4 DYLD-STUB$$_platform_memmove  (in libsystem_malloc.dylib) + 12  [0x18450a5ac]
                + ! : | + ! : | 8 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 320,1128,...  [0x1844e5150,0x1844e5478,...]
                + ! : | + ! : | 3 default_zone_realloc  (in libsystem_malloc.dylib) + 32  [0x1844b8d18]
                + ! : | + ! : | 3 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | + ! : |   3 _xzm_free  (in libsystem_malloc.dylib) + 80,284  [0x1844ec750,0x1844ec81c]
                + ! : | + ! : 3 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 48,72,...  [0x1844f4ac8,0x1844f4ae0,...]
                + ! : | + ! 3 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 208,220  [0x1844f4b68,0x1844f4b74]
                + ! : | + ! 2 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | + ! : 2 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 188,496  [0x1844e43c0,0x1844e44f4]
                + ! : | + ! 1 _realloc  (in libsystem_malloc.dylib) + 248  [0x1844f5288]
                + ! : | + ! 1 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 708  [0x1844e45c8]
                + ! : | + 3 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 36,64  [0x100c6d38c,0x100c6d3a8]
                + ! : | 3 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown8document6NodeIdE8grow_oneBQ_  (in baseline) + 68,60  [0x100c6d348,0x100c6d340]
                + ! : 53 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6712  [0x100c0ca70]
                + ! : | 53 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 12,136,...  [0x100c095c4,0x100c09640,...]
                + ! : 44 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 656  [0x100c0b2c8]
                + ! : | 44 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 12,4,...  [0x100c095c4,0x100c095bc,...]
                + ! : 40 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 8160  [0x100c0d018]
                + ! : | 40 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 120,0,...  [0x100c2537c,0x100c25304,...]
                + ! : 32 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6516  [0x100c0c9ac]
                + ! : | 32 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 20,116,...  [0x100c0a570,0x100c0a5d0,...]
                + ! : 30 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6488  [0x100c0c990]
                + ! : | 30 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline) + 24,244,...  [0x100c09e08,0x100c09ee4,...]
                + ! : 24 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5692  [0x100c0c674]
                + ! : | 24 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 120,88,...  [0x100c2537c,0x100c2535c,...]
                + ! : 22 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 1820  [0x100c0b754]
                + ! : | 14 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 148,20,...  [0x100c24a84,0x100c24a04,...]
                + ! : | 8 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 492  [0x100c24bdc]
                + ! : |   8 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline) + 8,104,...  [0x100c24890,0x100c248f0,...]
                + ! : 20 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 644,648  [0x100c0983c,0x100c09840]
                + ! : 20 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5660  [0x100c0c654]
                + ! : | 20 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline) + 244,24,...  [0x100c09ee4,0x100c09e08,...]
                + ! : 20 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 9244  [0x100c0d454]
                + ! : | 20 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 116,20,...  [0x100c0a5d0,0x100c0a570,...]
                + ! : 20 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 9336  [0x100c0d4b0]
                + ! : | 20 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 20,116,...  [0x100c0a570,0x100c0a5d0,...]
                + ! : 15 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 7224  [0x100c0cc70]
                + ! : | 9 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15list_interrupts  (in baseline) + 72  [0x100c09f7c]
                + ! : | + 6 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 148,20,...  [0x100c24a84,0x100c24a04,...]
                + ! : | + 3 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 492  [0x100c24bdc]
                + ! : | +   3 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline) + 8,80,...  [0x100c24890,0x100c248d8,...]
                + ! : | 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15list_interrupts  (in baseline) + 48,72,...  [0x100c09f64,0x100c09f7c,...]
                + ! : | 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10interrupts  (in baseline) + 20,388  [0x100c09884,0x100c099f4]
                + ! : 14 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 8468  [0x100c0d14c]
                + ! : | 14 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 12,68,...  [0x100c095c4,0x100c095fc,...]
                + ! : 11 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5412  [0x100c0c55c]
                + ! : | 11 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 20,60,...  [0x100c0a570,0x100c0a598,...]
                + ! : 10 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5016  [0x100c0c3d0]
                + ! : | 6 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners15scan_code_fence  (in baseline) + 152,164,...  [0x100c25594,0x100c255a0,...]
                + ! : | 4 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners15scan_code_fence  (in baseline) + 120  [0x100c25574]
                + ! : |   4 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 120,156,...  [0x100c2537c,0x100c253a0,...]
                + ! : 10 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5352  [0x100c0c520]
                + ! : | 10 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline) + 24,244,...  [0x100c09e08,0x100c09ee4,...]
                + ! : 10 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 7264  [0x100c0cc98]
                + ! : | 10 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10interrupts  (in baseline) + 20,52,...  [0x100c09884,0x100c098a4,...]
                + ! : 9 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10table_head  (in baseline) + 356,364  [0x100c09ca4,0x100c09cac]
                + ! : 9 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 7196  [0x100c0cc54]
                + ! : | 9 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners19scan_setext_heading  (in baseline) + 112,8,...  [0x100c2569c,0x100c25634,...]
                + ! : 9 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 10328  [0x100c0d890]
                + ! : | 9 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_html  (in baseline) + 184,12,...  [0x100c09d8c,0x100c09ce0,...]
                + ! : 8 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 128  [0x100c0b0b8]
                + ! : | 6 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 404,28,...  [0x1844e8be0,0x1844e8a68,...]
                + ! : | 1 _malloc_zone_malloc  (in libsystem_malloc.dylib) + 80  [0x1844f4540]
                + ! : | 1 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 432  [0x1844efb40]
                + ! : 8 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 7308  [0x100c0ccc4]
                + ! : | 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10interrupts  (in baseline) + 4,20,...  [0x100c09874,0x100c09884,...]
                + ! : | 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15list_interrupts  (in baseline) + 72  [0x100c09f7c]
                + ! : |   2 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 492  [0x100c24bdc]
                + ! : |   ! 2 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline) + 48,84  [0x100c248b8,0x100c248dc]
                + ! : |   2 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 0,148  [0x100c249f0,0x100c24a84]
                + ! : 8 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 8384  [0x100c0d0f8]
                + ! : | 8 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 116,20,...  [0x100c0a5d0,0x100c0a570,...]
                + ! : 7 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 10484  [0x100c0d92c]
                + ! : | 2 _RINvMs_NtCs3vUkWdPtNor_5alloc3vecINtB5_3VecjE8dedup_byNCNvMNtCs8seiryzelau_13core_markdown11definitionsNtBV_11Definitions6finishs1_0EBX_  (in baseline) + 328,344  [0x100c1bba0,0x100c1bbb0]
                + ! : | 2 _RNvMNtCs8seiryzelau_13core_markdown11definitionsNtB2_11Definitions6finish  (in baseline) + 32,284  [0x100c20040,0x100c2013c]
                + ! : | 1 _RINvMs_NtCs3vUkWdPtNor_5alloc3vecINtB5_3VecjE8dedup_byNCNvMNtCs8seiryzelau_13core_markdown11definitionsNtBV_11Definitions6finishs_0EBX_  (in baseline) + 344  [0x100c1bd7c]
                + ! : | 1 _RNvMNtCs8seiryzelau_13core_markdown11definitionsNtB2_11Definitions6finish  (in baseline) + 284  [0x100c2013c]
                + ! : | + 1 _RINvMs_NtCs3vUkWdPtNor_5alloc3vecINtB5_3VecjE8dedup_byNCNvMNtCs8seiryzelau_13core_markdown11definitionsNtBV_11Definitions6finishs_0EBX_  (in baseline) + 36  [0x100c1bc48]
                + ! : | 1 _RNvMNtCs8seiryzelau_13core_markdown11definitionsNtB2_11Definitions6finish  (in baseline) + 604  [0x100c2027c]
                + ! : |   1 _RINvMs_NtCs3vUkWdPtNor_5alloc3vecINtB5_3VecjE8dedup_byNCNvMNtCs8seiryzelau_13core_markdown11definitionsNtBV_11Definitions6finishs1_0EBX_  (in baseline) + 36  [0x100c1ba7c]
                + ! : 6 _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in baseline) + 3204,3208,...  [0x100c29834,0x100c29838,...]
                + ! : 6 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 2728  [0x100c0bae0]
                + ! : | 6 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 12,4,...  [0x100c0a568,0x100c0a560,...]
                + ! : 5 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser4htmlNtB2_4Html5start  (in baseline) + 1568  [0x100c173c4]
                + ! : 5 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 164  [0x100c0b0dc]
                + ! : | 3 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 280,320,...  [0x1844efaa8,0x1844efad0,...]
                + ! : | 1 _RNvCsjVqd8RsBhQu_7___rustc11___rdl_alloc  (in baseline) + 0  [0x100c3cab0]
                + ! : | 1 _malloc_zone_malloc  (in libsystem_malloc.dylib) + 44  [0x1844f451c]
                + ! : 5 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5044  [0x100c0c3ec]
                + ! : | 5 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline) + 24,244  [0x100c09e08,0x100c09ee4]
                + ! : 4 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5324  [0x100c0c504]
                + ! : | 4 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser4htmlNtB2_4Html5start  (in baseline) + 16,0,...  [0x100c16db4,0x100c16da4,...]
                + ! : 4 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 10564  [0x100c0d97c]
                + ! : | 2 _xzm_free_tc  (in libsystem_malloc.dylib) + 48,160  [0x1844f18a8,0x1844f1918]
                + ! : | 1 DYLD-STUB$$free  (in baseline) + 4  [0x100c73124]
                + ! : | 1 _free  (in libsystem_malloc.dylib) + 4  [0x1844f5114]
                + ! : 3 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 672  [0x100c24c90]
                + ! : 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 436  [0x100c0a214]
                + ! : 3 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 2636  [0x100c0ba84]
                + ! : | 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 116,20  [0x100c0a5d0,0x100c0a570]
                + ! : 3 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners15scan_code_fence  (in baseline) + 236,232  [0x100c255e8,0x100c255e4]
                + ! : 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline) + 248  [0x100c09ee8]
                + ! : 1 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 152  [0x100c0b0d0]
                + ! : | 1 _RNvCsjVqd8RsBhQu_7___rustc35___rust_no_alloc_shim_is_unstable_v2  (in baseline) + 0  [0x100b721f8]
                + ! : 1 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 2568  [0x100c0ba40]
                + ! : | 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline) + 244  [0x100c09ee4]
                + ! : 1 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 184  [0x100c253bc]
                + ! 3 _RNvMNtCs8seiryzelau_13core_markdown12event_parserNtB2_11EventParser7prepare  (in baseline) + 164,216,...  [0x100c1e6d4,0x100c1e708,...]
                + ! 1 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 10608  [0x100c0d9a8]
                + 46 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 9244  [0x100b59294]
                + ! 41 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown12event_parser11EventParserECseVgRDH8534i_19markdown_comparison  (in baseline) + 52  [0x100b5627c]
                + ! : 22 _xzm_xzone_free_freelist  (in libsystem_malloc.dylib) + 720  [0x1844edef8]
                + ! : | 20 mach_absolute_time  (in libsystem_kernel.dylib) + 108,16,...  [0x1846890f8,0x18468909c,...]
                + ! : | 2 DYLD-STUB$$mach_absolute_time  (in libsystem_malloc.dylib) + 12  [0x18450a8ac]
                + ! : 9 _xzm_free_outlined  (in libsystem_malloc.dylib) + 76,192,...  [0x1844ecef8,0x1844ecf6c,...]
                + ! : 5 _xzm_xzone_free_freelist  (in libsystem_malloc.dylib) + 80,348  [0x1844edc78,0x1844edd84]
                + ! : 3 DYLD-STUB$$free  (in baseline) + 0  [0x100c73120]
                + ! : 2 _free  (in libsystem_malloc.dylib) + 36,76  [0x1844f5134,0x1844f515c]
                + ! 2 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown12event_parser11EventParserECseVgRDH8534i_19markdown_comparison  (in baseline) + 80  [0x100b56298]
                + ! : 2 _xzm_free_tc  (in libsystem_malloc.dylib) + 264,332  [0x1844f1980,0x1844f19c4]
                + ! 2 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown13inline_parser12InlineParserECseVgRDH8534i_19markdown_comparison  (in baseline) + 4,264  [0x100b56434,0x100b56538]
                + ! 1 _xzm_free_outlined  (in libsystem_malloc.dylib) + 716  [0x1844ed178]
                + 10 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 360  [0x100b56fe0]
                + ! 10 _platform_memmove  (in libsystem_platform.dylib) + 180,144,...  [0x1846d7e14,0x1846d7df0,...]
                + 10 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 9236  [0x100b5928c]
                + ! 10 _platform_memmove  (in libsystem_platform.dylib) + 180,204  [0x1846d7e14,0x1846d7e2c]
                + 8 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 332,360,...  [0x100b56fc4,0x100b56fe0,...]
                + 1 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown13inline_parser12InlineParserECseVgRDH8534i_19markdown_comparison  (in baseline) + 328  [0x100b56578]
                + 1 _RNvCseVgRDH8534i_19markdown_comparison4main  (in baseline) + 1400  [0x100b5a278]
                26 _RNvCseVgRDH8534i_19markdown_comparison4main  (in baseline) + 1348  [0x100b5a244]
                + 23 _RNvMNtCs1coMeGJvsuS_3std4timeNtB2_7Instant7elapsed  (in baseline) + 28  [0x100c3cd9c]
                + ! 23 _RNvMNtNtNtNtCs1coMeGJvsuS_3std3sys3pal4unix4timeNtB2_8Timespec3now  (in baseline) + 24  [0x100c3d6bc]
                + !   19 clock_gettime  (in libsystem_c.dylib) + 60  [0x184564100]
                + !   : 13 clock_gettime_nsec_np  (in libsystem_c.dylib) + 384  [0x1845561ac]
                + !   : | 13 mach_absolute_time  (in libsystem_kernel.dylib) + 108,112  [0x1846890f8,0x1846890fc]
                + !   : 4 clock_gettime_nsec_np  (in libsystem_c.dylib) + 240,8,...  [0x18455611c,0x184556034,...]
                + !   : 2 clock_gettime_nsec_np  (in libsystem_c.dylib) + 240  [0x18455611c]
                + !   :   2 mach_timebase_info  (in libsystem_kernel.dylib) + 4,28  [0x184688fbc,0x184688fd4]
                + !   3 clock_gettime  (in libsystem_c.dylib) + 64,56  [0x184564104,0x1845640fc]
                + !   1 DYLD-STUB$$clock_gettime  (in baseline) + 0  [0x100c7309c]
                + 2 _RNvMNtCs1coMeGJvsuS_3std4timeNtB2_7Instant7elapsed  (in baseline) + 68  [0x100c3cdc4]
                + ! 2 _RNvMNtNtNtNtCs1coMeGJvsuS_3std3sys3pal4unix4timeNtB2_8Timespec12sub_timespec  (in baseline) + 60  [0x100c3d5fc]
                + 1 _RNvMNtCs1coMeGJvsuS_3std4timeNtB2_7Instant7elapsed  (in baseline) + 92  [0x100c3cddc]
                1 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 9352  [0x100b59300]

Total number in stack (recursive counted multiple, when >=5):
        11       _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 0  [0x100c0a55c]
        11       _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 0  [0x100c25304]
        9       _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 0  [0x100c095b8]
        7       _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 0  [0x100c249f0]
        6       _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline) + 0  [0x100c09df0]
        5       _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline) + 0  [0x100c24888]
        5       _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 492  [0x100c24bdc]
        5       _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 0  [0x100c6d368]

Sort by top of stack, same collapsed (when >= 5):
        _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline)        659
        _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline)        388
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline)        204
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline)        202
        _platform_memmove  (in libsystem_platform.dylib)        157
        mach_absolute_time  (in libsystem_kernel.dylib)        112
        _RNvNtCsglYb6d7nGNF_6memchr6memmem4find  (in baseline)        88
        _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in baseline)        86
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline)        72
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline)        67
        _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline)        41
        _RNvXNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fnINtB2_6FromFnNCNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB17_7Builder20definition_fragments0ENtNtNtB6_6traits8iterator8Iterator4nextB19_  (in baseline)        29
        _xzm_malloc  (in libsystem_malloc.dylib)        25
        xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib)        22
        _xzm_free  (in libsystem_malloc.dylib)        20
        _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline)        18
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10interrupts  (in baseline)        16
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline)        16
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10table_head  (in baseline)        14
        _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners23scan_closing_code_fence  (in baseline)        13
        _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib)        13
        xzm_malloc_zone_size  (in libsystem_malloc.dylib)        13
        _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline)        12
        __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib)        11
        _malloc_zone_realloc  (in libsystem_malloc.dylib)        10
        _xzm_free_outlined  (in libsystem_malloc.dylib)        10
        _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline)        9
        _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser4htmlNtB2_4Html5start  (in baseline)        9
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_html  (in baseline)        9
        _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners15scan_code_fence  (in baseline)        9
        _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners19scan_setext_heading  (in baseline)        9
        _realloc  (in libsystem_malloc.dylib)        9
        _xzm_malloc_tc  (in libsystem_malloc.dylib)        7
        _xzm_xzone_malloc_small_freelist  (in libsystem_malloc.dylib)        7
        default_zone_realloc  (in libsystem_malloc.dylib)        6
        DYLD-STUB$$_platform_memmove  (in libsystem_malloc.dylib)        5
        _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser4htmlNtB2_4Html6closed  (in baseline)        5
        _xzm_xzone_free_freelist  (in libsystem_malloc.dylib)        5

Binary Images:
       0x100b38000 -        0x100cfe66f +baseline (0) <769F5531-DB9E-306E-999A-643EE6A203C3> /tmp/*/baseline
       0x184244000 -        0x1842935f7  libobjc.A.dylib (973.1) <C0680DF6-9900-3C29-A071-95A031686EF8> /usr/lib/libobjc.A.dylib
       0x184294000 -        0x18429e23f  libsharedcache.dylib (0) <BBF95357-BEBF-3D89-8900-2BBB14A667C5> /usr/lib/libsharedcache.dylib
       0x18429f000 -        0x1842c5d3b  libdyld.dylib (27062) <62863BCA-DD60-3D32-A9DB-89099BA6F3D7> /usr/lib/system/libdyld.dylib
       0x1842c6000 -        0x1843856e3  dyld (1.0.0 - 27062) <D341DDCB-7969-3A9C-8E03-0CF4751398A9> /usr/lib/dyld
       0x184386000 -        0x18438901f  libsystem_blocks.dylib (98.1) <6F304731-D95D-3501-B4AD-F2934F7F2446> /usr/lib/system/libsystem_blocks.dylib
       0x18438a000 -        0x1843df0df  libxpc.dylib (3298.1.1) <0791121F-B5FC-3F84-BF04-115E86D2D882> /usr/lib/system/libxpc.dylib
       0x1843e0000 -        0x1843ffc13  libsystem_trace.dylib (1966.1.1) <B48A8E3E-A12A-3342-8321-428B555E965E> /usr/lib/system/libsystem_trace.dylib
       0x184400000 -        0x1844b4f27  libcorecrypto.dylib (2109.0.22) <807AA6C9-5D8A-3CA5-B4CE-FACE5296EF6A> /usr/lib/system/libcorecrypto.dylib
       0x1844b5000 -        0x18450ac5f  libsystem_malloc.dylib (886.0.8) <2339CB57-FE5A-3154-A206-A76059C749EB> /usr/lib/system/libsystem_malloc.dylib
       0x18450b000 -        0x18455119f  libdispatch.dylib (1605.0.2) <022BF08F-0B3A-3225-9E65-16D1553CE90D> /usr/lib/system/libdispatch.dylib
       0x184552000 -        0x184554d2b  libsystem_featureflags.dylib (108) <20C1CAB2-1F13-3426-8146-9CAE9FF2A33D> /usr/lib/system/libsystem_featureflags.dylib
       0x184555000 -        0x1845d7ca3  libsystem_c.dylib (1786.0.3) <FBA7B23E-AA60-3A90-9AA4-A7A2E0AD63EE> /usr/lib/system/libsystem_c.dylib
       0x1845d8000 -        0x18466d033  libc++.1.dylib (2200.27) <1E9BA4AA-B5DA-3CF3-80AC-4B880049573F> /usr/lib/libc++.1.dylib
       0x18466e000 -        0x184687eff  libc++abi.dylib (2200.27) <A21743EE-6E1C-3E74-97EA-7AF793DE4BDF> /usr/lib/libc++abi.dylib
       0x184688000 -        0x1846c69ab  libsystem_kernel.dylib (13432.1.9) <F63BF418-8F75-34A4-AAF1-8CAF2B9B6A05> /usr/lib/system/libsystem_kernel.dylib
       0x1846c7000 -        0x1846d391b  libsystem_pthread.dylib (553.0.1) <5A1828C3-CBC2-3B85-BD07-C8ED10021A41> /usr/lib/system/libsystem_pthread.dylib
       0x1846d4000 -        0x1846dd4f3  libsystem_platform.dylib (402.0.1.0.1) <080E4444-A0FB-3913-9756-4E470015F32F> /usr/lib/system/libsystem_platform.dylib
       0x1846de000 -        0x18470c903  libsystem_info.dylib (603) <BC387AEB-1CEF-3513-92D7-D7F913596711> /usr/lib/system/libsystem_info.dylib
       0x188836000 -        0x18883fb13  libsystem_darwin.dylib (1786.0.3) <4E66C888-993C-3E6A-A8DA-A949C01C5B67> /usr/lib/system/libsystem_darwin.dylib
       0x188c90000 -        0x188ca1b8b  libsystem_notify.dylib (368) <58FD36D8-37A7-311C-80F2-8E64DD8710CF> /usr/lib/system/libsystem_notify.dylib
       0x18aded000 -        0x18ae07d93  libsystem_networkextension.dylib (2340.1.2) <22E1D190-486F-324F-ABA4-F36AB841BFE9> /usr/lib/system/libsystem_networkextension.dylib
       0x18ae95000 -        0x18aeac247  libsystem_asl.dylib (409) <B4D449B7-A821-3A9A-8019-E917B291F10A> /usr/lib/system/libsystem_asl.dylib
       0x18be40000 -        0x18be40f2f  libobjcMsgSend.dylib (973.1) <41179EDE-DC97-3BBE-8848-6400D12C1436> /usr/lib/objc/libobjcMsgSend.dylib
       0x18cf8c000 -        0x18cf93edf  libsystem_symptoms.dylib (2394.0.4) <60EE7884-9F4E-3184-A6AC-FA40A7A0297D> /usr/lib/system/libsystem_symptoms.dylib
       0x191324000 -        0x19135eaeb  libsystem_containermanager.dylib (833.0.8.0.1) <08A57205-555D-3792-8931-9D5B585AF326> /usr/lib/system/libsystem_containermanager.dylib
       0x192977000 -        0x19297b317  libsystem_configuration.dylib (1446) <F3EB66A7-7A24-3AE5-B6E8-9A37BB00F119> /usr/lib/system/libsystem_configuration.dylib
       0x19297c000 -        0x192982e03  libsystem_sandbox.dylib (3051.0.52) <1E892B56-092E-3832-BDE3-DCE356D7A4FA> /usr/lib/system/libsystem_sandbox.dylib
       0x193e40000 -        0x193e40f2f  libobjcMsgSend1.dylib (973.1) <B40D9B2A-E1EE-37ED-8004-711A1F263DE1> /usr/lib/objc/libobjcMsgSend1.dylib
       0x194560000 -        0x194562f93  libquarantine.dylib (217.0.4) <7FD4AE22-86EF-382B-83F5-ADF9336C1160> /usr/lib/system/libquarantine.dylib
       0x194c72000 -        0x194c781e7  libsystem_coreservices.dylib (203) <57248E07-11A5-3857-918E-4A3A63B69FE8> /usr/lib/system/libsystem_coreservices.dylib
       0x19523a000 -        0x195277b27  libsystem_m.dylib (3326.0.1) <A3FB340F-3ED5-30F4-8B64-9D5860F64D35> /usr/lib/system/libsystem_m.dylib
       0x195279000 -        0x19527c4f7  libmacho.dylib (27062) <50DEADEC-3E99-3519-AFC3-4A3FEB3F14C3> /usr/lib/system/libmacho.dylib
       0x195296000 -        0x1952a2707  libcommonCrypto.dylib (600041) <41C99F45-C5E6-39DB-B1F2-A1BEA9D242A4> /usr/lib/system/libcommonCrypto.dylib
       0x1952a3000 -        0x1952acc87  libunwind.dylib (2200.5) <3070AB81-B082-39E8-8A00-EF88DDE9AC47> /usr/lib/system/libunwind.dylib
       0x1952b4000 -        0x1952be7eb  libcopyfile.dylib (260.0.3) <72D95AF9-BF5E-3A84-81A6-BCC5BDB99857> /usr/lib/system/libcopyfile.dylib
       0x1952bf000 -        0x1952c28bf  libcompiler_rt.dylib (103.4) <DFB5CE7F-A36E-36AA-BECE-1392D3D43607> /usr/lib/system/libcompiler_rt.dylib
       0x1952c3000 -        0x1952c8077  libsystem_collections.dylib (1786.0.3) <1E8022D4-5A37-3A7A-8936-603E6FA88358> /usr/lib/system/libsystem_collections.dylib
       0x1952c9000 -        0x1952cbf1f  libsystem_secinit.dylib (182) <DE037464-4C5D-3E96-A33F-2A4557CC6A20> /usr/lib/system/libsystem_secinit.dylib
       0x1952cc000 -        0x1952ce97f  libremovefile.dylib (96) <E6E6DFCF-6B2C-3F30-A59D-816CAB1190CE> /usr/lib/system/libremovefile.dylib
       0x1952cf000 -        0x1952cfe27  libkeymgr.dylib (31) <5EC997EF-3ADA-360B-9FCD-5F940C83FA4E> /usr/lib/system/libkeymgr.dylib
       0x1952d0000 -        0x1952d8af7  libsystem_dnssd.dylib (3111.0.5.0.1) <DE22096F-1E5B-3D6E-8164-771582DD6391> /usr/lib/system/libsystem_dnssd.dylib
       0x1952d9000 -        0x1952ddf1b  libcache.dylib (95) <80BAE197-E285-3F6E-A1EE-B77FE37D7E5D> /usr/lib/system/libcache.dylib
       0x1952de000 -        0x1952df8f3  libSystem.B.dylib (1359) <4FDC9AA6-B344-37FE-B8C6-A4C94A038F57> /usr/lib/libSystem.B.dylib
       0x19be40000 -        0x19be40f2f  libobjcMsgSend2.dylib (973.1) <BD27A84B-C9AE-3282-BBEA-3B6119837B5A> /usr/lib/objc/libobjcMsgSend2.dylib
       0x1a3e40000 -        0x1a3e40f2f  libobjcMsgSend3.dylib (973.1) <C0860D68-DDFC-3BD7-8B06-DB0645CBBED4> /usr/lib/objc/libobjcMsgSend3.dylib
       0x1abe40000 -        0x1abe40f2f  libobjcMsgSend4.dylib (973.1) <A6153BF5-622B-3B01-81B6-F64A365EF613> /usr/lib/objc/libobjcMsgSend4.dylib
       0x1b3e40000 -        0x1b3e40f2f  libobjcMsgSend5.dylib (973.1) <3913A71C-B29A-3AEA-820B-BEC40AC1861A> /usr/lib/objc/libobjcMsgSend5.dylib
       0x1bbe40000 -        0x1bbe40f2f  libobjcMsgSend6.dylib (973.1) <9BC523A3-E167-3F6C-8CAE-0F3EBA671791> /usr/lib/objc/libobjcMsgSend6.dylib
       0x1c3e40000 -        0x1c3e40f2f  libobjcMsgSend7.dylib (973.1) <248B7BCE-5B4C-34C7-A340-43D5228628C5> /usr/lib/objc/libobjcMsgSend7.dylib
       0x1cbe40000 -        0x1cbe40f2f  libobjcMsgSend8.dylib (973.1) <3E041BAD-A8E8-3069-B741-78CD1A45B176> /usr/lib/objc/libobjcMsgSend8.dylib
       0x1d3e40000 -        0x1d3e40f2f  libobjcMsgSend9.dylib (973.1) <34A67969-21A0-39D6-BB81-8FDA5A2409DB> /usr/lib/objc/libobjcMsgSend9.dylib
       0x1dbe40000 -        0x1dbe40f2f  libobjcMsgSend10.dylib (973.1) <678186C0-8EAD-3B35-8CBB-00285B41E4A0> /usr/lib/objc/libobjcMsgSend10.dylib
       0x1e3e40000 -        0x1e3e40f2f  libobjcMsgSend11.dylib (973.1) <E05CB08C-E956-36FA-8967-AE8E346A8D2C> /usr/lib/objc/libobjcMsgSend11.dylib
       0x20be40000 -        0x20be40f2f  libobjcMsgSend12.dylib (973.1) <10AB03AA-FF1F-3FDC-9DFB-BFC40042C501> /usr/lib/objc/libobjcMsgSend12.dylib
       0x213e40000 -        0x213e40f2f  libobjcMsgSend13.dylib (973.1) <ABF53427-FA6F-3D0D-8F9D-7AD795CA5C92> /usr/lib/objc/libobjcMsgSend13.dylib
       0x21be40000 -        0x21be40f2f  libobjcMsgSend14.dylib (973.1) <9A844C46-A6DA-34D4-8EBF-2AD775C30684> /usr/lib/objc/libobjcMsgSend14.dylib
       0x223e40000 -        0x223e40f2f  libobjcMsgSend15.dylib (973.1) <7C995666-2B2D-3284-AA0A-EBF7C922838E> /usr/lib/objc/libobjcMsgSend15.dylib
       0x22be40000 -        0x22be40f2f  libobjcMsgSend16.dylib (973.1) <B6C0E14B-53AE-3E22-9ED5-1729C49F46F2> /usr/lib/objc/libobjcMsgSend16.dylib
       0x233e40000 -        0x233e40f2f  libobjcMsgSend17.dylib (973.1) <07B4CF85-251B-301B-832B-20B315A59E19> /usr/lib/objc/libobjcMsgSend17.dylib
       0x23be40000 -        0x23be40f2f  libobjcMsgSend18.dylib (973.1) <43E575B7-04DB-3999-A633-1A3B638BA6E3> /usr/lib/objc/libobjcMsgSend18.dylib
       0x243e40000 -        0x243e40f2f  libobjcMsgSend19.dylib (973.1) <736F4D85-76F7-3B28-8D87-C07E8F7A0EF4> /usr/lib/objc/libobjcMsgSend19.dylib
       0x24be40000 -        0x24be40f2f  libobjcMsgSend20.dylib (973.1) <74E67C8B-6BCA-3184-A18E-A97F370052C6> /usr/lib/objc/libobjcMsgSend20.dylib
       0x253e40000 -        0x253e40f2f  libobjcMsgSend21.dylib (973.1) <CC0D732F-98E7-3888-9E15-70984DA2FB04> /usr/lib/objc/libobjcMsgSend21.dylib
       0x25be40000 -        0x25be40f2f  libobjcMsgSend22.dylib (973.1) <85A60286-5DE3-32BA-B18C-2A498B065C88> /usr/lib/objc/libobjcMsgSend22.dylib
       0x263e40000 -        0x263e40f2f  libobjcMsgSend23.dylib (973.1) <5452A0D2-6B19-39BE-ADDD-80B7BCDE3A98> /usr/lib/objc/libobjcMsgSend23.dylib
       0x26be40000 -        0x26be40f2f  libobjcMsgSend24.dylib (973.1) <94BBF2D6-722B-350D-8557-4D25A8E8D53A> /usr/lib/objc/libobjcMsgSend24.dylib
       0x273e40000 -        0x273e40f2f  libobjcMsgSend25.dylib (973.1) <35481387-5A8E-3AE4-86A6-94CEB3CC8726> /usr/lib/objc/libobjcMsgSend25.dylib
       0x28be40000 -        0x28be40f2f  libobjcMsgSend26.dylib (973.1) <9E0C8664-E7F4-39D1-AAFC-BD92B255E4E8> /usr/lib/objc/libobjcMsgSend26.dylib
       0x293e40000 -        0x293e40f2f  libobjcMsgSend27.dylib (973.1) <FD424935-55A9-3650-955A-EED3441A1D19> /usr/lib/objc/libobjcMsgSend27.dylib
       0x29be40000 -        0x29be40f2f  libobjcMsgSend28.dylib (973.1) <09BA7B97-7DF7-3C7F-932A-B6847662FC49> /usr/lib/objc/libobjcMsgSend28.dylib
       0x2a3e40000 -        0x2a3e40f2f  libobjcMsgSend29.dylib (973.1) <36D5BA3F-2139-30B0-8558-556764BE9813> /usr/lib/objc/libobjcMsgSend29.dylib
       0x2abe40000 -        0x2abe40f2f  libobjcMsgSend30.dylib (973.1) <9F05564A-9D12-372C-98FC-E9F0E6BE4F04> /usr/lib/objc/libobjcMsgSend30.dylib
       0x2b0b5a000 -        0x2b0b60fe5  libRosetta.dylib (385) <E359944B-D230-33F9-A04E-0C3B17C3326E> /usr/lib/libRosetta.dylib
       0x2b1549000 -        0x2b154c75b  libsystem_darwindirectory.dylib (129.0.1) <61264923-2AA5-3658-B8C4-550C71E9D4B3> /usr/lib/system/libsystem_darwindirectory.dylib
       0x2b154d000 -        0x2b1557d9b  libsystem_eligibility.dylib (446.1.3) <EDDE8E9C-A2CF-3931-BBB3-321CB852EB30> /usr/lib/system/libsystem_eligibility.dylib
       0x2b1558000 -        0x2b156142b  libsystem_sanitizers.dylib (32) <7138ED99-7AA0-34EA-B35B-20EF6ADB1EED> /usr/lib/system/libsystem_sanitizers.dylib
       0x2b1562000 -        0x2b1562a13  libsystem_trial.dylib (511) <6AE48824-EC44-3A8C-B501-BE57DBE892E7> /usr/lib/system/libsystem_trial.dylib
       0x2b3e40000 -        0x2b3e40f2f  libobjcMsgSend31.dylib (973.1) <0985E20F-78C3-3466-A2B2-DBB95F7104A3> /usr/lib/objc/libobjcMsgSend31.dylib
       0x2bbe40000 -        0x2bbe40f2f  libobjcMsgSend32.dylib (973.1) <0D309D58-D576-3E5D-AD4B-6D55AB491702> /usr/lib/objc/libobjcMsgSend32.dylib
       0x2c3e40000 -        0x2c3e40f2f  libobjcMsgSend33.dylib (973.1) <346E0484-48FA-369B-8A64-93B5F5341CFE> /usr/lib/objc/libobjcMsgSend33.dylib
       0x2cbe40000 -        0x2cbe40f2f  libobjcMsgSend34.dylib (973.1) <6A31F809-BCBE-3E01-A367-E91FDACCE324> /usr/lib/objc/libobjcMsgSend34.dylib
