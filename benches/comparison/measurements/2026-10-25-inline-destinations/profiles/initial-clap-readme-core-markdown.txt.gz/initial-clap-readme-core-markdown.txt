Analysis of sampling baseline (pid 9889) every 1 millisecond
Process:         baseline [9889]
Path:            /private/tmp/*/baseline
Load Address:    0x104158000
Identifier:      baseline
Version:         0
Code Type:       ARM64
Platform:        macOS
Parent Process:  python3.13 [9888]
Target Type:     live task

Date/Time:       2026-10-25 11:29:21.434 +1300
Launch Time:     2026-10-25 11:29:20.897 +1300
OS Version:      macOS 27.0.1 (26A434)
Report Version:  7
Analysis Tool:   /usr/bin/sample

Physical footprint:         2080K
Physical footprint (peak):  2080K
Idle exit:                  untracked
----

Call graph:
    2468 Thread_43524405   DispatchQueue_1: com.apple.main-thread  (serial)
      2468 start  (in dyld) + 6688  [0x1842f7e80]
        2468 main  (in baseline) + 52  [0x10417bc20]
          2468 _RNvNtCs1coMeGJvsuS_3std2rt19lang_start_internal  (in baseline) + 936  [0x10426a030]
            2468 _RNCINvNtCs1coMeGJvsuS_3std2rt10lang_startuE0CseVgRDH8534i_19markdown_comparison  (in baseline) + 16  [0x10418e6d4]
              2468 _RINvNtNtCs1coMeGJvsuS_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECseVgRDH8534i_19markdown_comparison  (in baseline) + 12  [0x10418f000]
                2459 _RNvCseVgRDH8534i_19markdown_comparison4main  (in baseline) + 1380  [0x10417a264]
                + 2457 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 9268  [0x1041792ac]
                + ! 1924 _RNvCs8seiryzelau_13core_markdown20to_html_with_options  (in baseline) + 216  [0x10423f794]
                + ! : 749 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 6348  [0x10421a140]
                + ! : | 398 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 3932  [0x10420e8c4]
                + ! : | + 398 _RNvNtCs8seiryzelau_13core_markdown13inline_parser8resource  (in baseline) + 392,564,...  [0x104218450,0x1042184fc,...]
                + ! : | 186 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 7272,844,...  [0x10420f5d0,0x10420dcb4,...]
                + ! : | 40 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 9612  [0x10420fef4]
                + ! : | + 22 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_EB7_  (in baseline) + 848  [0x104215a78]
                + ! : | + ! 19 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in baseline) + 60  [0x10428d084]
                + ! : | + ! : 18 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x10428d3c4]
                + ! : | + ! : | 15 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | + ! : | + 11 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | + ! : | + ! 5 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | + ! : | + ! : 3 _xzm_malloc  (in libsystem_malloc.dylib) + 276,208  [0x1844e7f08,0x1844e7ec4]
                + ! : | + ! : | + ! : 2 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 0,404  [0x1844e8a4c,0x1844e8be0]
                + ! : | + ! : | + ! 3 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 476,904,...  [0x1844e51ec,0x1844e5398,...]
                + ! : | + ! : | + ! 2 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | + ! : | + ! : 1 DYLD-STUB$$_platform_memmove  (in libsystem_malloc.dylib) + 12  [0x18450a5ac]
                + ! : | + ! : | + ! : 1 _platform_memmove  (in libsystem_platform.dylib) + 180  [0x1846d7e14]
                + ! : | + ! : | + ! 1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | + ! : | + !   1 _xzm_free  (in libsystem_malloc.dylib) + 692  [0x1844ec9b4]
                + ! : | + ! : | + 4 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 124,160  [0x1844f4b14,0x1844f4b38]
                + ! : | + ! : | 2 _realloc  (in libsystem_malloc.dylib) + 208,252  [0x1844f5260,0x1844f528c]
                + ! : | + ! : | 1 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | + ! : |   1 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 200  [0x1844e43cc]
                + ! : | + ! : 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 64  [0x10428d3a8]
                + ! : | + ! 2 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in baseline) + 60,68  [0x10428d084,0x10428d08c]
                + ! : | + ! 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 168  [0x10428d410]
                + ! : | + 15 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_EB7_  (in baseline) + 32,1248,...  [0x104215748,0x104215c08,...]
                + ! : | + 3 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_EB7_  (in baseline) + 1384  [0x104215c90]
                + ! : | +   3 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown8document6NodeIdE8grow_oneBQ_  (in baseline) + 60  [0x10428d340]
                + ! : | +     3 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 120  [0x10428d3e0]
                + ! : | +       1 DYLD-STUB$$malloc  (in baseline) + 4  [0x104293154]
                + ! : | +       1 _RNvCsjVqd8RsBhQu_7___rustc11___rdl_alloc  (in baseline) + 0  [0x10425cab0]
                + ! : | +       1 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 92  [0x1844ef9ec]
                + ! : | 37 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 3972  [0x10420e8ec]
                + ! : | + 35 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser4LinkE8grow_oneBQ_  (in baseline) + 60  [0x10428d14c]
                + ! : | + ! 31 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x10428d3c4]
                + ! : | + ! : 28 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | + ! : | 25 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | + ! : | + 12 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | + ! : | + ! 9 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | + ! : | + ! : 9 mach_absolute_time  (in libsystem_kernel.dylib) + 108,16,...  [0x1846890f8,0x18468909c,...]
                + ! : | + ! : | + ! 2 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 280,568  [0x1844ed79c,0x1844ed8bc]
                + ! : | + ! : | + ! 1 _xzm_free  (in libsystem_malloc.dylib) + 848  [0x1844eca50]
                + ! : | + ! : | + 6 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996,476,...  [0x1844e53f4,0x1844e51ec,...]
                + ! : | + ! : | + 4 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | + ! : | + ! 3 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 180,256,...  [0x1844e8b00,0x1844e8b4c,...]
                + ! : | + ! : | + ! 1 _xzm_malloc  (in libsystem_malloc.dylib) + 108  [0x1844e7e60]
                + ! : | + ! : | + 2 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | + ! : | + ! 2 _platform_memmove  (in libsystem_platform.dylib) + 180,204  [0x1846d7e14,0x1846d7e2c]
                + ! : | + ! : | + 1 _xzm_free  (in libsystem_malloc.dylib) + 968  [0x1844ecac8]
                + ! : | + ! : | 3 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 124,48  [0x1844f4b14,0x1844f4ac8]
                + ! : | + ! : 2 _realloc  (in libsystem_malloc.dylib) + 36,248  [0x1844f51b4,0x1844f5288]
                + ! : | + ! : 1 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | + ! :   1 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 268  [0x1844e4410]
                + ! : | + ! 4 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 120  [0x10428d3e0]
                + ! : | + !   2 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 92,192  [0x1844ef9ec,0x1844efa50]
                + ! : | + !   1 _RNvCsjVqd8RsBhQu_7___rustc11___rdl_alloc  (in baseline) + 0  [0x10425cab0]
                + ! : | + !   1 _malloc_zone_malloc  (in libsystem_malloc.dylib) + 44  [0x1844f451c]
                + ! : | + 2 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser4LinkE8grow_oneBQ_  (in baseline) + 60  [0x10428d14c]
                + ! : | 27 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 6556  [0x10420f304]
                + ! : | + 27 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in baseline) + 60  [0x10428d084]
                + ! : | +   27 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x10428d3c4]
                + ! : | +     20 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | +     ! 18 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | +     ! : 13 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | +     ! : | 10 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | +     ! : | + 10 mach_absolute_time  (in libsystem_kernel.dylib) + 108  [0x1846890f8]
                + ! : | +     ! : | 3 _xzm_free  (in libsystem_malloc.dylib) + 28,220,...  [0x1844ec71c,0x1844ec7dc,...]
                + ! : | +     ! : 2 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | +     ! : | 1 _xzm_malloc  (in libsystem_malloc.dylib) + 512  [0x1844e7ff4]
                + ! : | +     ! : | 1 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 256  [0x1844e8b4c]
                + ! : | +     ! : 2 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | +     ! : | 2 _platform_memmove  (in libsystem_platform.dylib) + 180  [0x1846d7e14]
                + ! : | +     ! : 1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 224  [0x1844e50f0]
                + ! : | +     ! 2 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 24,48  [0x1844f4ab0,0x1844f4ac8]
                + ! : | +     3 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | +     ! 3 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 104,136,...  [0x1844e436c,0x1844e438c,...]
                + ! : | +     2 _realloc  (in libsystem_malloc.dylib) + 36,412  [0x1844f51b4,0x1844f532c]
                + ! : | +     1 _RNvCsjVqd8RsBhQu_7___rustc13___rdl_realloc  (in baseline) + 0  [0x10425cb28]
                + ! : | +     1 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 708  [0x1844e45c8]
                + ! : | 24 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 7692  [0x10420f774]
                + ! : | + 23 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in baseline) + 60  [0x10428d084]
                + ! : | + ! 23 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x10428d3c4]
                + ! : | + !   22 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | + !   : 22 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | + !   :   9 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | + !   :   | 8 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | + !   :   | + 8 mach_absolute_time  (in libsystem_kernel.dylib) + 108,16,...  [0x1846890f8,0x18468909c,...]
                + ! : | + !   :   | 1 _xzm_free  (in libsystem_malloc.dylib) + 704  [0x1844ec9c0]
                + ! : | + !   :   7 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | + !   :   | 7 _platform_memmove  (in libsystem_platform.dylib) + 180,0  [0x1846d7e14,0x1846d7d60]
                + ! : | + !   :   3 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | + !   :   | 3 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 28,640,...  [0x1844e8a68,0x1844e8ccc,...]
                + ! : | + !   :   3 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 400,996  [0x1844e51a0,0x1844e53f4]
                + ! : | + !   1 _realloc  (in libsystem_malloc.dylib) + 20  [0x1844f51a4]
                + ! : | + 1 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in baseline) + 0  [0x10428d048]
                + ! : | 11 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 4052  [0x10420e93c]
                + ! : | + 11 _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser18suppress_autolinks  (in baseline) + 48,128,...  [0x104217574,0x1042175c4,...]
                + ! : | 7 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_EB7_  (in baseline) + 1464  [0x104215ce0]
                + ! : | 5 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 1280  [0x10420de68]
                + ! : | + 5 _RNvNtNtCs8seiryzelau_13core_markdown13inline_parser8autolink3web  (in baseline) + 24,44,...  [0x104247078,0x10424708c,...]
                + ! : | 4 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 6656  [0x10420f368]
                + ! : | + 4 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser4TickE8grow_oneBQ_  (in baseline) + 60  [0x10428d1b0]
                + ! : | +   2 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 120  [0x10428d3e0]
                + ! : | +   ! 1 _RNvCsjVqd8RsBhQu_7___rustc11___rdl_alloc  (in baseline) + 0  [0x10425cab0]
                + ! : | +   ! 1 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 144  [0x1844efa20]
                + ! : | +   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 108  [0x10428d3d4]
                + ! : | +   ! 1 _RNvCsjVqd8RsBhQu_7___rustc35___rust_no_alloc_shim_is_unstable_v2  (in baseline) + 0  [0x1041921f8]
                + ! : | +   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 100  [0x10428d3cc]
                + ! : | 3 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 6184  [0x10420f190]
                + ! : | + 2 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser9DelimiterE8grow_oneBQ_  (in baseline) + 60  [0x10428d278]
                + ! : | + ! 2 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 120  [0x10428d3e0]
                + ! : | + !   2 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 144,260  [0x1844efa20,0x1844efa94]
                + ! : | + 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 164  [0x10428d40c]
                + ! : | 3 _RNvNtNtCs8seiryzelau_13core_markdown13inline_parser8autolink3web  (in baseline) + 1928  [0x1042477e8]
                + ! : | 2 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 4028  [0x10420e924]
                + ! : | + 2 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_EB7_  (in baseline) + 20  [0x10421573c]
                + ! : | 1 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 4884  [0x10420ec7c]
                + ! : | + 1 _RNvNtNtCs8seiryzelau_13core_markdown4util4char8classify  (in baseline) + 104  [0x1042420c4]
                + ! : | 1 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser4TickE8grow_oneBQ_  (in baseline) + 80  [0x10428d1c4]
                + ! : 492 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 8228,4312,...  [0x10421a898,0x10421994c,...]
                + ! : 157 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 22720  [0x10421e134]
                + ! : | 101 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in baseline) + 836,844,...  [0x10423df24,0x10423df2c,...]
                + ! : | 36 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in baseline) + 2556  [0x10423e5dc]
                + ! : | + 36 _RINvNvMs2_NtCs3vUkWdPtNor_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs8seiryzelau_13core_markdown  (in baseline) + 108  [0x10428cf2c]
                + ! : | +   36 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x10428d3c4]
                + ! : | +     33 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | +     ! 29 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | +     ! : 13 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | +     ! : | 13 _platform_memmove  (in libsystem_platform.dylib) + 180  [0x1846d7e14]
                + ! : | +     ! : 12 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | +     ! : | 7 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | +     ! : | + 7 mach_absolute_time  (in libsystem_kernel.dylib) + 108,16  [0x1846890f8,0x18468909c]
                + ! : | +     ! : | 3 _xzm_free  (in libsystem_malloc.dylib) + 24,28,...  [0x1844ec718,0x1844ec71c,...]
                + ! : | +     ! : | 2 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 56,372  [0x1844ed6bc,0x1844ed7f8]
                + ! : | +     ! : 3 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | +     ! : | 3 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 404,88  [0x1844e8be0,0x1844e8aa4]
                + ! : | +     ! : 1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 248  [0x1844e5108]
                + ! : | +     ! 4 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 124,0,...  [0x1844f4b14,0x1844f4a98,...]
                + ! : | +     1 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 208  [0x1844f4b68]
                + ! : | +     1 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | +     ! 1 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 496  [0x1844e44f4]
                + ! : | +     1 _realloc  (in libsystem_malloc.dylib) + 248  [0x1844f5288]
                + ! : | 20 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in baseline) + 2364  [0x10423e51c]
                + ! : |   20 _platform_memmove  (in libsystem_platform.dylib) + 428,452,...  [0x1846d7f0c,0x1846d7f24,...]
                + ! : 95 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 23128  [0x10421e2cc]
                + ! : | 80 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in baseline) + 836,844,...  [0x10423df24,0x10423df2c,...]
                + ! : | 15 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in baseline) + 2364  [0x10423e51c]
                + ! : |   15 _platform_memmove  (in libsystem_platform.dylib) + 428,452,...  [0x1846d7f0c,0x1846d7f24,...]
                + ! : 89 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 12852  [0x10421baa8]
                + ! : | 68 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in baseline) + 232,352,...  [0x1042222b8,0x104222330,...]
                + ! : | 21 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in baseline) + 652  [0x10422245c]
                + ! : |   18 _platform_memmove  (in libsystem_platform.dylib) + 428,452,...  [0x1846d7f0c,0x1846d7f24,...]
                + ! : |   3 DYLD-STUB$$memcpy  (in baseline) + 4  [0x10429316c]
                + ! : 86 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 1768  [0x104218f5c]
                + ! : | 68 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in baseline) + 320,228,...  [0x104242c40,0x104242be4,...]
                + ! : | 9 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in baseline) + 1100  [0x104242f4c]
                + ! : | + 9 _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in baseline) + 48,340,...  [0x1042425fc,0x104242720,...]
                + ! : | 5 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in baseline) + 588  [0x104242d4c]
                + ! : | + 5 _RNvNtNtCs8seiryzelau_13core_markdown4util19character_reference4scan  (in baseline) + 496,208,...  [0x10424ae64,0x10424ad44,...]
                + ! : | 4 _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in baseline) + 828,832  [0x104242908,0x10424290c]
                + ! : 81 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 24752  [0x10421e924]
                + ! : | 81 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown6stream9EventKindEBF_  (in baseline) + 36,12,...  [0x104221f78,0x104221f60,...]
                + ! : 33 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 11536  [0x10421b584]
                + ! : | 19 _RINvNtNtCs8seiryzelau_13core_markdown4util9tagfilter14write_filteredNtNtB6_6stream11StreamErrorNCINvMNtB6_19event_html_rendererINtB1B_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9event_refKb0_E0EB6_  (in baseline) + 432,468,...  [0x104245f90,0x104245fb4,...]
                + ! : | 13 _RINvNtNtCs8seiryzelau_13core_markdown4util9tagfilter14write_filteredNtNtB6_6stream11StreamErrorNCINvMNtB6_19event_html_rendererINtB1B_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9event_refKb0_E0EB6_  (in baseline) + 3292  [0x104246abc]
                + ! : | + 7 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in baseline) + 12,364,...  [0x1042221dc,0x10422233c,...]
                + ! : | + 6 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in baseline) + 652  [0x10422245c]
                + ! : | +   4 _platform_memmove  (in libsystem_platform.dylib) + 452,428  [0x1846d7f24,0x1846d7f0c]
                + ! : | +   2 DYLD-STUB$$memcpy  (in baseline) + 4  [0x10429316c]
                + ! : | 1 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in baseline) + 732  [0x1042224ac]
                + ! : 30 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 34868  [0x1042210a8]
                + ! : | 20 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown12event_parser11EventParserEBF_  (in baseline) + 52  [0x104221b5c]
                + ! : | + 11 _xzm_xzone_free_freelist  (in libsystem_malloc.dylib) + 720  [0x1844edef8]
                + ! : | + ! 11 mach_absolute_time  (in libsystem_kernel.dylib) + 108,112  [0x1846890f8,0x1846890fc]
                + ! : | + 5 _xzm_xzone_free_freelist  (in libsystem_malloc.dylib) + 564,48,...  [0x1844ede5c,0x1844edc58,...]
                + ! : | + 2 _xzm_free_outlined  (in libsystem_malloc.dylib) + 0,112  [0x1844eceac,0x1844ecf1c]
                + ! : | + 1 _free  (in libsystem_malloc.dylib) + 0  [0x1844f5110]
                + ! : | + 1 _xzm_free_tc  (in libsystem_malloc.dylib) + 84  [0x1844f18cc]
                + ! : | 8 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown13inline_parser12InlineParserEBF_  (in baseline) + 148  [0x104221da4]
                + ! : | + 4 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | + ! 4 mach_absolute_time  (in libsystem_kernel.dylib) + 108  [0x1846890f8]
                + ! : | + 2 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 0,504  [0x1844ed684,0x1844ed87c]
                + ! : | + 2 _xzm_free_tc  (in libsystem_malloc.dylib) + 120,292  [0x1844f18f0,0x1844f199c]
                + ! : | 1 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown13inline_parser12InlineParserEBF_  (in baseline) + 44  [0x104221d3c]
                + ! : | + 1 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | +   1 mach_absolute_time  (in libsystem_kernel.dylib) + 108  [0x1846890f8]
                + ! : | 1 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown13inline_parser12InlineParserEBF_  (in baseline) + 68  [0x104221d54]
                + ! : |   1 _free  (in libsystem_malloc.dylib) + 4  [0x1844f5114]
                + ! : 14 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown6stream9EventKindEBF_  (in baseline) + 96  [0x104221fb4]
                + ! : 14 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in baseline) + 732,736  [0x1042224ac,0x1042224b0]
                + ! : 11 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 23688  [0x10421e4fc]
                + ! : | 8 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser9DelimiterE8grow_oneBQ_  (in baseline) + 60  [0x10428d278]
                + ! : | + 7 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x10428d3c4]
                + ! : | + ! 6 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | + ! : 6 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | + ! :   2 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | + ! :   | 2 _xzm_free  (in libsystem_malloc.dylib) + 252,1808  [0x1844ec7fc,0x1844ece10]
                + ! : | + ! :   2 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 400,1128  [0x1844e51a0,0x1844e5478]
                + ! : | + ! :   1 _xzm_free  (in libsystem_malloc.dylib) + 1820  [0x1844ece1c]
                + ! : | + ! :   1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | + ! :     1 _xzm_malloc  (in libsystem_malloc.dylib) + 448  [0x1844e7fb4]
                + ! : | + ! 1 realloc  (in libsystem_malloc.dylib) + 0  [0x1844b78f4]
                + ! : | + 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 120  [0x10428d3e0]
                + ! : | +   1 _malloc_zone_malloc  (in libsystem_malloc.dylib) + 64  [0x1844f4530]
                + ! : | 3 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser9DelimiterE8grow_oneBQ_  (in baseline) + 60  [0x10428d278]
                + ! : 11 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 25588  [0x10421ec68]
                + ! : | 11 _platform_memmove  (in libsystem_platform.dylib) + 452,444,...  [0x1846d7f24,0x1846d7f1c,...]
                + ! : 8 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 64  [0x1042188b4]
                + ! : | 7 _platform_memmove  (in libsystem_platform.dylib) + 144,180,...  [0x1846d7df0,0x1846d7e14,...]
                + ! : | 1 DYLD-STUB$$memcpy  (in baseline) + 4  [0x10429316c]
                + ! : 8 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 5676  [0x104219ea0]
                + ! : | 5 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser5value  (in baseline) + 0,120,...  [0x10423e774,0x10423e7ec,...]
                + ! : | 2 _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in baseline) + 820,832  [0x104242900,0x10424290c]
                + ! : | 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser5value  (in baseline) + 216  [0x10423e84c]
                + ! : |   1 _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in baseline) + 48  [0x1042425fc]
                + ! : 7 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 23068  [0x10421e290]
                + ! : | 7 _RNvMNtCs8seiryzelau_13core_markdown6streamNtB2_4Text7resolve  (in baseline) + 80,0,...  [0x104240314,0x1042402c4,...]
                + ! : 6 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in baseline) + 1168,1176  [0x104242f90,0x104242f98]
                + ! : 4 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 22640  [0x10421e0e4]
                + ! : | 4 _RNvMNtCs8seiryzelau_13core_markdown6streamNtB2_4Text7resolve  (in baseline) + 0,20,...  [0x1042402c4,0x1042402d8,...]
                + ! : 4 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 24692  [0x10421e8e8]
                + ! : | 3 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in baseline) + 652  [0x10422245c]
                + ! : | + 3 _platform_memmove  (in libsystem_platform.dylib) + 0,420  [0x1846d7d60,0x1846d7f04]
                + ! : | 1 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in baseline) + 484  [0x1042223b4]
                + ! : 4 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 25796  [0x10421ed38]
                + ! : | 4 _platform_memmove  (in libsystem_platform.dylib) + 12,428,...  [0x1846d7d6c,0x1846d7f0c,...]
                + ! : 3 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 4480  [0x1042199f4]
                + ! : | 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser17document_boundary  (in baseline) + 16,68,...  [0x10428d428,0x10428d45c,...]
                + ! : 3 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 23084  [0x10421e2a0]
                + ! : | 3 _RNvMNtCs9nEiEE0E2Vj_4core6resultINtB2_6ResultReNtNtCs8seiryzelau_13core_markdown6stream11StreamErrorE6expectBN_  (in baseline) + 12,24,...  [0x1042252fc,0x104225308,...]
                + ! : 3 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline) + 9744,9736  [0x10420ff78,0x10420ff70]
                + ! : 2 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 10140  [0x10421b010]
                + ! : | 2 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9terminateB4_  (in baseline) + 0  [0x104225128]
                + ! : 2 _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in baseline) + 2300,2308  [0x10423e4dc,0x10423e4e4]
                + ! : 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 9096  [0x10421abfc]
                + ! : | 1 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9footnotesB4_  (in baseline) + 36  [0x1042226dc]
                + ! : 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 13596  [0x10421bd90]
                + ! : | 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 13596  [0x10421bd90]
                + ! : |   1 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9terminateB4_  (in baseline) + 152  [0x1042251c0]
                + ! : 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 19544  [0x10421d4cc]
                + ! : | 1 DYLD-STUB$$memcpy  (in baseline) + 4  [0x10429316c]
                + ! : 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 22656  [0x10421e0f4]
                + ! : | 1 _RNvMNtCs9nEiEE0E2Vj_4core6resultINtB2_6ResultReNtNtCs8seiryzelau_13core_markdown6stream11StreamErrorE6expectBN_  (in baseline) + 24  [0x104225308]
                + ! : 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 24428  [0x10421e7e0]
                + ! : | 1 _RNvMNtCs8seiryzelau_13core_markdown6streamNtB2_4Text7resolve  (in baseline) + 20  [0x1042402d8]
                + ! : 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 24476  [0x10421e810]
                + ! : | 1 _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in baseline) + 652  [0x10422245c]
                + ! : |   1 DYLD-STUB$$memcpy  (in baseline) + 4  [0x10429316c]
                + ! : 1 _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline) + 24644  [0x10421e8b8]
                + ! : | 1 _RNvMNtCs8seiryzelau_13core_markdown6streamNtB2_4Text7resolve  (in baseline) + 0  [0x1042402c4]
                + ! : 1 _RNvMNtCs9nEiEE0E2Vj_4core6resultINtB2_6ResultReNtNtCs8seiryzelau_13core_markdown6stream11StreamErrorE6expectBN_  (in baseline) + 40  [0x104225318]
                + ! 527 _RNvCs8seiryzelau_13core_markdown20to_html_with_options  (in baseline) + 200  [0x10423f784]
                + ! : 526 _RNvMNtCs8seiryzelau_13core_markdown12event_parserNtB2_11EventParser7prepare  (in baseline) + 44  [0x10423e65c]
                + ! : | 142 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 768,1116,...  [0x10422b338,0x10422b494,...]
                + ! : | 70 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6664  [0x10422ca40]
                + ! : | + 60 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 76  [0x10422a5a8]
                + ! : | + ! 60 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4NodeE8grow_oneBQ_  (in baseline) + 60  [0x10428d0e8]
                + ! : | + !   58 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x10428d3c4]
                + ! : | + !   : 52 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | + !   : | 51 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | + !   : | + 27 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | + !   : | + ! 21 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | + !   : | + ! : 21 mach_absolute_time  (in libsystem_kernel.dylib) + 108,112,...  [0x1846890f8,0x1846890fc,...]
                + ! : | + !   : | + ! 4 _xzm_free  (in libsystem_malloc.dylib) + 80,28  [0x1844ec750,0x1844ec71c]
                + ! : | + !   : | + ! 2 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 28,56  [0x1844ed6a0,0x1844ed6bc]
                + ! : | + !   : | + 14 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | + !   : | + ! 14 _platform_memmove  (in libsystem_platform.dylib) + 180,136  [0x1846d7e14,0x1846d7de8]
                + ! : | + !   : | + 5 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | + !   : | + ! 2 _xzm_xzone_malloc_small_freelist  (in libsystem_malloc.dylib) + 92,1036  [0x1844e8ea8,0x1844e9258]
                + ! : | + !   : | + ! 2 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 268,832  [0x1844e8b58,0x1844e8d8c]
                + ! : | + !   : | + ! 1 _xzm_malloc  (in libsystem_malloc.dylib) + 0  [0x1844e7df4]
                + ! : | + !   : | + 5 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 268,320,...  [0x1844e511c,0x1844e5150,...]
                + ! : | + !   : | 1 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 124  [0x1844f4b14]
                + ! : | + !   : 5 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | + !   : | 5 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 496,92,...  [0x1844e44f4,0x1844e4360,...]
                + ! : | + !   : 1 _RNvCsjVqd8RsBhQu_7___rustc13___rdl_realloc  (in baseline) + 0  [0x10425cb28]
                + ! : | + !   2 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 8,40  [0x10428d370,0x10428d390]
                + ! : | + 10 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 20,60,...  [0x10422a570,0x10422a598,...]
                + ! : | 34 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 4640  [0x10422c258]
                + ! : | + 22 _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in baseline) + 64  [0x104248bf0]
                + ! : | + ! 20 _RNvXNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fnINtB2_6FromFnNCNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB17_7Builder20definition_fragments0ENtNtNtB6_6traits8iterator8Iterator4nextB19_  (in baseline) + 280  [0x10424c078]
                + ! : | + ! : 20 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 280,292,...  [0x10424541c,0x104245428,...]
                + ! : | + ! 2 _RNvXNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fnINtB2_6FromFnNCNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB17_7Builder20definition_fragments0ENtNtNtB6_6traits8iterator8Iterator4nextB19_  (in baseline) + 4,44  [0x10424bf64,0x10424bf8c]
                + ! : | + 11 _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in baseline) + 428,432,...  [0x104248d5c,0x104248d60,...]
                + ! : | + 1 _RNvXNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fnINtB2_6FromFnNCNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB17_7Builder20definition_fragments0ENtNtNtB6_6traits8iterator8Iterator4nextB19_  (in baseline) + 676  [0x10424c204]
                + ! : | 34 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6048  [0x10422c7d8]
                + ! : | + 30 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10table_head  (in baseline) + 36  [0x104229b64]
                + ! : | + ! 15 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 72  [0x10422a0a8]
                + ! : | + ! : 15 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 120,272,...  [0x10424537c,0x104245414,...]
                + ! : | + ! 7 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 40,4,...  [0x10422a088,0x10422a064,...]
                + ! : | + ! 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 644  [0x10422983c]
                + ! : | + ! 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 112  [0x10422a0d0]
                + ! : | + ! : 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 12,196  [0x1042295c4,0x10422967c]
                + ! : | + ! 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 400  [0x10422a1f0]
                + ! : | + !   2 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 128,388  [0x104244a70,0x104244b74]
                + ! : | + 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 436,428  [0x10422a214,0x10422a20c]
                + ! : | 23 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 8428  [0x10422d124]
                + ! : | + 20 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser4htmlNtB2_4Html6closed  (in baseline) + 1476  [0x104237aa0]
                + ! : | + ! 19 _RNvNtCsglYb6d7nGNF_6memchr6memmem4find  (in baseline) + 252,184,...  [0x104237f3c,0x104237ef8,...]
                + ! : | + ! 1 _RNvNtCsglYb6d7nGNF_6memchr6memmem4find  (in baseline) + 232  [0x104237f28]
                + ! : | + !   1 _RNvNtNtNtCsglYb6d7nGNF_6memchr4arch3all9rabinkarp12is_equal_raw  (in baseline) + 0  [0x10428e454]
                + ! : | + 2 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser4htmlNtB2_4Html6closed  (in baseline) + 1748  [0x104237bb0]
                + ! : | + 1 _RNvNtCsglYb6d7nGNF_6memchr6memmem4find  (in baseline) + 764  [0x10423813c]
                + ! : | 21 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 7124  [0x10422cc0c]
                + ! : | + 12 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 72  [0x10422a0a8]
                + ! : | + ! 12 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 272,120,...  [0x104245414,0x10424537c,...]
                + ! : | + 5 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 40,112,...  [0x10422a088,0x10422a0d0,...]
                + ! : | + 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 112  [0x10422a0d0]
                + ! : | + ! 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 140,136  [0x104229644,0x104229640]
                + ! : | + 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 400  [0x10422a1f0]
                + ! : | +   1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 668  [0x104244c8c]
                + ! : | 19 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6712  [0x10422ca70]
                + ! : | + 19 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 68,72,...  [0x1042295fc,0x104229600,...]
                + ! : | 16 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 656  [0x10422b2c8]
                + ! : | + 16 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 4,20,...  [0x1042295bc,0x1042295cc,...]
                + ! : | 16 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6620  [0x10422ca14]
                + ! : | + 16 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 120,272,...  [0x10424537c,0x104245414,...]
                + ! : | 14 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6488  [0x10422c990]
                + ! : | + 14 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline) + 24,244,...  [0x104229e08,0x104229ee4,...]
                + ! : | 14 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 9276  [0x10422d474]
                + ! : | + 9 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown8document6NodeIdE8grow_oneBQ_  (in baseline) + 60  [0x10428d340]
                + ! : | + ! 8 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x10428d3c4]
                + ! : | + ! : 6 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | + ! : | 6 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | + ! : |   3 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | + ! : |   + 3 _xzm_malloc  (in libsystem_malloc.dylib) + 0,344,...  [0x1844e7df4,0x1844e7f4c,...]
                + ! : | + ! : |   2 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 904,996  [0x1844e5398,0x1844e53f4]
                + ! : | + ! : |   1 _xzm_free  (in libsystem_malloc.dylib) + 1836  [0x1844ece2c]
                + ! : | + ! : 1 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | + ! : | 1 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 460  [0x1844e44d0]
                + ! : | + ! : 1 _realloc  (in libsystem_malloc.dylib) + 228  [0x1844f5274]
                + ! : | + ! 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 36  [0x10428d38c]
                + ! : | + 4 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown8document6NodeIdE8grow_oneBQ_  (in baseline) + 60,68  [0x10428d340,0x10428d348]
                + ! : | + 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 168  [0x10428d410]
                + ! : | 13 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 192,188  [0x10422a61c,0x10422a618]
                + ! : | 13 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5068  [0x10422c404]
                + ! : | + 6 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 420,180,...  [0x10422a7f0,0x10422a700,...]
                + ! : | + 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 276  [0x10422a760]
                + ! : | + ! 4 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in baseline) + 60  [0x10428d084]
                + ! : | + !   3 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 120  [0x10428d3e0]
                + ! : | + !   : 3 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 192,308  [0x1844efa50,0x1844efac4]
                + ! : | + !   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 108  [0x10428d3d4]
                + ! : | + !     1 _RNvCsjVqd8RsBhQu_7___rustc35___rust_no_alloc_shim_is_unstable_v2  (in baseline) + 0  [0x1041921f8]
                + ! : | + 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 564  [0x10422a880]
                + ! : | + ! 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 68  [0x1042295fc]
                + ! : | + 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 948  [0x10422aa00]
                + ! : | +   1 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners23scan_closing_code_fence  (in baseline) + 92  [0x1042457e8]
                + ! : | 10 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 8160  [0x10422d018]
                + ! : | + 10 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 272,460,...  [0x104245414,0x1042454d0,...]
                + ! : | 7 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 644  [0x10422983c]
                + ! : | 7 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 1820  [0x10422b754]
                + ! : | + 5 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 20,128,...  [0x104244a04,0x104244a70,...]
                + ! : | + 2 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 492  [0x104244bdc]
                + ! : | +   2 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline) + 8,40  [0x104244890,0x1042448b0]
                + ! : | 7 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 8468  [0x10422d14c]
                + ! : | + 7 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 68,136,...  [0x1042295fc,0x104229640,...]
                + ! : | 6 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 9336  [0x10422d4b0]
                + ! : | + 6 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 20,60,...  [0x10422a570,0x10422a598,...]
                + ! : | 5 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5692  [0x10422c674]
                + ! : | + 5 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 0,88,...  [0x104245304,0x10424535c,...]
                + ! : | 5 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6516  [0x10422c9ac]
                + ! : | + 5 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 20,116  [0x10422a570,0x10422a5d0]
                + ! : | 5 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 9244  [0x10422d454]
                + ! : | + 5 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 116,20,...  [0x10422a5d0,0x10422a570,...]
                + ! : | 4 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5016  [0x10422c3d0]
                + ! : | + 2 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners15scan_code_fence  (in baseline) + 120  [0x104245574]
                + ! : | + ! 2 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 120,180  [0x10424537c,0x1042453b8]
                + ! : | + 2 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners15scan_code_fence  (in baseline) + 44,152  [0x104245528,0x104245594]
                + ! : | 4 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5660  [0x10422c654]
                + ! : | + 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline) + 24,188,...  [0x104229e08,0x104229eac,...]
                + ! : | 4 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 10328  [0x10422d890]
                + ! : | + 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_html  (in baseline) + 36,116,...  [0x104229cf8,0x104229d48,...]
                + ! : | 3 _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in baseline) + 3196,3204,...  [0x10424982c,0x104249834,...]
                + ! : | 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10table_head  (in baseline) + 356  [0x104229ca4]
                + ! : | 3 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 2728  [0x10422bae0]
                + ! : | + 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 60,120,...  [0x10422a598,0x10422a5d4,...]
                + ! : | 3 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 7224  [0x10422cc70]
                + ! : | + 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15list_interrupts  (in baseline) + 72  [0x104229f7c]
                + ! : | + ! 2 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 492  [0x104244bdc]
                + ! : | + !   2 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline) + 40,80  [0x1042448b0,0x1042448d8]
                + ! : | + 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10interrupts  (in baseline) + 348  [0x1042299cc]
                + ! : | 3 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 7308  [0x10422ccc4]
                + ! : | + 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10interrupts  (in baseline) + 0  [0x104229870]
                + ! : | + 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15list_interrupts  (in baseline) + 72  [0x104229f7c]
                + ! : | +   1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 492  [0x104244bdc]
                + ! : | +     1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline) + 180  [0x10424493c]
                + ! : | 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 436  [0x10422a214]
                + ! : | 2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 164  [0x10422b0dc]
                + ! : | + 1 _RNvCsjVqd8RsBhQu_7___rustc11___rdl_alloc  (in baseline) + 0  [0x10425cab0]
                + ! : | + 1 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 352  [0x1844efaf0]
                + ! : | 2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 2636  [0x10422ba84]
                + ! : | + 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 60,116  [0x10422a598,0x10422a5d0]
                + ! : | 2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5352  [0x10422c520]
                + ! : | + 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline) + 24,148  [0x104229e08,0x104229e84]
                + ! : | 2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 7264  [0x10422cc98]
                + ! : | + 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10interrupts  (in baseline) + 52,688  [0x1042298a4,0x104229b20]
                + ! : | 2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 8384  [0x10422d0f8]
                + ! : | + 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 20,116  [0x10422a570,0x10422a5d0]
                + ! : | 1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser4htmlNtB2_4Html5start  (in baseline) + 1568  [0x1042373c4]
                + ! : | 1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 672  [0x104244c90]
                + ! : | 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline) + 248  [0x104229ee8]
                + ! : | 1 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 128  [0x10422b0b8]
                + ! : | + 1 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 44  [0x1844ef9bc]
                + ! : | 1 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5412  [0x10422c55c]
                + ! : | + 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 156  [0x10422a5f8]
                + ! : | 1 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 10484  [0x10422d92c]
                + ! : |   1 _RINvMs_NtCs3vUkWdPtNor_5alloc3vecINtB5_3VecjE8dedup_byNCNvMNtCs8seiryzelau_13core_markdown11definitionsNtBV_11Definitions6finishs1_0EBX_  (in baseline) + 328  [0x10423bba0]
                + ! : 1 _RNvMNtCs8seiryzelau_13core_markdown12event_parserNtB2_11EventParser7prepare  (in baseline) + 220  [0x10423e70c]
                + ! 4 _RNvCs8seiryzelau_13core_markdown20to_html_with_options  (in baseline) + 224  [0x10423f79c]
                + ! : 2 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueINtNtCs8seiryzelau_13core_markdown19event_html_renderer17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringEEBG_  (in baseline) + 500,576  [0x10423f24c,0x10423f298]
                + ! : 1 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueINtNtCs8seiryzelau_13core_markdown19event_html_renderer17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringEEBG_  (in baseline) + 48  [0x10423f088]
                + ! : | 1 _xzm_free_tc  (in libsystem_malloc.dylib) + 312  [0x1844f19b0]
                + ! : 1 _RNvMsz_NtNtNtCs3vUkWdPtNor_5alloc11collections5btree3mapINtB5_8IntoIterNtNtBb_6string6StringjE10dying_nextCs8seiryzelau_13core_markdown  (in baseline) + 448  [0x104234914]
                + ! 1 _RNvCs8seiryzelau_13core_markdown20to_html_with_options  (in baseline) + 72  [0x10423f704]
                + ! : 1 _malloc_zone_malloc  (in libsystem_malloc.dylib) + 64  [0x1844f4530]
                + ! 1 _RNvCs8seiryzelau_13core_markdown20to_html_with_options  (in baseline) + 76  [0x10423f708]
                + 2 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 9268,9292  [0x1041792ac,0x1041792c4]
                8 _RNvCseVgRDH8534i_19markdown_comparison4main  (in baseline) + 1420  [0x10417a28c]
                + 5 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! 5 mach_absolute_time  (in libsystem_kernel.dylib) + 108,16  [0x1846890f8,0x18468909c]
                + 2 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 96,100  [0x1844ed6e4,0x1844ed6e8]
                + 1 _xzm_free_tc  (in libsystem_malloc.dylib) + 104  [0x1844f18e0]
                1 _RNvCseVgRDH8534i_19markdown_comparison4main  (in baseline) + 1348  [0x10417a244]
                  1 _RNvMNtCs1coMeGJvsuS_3std4timeNtB2_7Instant7elapsed  (in baseline) + 28  [0x10425cd9c]
                    1 _RNvMNtNtNtNtCs1coMeGJvsuS_3std3sys3pal4unix4timeNtB2_8Timespec3now  (in baseline) + 24  [0x10425d6bc]
                      1 clock_gettime  (in libsystem_c.dylib) + 60  [0x184564100]
                        1 clock_gettime_nsec_np  (in libsystem_c.dylib) + 384  [0x1845561ac]
                          1 mach_absolute_time  (in libsystem_kernel.dylib) + 108  [0x1846890f8]

Total number in stack (recursive counted multiple, when >=5):
        14       _platform_memmove  (in libsystem_platform.dylib) + 0  [0x1846d7d60]
        10       _xzm_free  (in libsystem_malloc.dylib) + 0  [0x1844ec700]
        10       mach_absolute_time  (in libsystem_kernel.dylib) + 0  [0x18468908c]
        9       _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 0  [0x10422a55c]
        8       _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 0  [0x1042295b8]
        8       _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x10428d3c4]
        8       __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
        8       _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
        8       _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
        8       xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 0  [0x1844e5010]
        8       xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
        7       _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 0  [0x10428d368]
        7       _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 0  [0x104245304]
        7       _xzm_malloc_tc  (in libsystem_malloc.dylib) + 0  [0x1844ef990]
        7       xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
        7       xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 0  [0x1844e4304]
        6       _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 120  [0x10428d3e0]
        6       _malloc_zone_realloc  (in libsystem_malloc.dylib) + 0  [0x1844f4a98]
        6       _realloc  (in libsystem_malloc.dylib) + 0  [0x1844f5190]
        6       _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
        6       _xzm_malloc  (in libsystem_malloc.dylib) + 0  [0x1844e7df4]
        6       _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 0  [0x1844e8a4c]
        6       xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
        5       DYLD-STUB$$memcpy  (in baseline) + 0  [0x104293168]
        5       _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in baseline) + 0  [0x1042221d0]
        5       __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 0  [0x1844ed684]

Sort by top of stack, same collapsed (when >= 5):
        _RINvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB3_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE12render_innerKb0_NtNtB5_12event_parser11EventParserEB5_  (in baseline)        492
        _RNvNtCs8seiryzelau_13core_markdown13inline_parser8resource  (in baseline)        398
        _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EEB7_  (in baseline)        189
        _RINvNtNtCs8seiryzelau_13core_markdown4util12sanitize_uri15write_sanitizedNtNtB6_6stream11StreamErrorNCNvMNtB6_19event_html_rendererINtB1F_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE11destination0EB6_  (in baseline)        183
        _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline)        142
        _platform_memmove  (in libsystem_platform.dylib)        121
        _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown6stream9EventKindEBF_  (in baseline)        95
        _RNvMNtCs8seiryzelau_13core_markdown19event_html_rendererINtB2_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE7escapedB4_  (in baseline)        91
        _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline)        80
        mach_absolute_time  (in libsystem_kernel.dylib)        77
        _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in baseline)        74
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline)        60
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline)        47
        _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_EB7_  (in baseline)        24
        xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib)        23
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline)        21
        _RNvNtCsglYb6d7nGNF_6memchr6memmem4find  (in baseline)        20
        _RINvNtNtCs8seiryzelau_13core_markdown4util9tagfilter14write_filteredNtNtB6_6stream11StreamErrorNCINvMNtB6_19event_html_rendererINtB1B_17EventHtmlRendererNtNtCs3vUkWdPtNor_5alloc6string6StringE9event_refKb0_E0EB6_  (in baseline)        19
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline)        18
        _xzm_free  (in libsystem_malloc.dylib)        18
        _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in baseline)        16
        _malloc_zone_realloc  (in libsystem_malloc.dylib)        15
        _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in baseline)        14
        _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib)        14
        _RNvMNtCs8seiryzelau_13core_markdown6streamNtB2_4Text7resolve  (in baseline)        13
        xzm_malloc_zone_size  (in libsystem_malloc.dylib)        13
        _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser18suppress_autolinks  (in baseline)        11
        _xzm_malloc_tc  (in libsystem_malloc.dylib)        11
        __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib)        10
        _xzm_malloc  (in libsystem_malloc.dylib)        10
        _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline)        9
        _realloc  (in libsystem_malloc.dylib)        9
        DYLD-STUB$$memcpy  (in baseline)        8
        _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline)        8
        _RNvNtNtCs8seiryzelau_13core_markdown13inline_parser8autolink3web  (in baseline)        8
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline)        6
        _RNvMNtCs9nEiEE0E2Vj_4core6resultINtB2_6ResultReNtNtCs8seiryzelau_13core_markdown6stream11StreamErrorE6expectBN_  (in baseline)        5
        _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline)        5
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10interrupts  (in baseline)        5
        _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser5value  (in baseline)        5
        _RNvNtNtCs8seiryzelau_13core_markdown4util19character_reference4scan  (in baseline)        5
        _xzm_free_tc  (in libsystem_malloc.dylib)        5
        _xzm_xzone_free_freelist  (in libsystem_malloc.dylib)        5

Binary Images:
       0x104158000 -        0x10431e66f +baseline (0) <769F5531-DB9E-306E-999A-643EE6A203C3> /tmp/*/baseline
       0x184244000 -        0x1842935f7  libobjc.A.dylib (973.1) <C0680DF6-9900-3C29-A071-95A031686EF8> /usr/lib/libobjc.A.dylib
       0x184294000 -        0x18429e23f  libsharedcache.dylib (0) <BBF95357-BEBF-3D89-8900-2BBB14A667C5> /usr/lib/libsharedcache.dylib
       0x18429f000 -        0x1842c5d3b  libdyld.dylib (27062) <62863BCA-DD60-3D32-A9DB-89099BA6F3D7> /usr/lib/system/libdyld.dylib
       0x1842c6000 -        0x1843856e3  dyld (1.0.0 - 27062) <D341DDCB-7969-3A9C-8E03-0CF4751398A9> /usr/lib/dyld
       0x184386000 -        0x18438901f  libsystem_blocks.dylib (98.1) <6F304731-D95D-3501-B4AD-F2934F7F2446> /usr/lib/system/libsystem_blocks.dylib
       0x18438a000 -        0x1843df0df  libxpc.dylib (3298.1.1) <0791121F-B5FC-3F84-BF04-115E86D2D882> /usr/lib/system/libxpc.dylib
       0x1843e0000 -        0x1843ffc13  libsystem_trace.dylib (1966.1.1) <B48A8E3E-A12A-3342-8321-428B555E965E> /usr/lib/system/libsystem_trace.dylib
       0x184400000 -        0x1844b4f27  libcorecrypto.dylib (2109.0.22) <807AA6C9-5D8A-3CA5-B4CE-FACE5296EF6A> /usr/lib/system/libcorecrypto.dylib
       0x1844b5000 -        0x18450ac5f  libsystem_malloc.dylib (886.0.8) <2339CB57-FE5A-3154-A206-A76059C749EB> /usr/lib/system/libsystem_malloc.dylib
       0x18450b000 -        0x18455119f  libdispatch.dylib (1605.0.2) <022BF08F-0B3A-3225-9E65-16D1553CE90D> /usr/lib/system/libdispatch.dylib
       0x184552000 -        0x184554d2b  libsystem_featureflags.dylib (108) <20C1CAB2-1F13-3426-8146-9CAE9FF2A33D> /usr/lib/system/libsystem_featureflags.dylib
       0x184555000 -        0x1845d7ca3  libsystem_c.dylib (1786.0.3) <FBA7B23E-AA60-3A90-9AA4-A7A2E0AD63EE> /usr/lib/system/libsystem_c.dylib
       0x1845d8000 -        0x18466d033  libc++.1.dylib (2200.27) <1E9BA4AA-B5DA-3CF3-80AC-4B880049573F> /usr/lib/libc++.1.dylib
       0x18466e000 -        0x184687eff  libc++abi.dylib (2200.27) <A21743EE-6E1C-3E74-97EA-7AF793DE4BDF> /usr/lib/libc++abi.dylib
       0x184688000 -        0x1846c69ab  libsystem_kernel.dylib (13432.1.9) <F63BF418-8F75-34A4-AAF1-8CAF2B9B6A05> /usr/lib/system/libsystem_kernel.dylib
       0x1846c7000 -        0x1846d391b  libsystem_pthread.dylib (553.0.1) <5A1828C3-CBC2-3B85-BD07-C8ED10021A41> /usr/lib/system/libsystem_pthread.dylib
       0x1846d4000 -        0x1846dd4f3  libsystem_platform.dylib (402.0.1.0.1) <080E4444-A0FB-3913-9756-4E470015F32F> /usr/lib/system/libsystem_platform.dylib
       0x1846de000 -        0x18470c903  libsystem_info.dylib (603) <BC387AEB-1CEF-3513-92D7-D7F913596711> /usr/lib/system/libsystem_info.dylib
       0x188836000 -        0x18883fb13  libsystem_darwin.dylib (1786.0.3) <4E66C888-993C-3E6A-A8DA-A949C01C5B67> /usr/lib/system/libsystem_darwin.dylib
       0x188c90000 -        0x188ca1b8b  libsystem_notify.dylib (368) <58FD36D8-37A7-311C-80F2-8E64DD8710CF> /usr/lib/system/libsystem_notify.dylib
       0x18aded000 -        0x18ae07d93  libsystem_networkextension.dylib (2340.1.2) <22E1D190-486F-324F-ABA4-F36AB841BFE9> /usr/lib/system/libsystem_networkextension.dylib
       0x18ae95000 -        0x18aeac247  libsystem_asl.dylib (409) <B4D449B7-A821-3A9A-8019-E917B291F10A> /usr/lib/system/libsystem_asl.dylib
       0x18be40000 -        0x18be40f2f  libobjcMsgSend.dylib (973.1) <41179EDE-DC97-3BBE-8848-6400D12C1436> /usr/lib/objc/libobjcMsgSend.dylib
       0x18cf8c000 -        0x18cf93edf  libsystem_symptoms.dylib (2394.0.4) <60EE7884-9F4E-3184-A6AC-FA40A7A0297D> /usr/lib/system/libsystem_symptoms.dylib
       0x191324000 -        0x19135eaeb  libsystem_containermanager.dylib (833.0.8.0.1) <08A57205-555D-3792-8931-9D5B585AF326> /usr/lib/system/libsystem_containermanager.dylib
       0x192977000 -        0x19297b317  libsystem_configuration.dylib (1446) <F3EB66A7-7A24-3AE5-B6E8-9A37BB00F119> /usr/lib/system/libsystem_configuration.dylib
       0x19297c000 -        0x192982e03  libsystem_sandbox.dylib (3051.0.52) <1E892B56-092E-3832-BDE3-DCE356D7A4FA> /usr/lib/system/libsystem_sandbox.dylib
       0x193e40000 -        0x193e40f2f  libobjcMsgSend1.dylib (973.1) <B40D9B2A-E1EE-37ED-8004-711A1F263DE1> /usr/lib/objc/libobjcMsgSend1.dylib
       0x194560000 -        0x194562f93  libquarantine.dylib (217.0.4) <7FD4AE22-86EF-382B-83F5-ADF9336C1160> /usr/lib/system/libquarantine.dylib
       0x194c72000 -        0x194c781e7  libsystem_coreservices.dylib (203) <57248E07-11A5-3857-918E-4A3A63B69FE8> /usr/lib/system/libsystem_coreservices.dylib
       0x19523a000 -        0x195277b27  libsystem_m.dylib (3326.0.1) <A3FB340F-3ED5-30F4-8B64-9D5860F64D35> /usr/lib/system/libsystem_m.dylib
       0x195279000 -        0x19527c4f7  libmacho.dylib (27062) <50DEADEC-3E99-3519-AFC3-4A3FEB3F14C3> /usr/lib/system/libmacho.dylib
       0x195296000 -        0x1952a2707  libcommonCrypto.dylib (600041) <41C99F45-C5E6-39DB-B1F2-A1BEA9D242A4> /usr/lib/system/libcommonCrypto.dylib
       0x1952a3000 -        0x1952acc87  libunwind.dylib (2200.5) <3070AB81-B082-39E8-8A00-EF88DDE9AC47> /usr/lib/system/libunwind.dylib
       0x1952b4000 -        0x1952be7eb  libcopyfile.dylib (260.0.3) <72D95AF9-BF5E-3A84-81A6-BCC5BDB99857> /usr/lib/system/libcopyfile.dylib
       0x1952bf000 -        0x1952c28bf  libcompiler_rt.dylib (103.4) <DFB5CE7F-A36E-36AA-BECE-1392D3D43607> /usr/lib/system/libcompiler_rt.dylib
       0x1952c3000 -        0x1952c8077  libsystem_collections.dylib (1786.0.3) <1E8022D4-5A37-3A7A-8936-603E6FA88358> /usr/lib/system/libsystem_collections.dylib
       0x1952c9000 -        0x1952cbf1f  libsystem_secinit.dylib (182) <DE037464-4C5D-3E96-A33F-2A4557CC6A20> /usr/lib/system/libsystem_secinit.dylib
       0x1952cc000 -        0x1952ce97f  libremovefile.dylib (96) <E6E6DFCF-6B2C-3F30-A59D-816CAB1190CE> /usr/lib/system/libremovefile.dylib
       0x1952cf000 -        0x1952cfe27  libkeymgr.dylib (31) <5EC997EF-3ADA-360B-9FCD-5F940C83FA4E> /usr/lib/system/libkeymgr.dylib
       0x1952d0000 -        0x1952d8af7  libsystem_dnssd.dylib (3111.0.5.0.1) <DE22096F-1E5B-3D6E-8164-771582DD6391> /usr/lib/system/libsystem_dnssd.dylib
       0x1952d9000 -        0x1952ddf1b  libcache.dylib (95) <80BAE197-E285-3F6E-A1EE-B77FE37D7E5D> /usr/lib/system/libcache.dylib
       0x1952de000 -        0x1952df8f3  libSystem.B.dylib (1359) <4FDC9AA6-B344-37FE-B8C6-A4C94A038F57> /usr/lib/libSystem.B.dylib
       0x19be40000 -        0x19be40f2f  libobjcMsgSend2.dylib (973.1) <BD27A84B-C9AE-3282-BBEA-3B6119837B5A> /usr/lib/objc/libobjcMsgSend2.dylib
       0x1a3e40000 -        0x1a3e40f2f  libobjcMsgSend3.dylib (973.1) <C0860D68-DDFC-3BD7-8B06-DB0645CBBED4> /usr/lib/objc/libobjcMsgSend3.dylib
       0x1abe40000 -        0x1abe40f2f  libobjcMsgSend4.dylib (973.1) <A6153BF5-622B-3B01-81B6-F64A365EF613> /usr/lib/objc/libobjcMsgSend4.dylib
       0x1b3e40000 -        0x1b3e40f2f  libobjcMsgSend5.dylib (973.1) <3913A71C-B29A-3AEA-820B-BEC40AC1861A> /usr/lib/objc/libobjcMsgSend5.dylib
       0x1bbe40000 -        0x1bbe40f2f  libobjcMsgSend6.dylib (973.1) <9BC523A3-E167-3F6C-8CAE-0F3EBA671791> /usr/lib/objc/libobjcMsgSend6.dylib
       0x1c3e40000 -        0x1c3e40f2f  libobjcMsgSend7.dylib (973.1) <248B7BCE-5B4C-34C7-A340-43D5228628C5> /usr/lib/objc/libobjcMsgSend7.dylib
       0x1cbe40000 -        0x1cbe40f2f  libobjcMsgSend8.dylib (973.1) <3E041BAD-A8E8-3069-B741-78CD1A45B176> /usr/lib/objc/libobjcMsgSend8.dylib
       0x1d3e40000 -        0x1d3e40f2f  libobjcMsgSend9.dylib (973.1) <34A67969-21A0-39D6-BB81-8FDA5A2409DB> /usr/lib/objc/libobjcMsgSend9.dylib
       0x1dbe40000 -        0x1dbe40f2f  libobjcMsgSend10.dylib (973.1) <678186C0-8EAD-3B35-8CBB-00285B41E4A0> /usr/lib/objc/libobjcMsgSend10.dylib
       0x1e3e40000 -        0x1e3e40f2f  libobjcMsgSend11.dylib (973.1) <E05CB08C-E956-36FA-8967-AE8E346A8D2C> /usr/lib/objc/libobjcMsgSend11.dylib
       0x20be40000 -        0x20be40f2f  libobjcMsgSend12.dylib (973.1) <10AB03AA-FF1F-3FDC-9DFB-BFC40042C501> /usr/lib/objc/libobjcMsgSend12.dylib
       0x213e40000 -        0x213e40f2f  libobjcMsgSend13.dylib (973.1) <ABF53427-FA6F-3D0D-8F9D-7AD795CA5C92> /usr/lib/objc/libobjcMsgSend13.dylib
       0x21be40000 -        0x21be40f2f  libobjcMsgSend14.dylib (973.1) <9A844C46-A6DA-34D4-8EBF-2AD775C30684> /usr/lib/objc/libobjcMsgSend14.dylib
       0x223e40000 -        0x223e40f2f  libobjcMsgSend15.dylib (973.1) <7C995666-2B2D-3284-AA0A-EBF7C922838E> /usr/lib/objc/libobjcMsgSend15.dylib
       0x22be40000 -        0x22be40f2f  libobjcMsgSend16.dylib (973.1) <B6C0E14B-53AE-3E22-9ED5-1729C49F46F2> /usr/lib/objc/libobjcMsgSend16.dylib
       0x233e40000 -        0x233e40f2f  libobjcMsgSend17.dylib (973.1) <07B4CF85-251B-301B-832B-20B315A59E19> /usr/lib/objc/libobjcMsgSend17.dylib
       0x23be40000 -        0x23be40f2f  libobjcMsgSend18.dylib (973.1) <43E575B7-04DB-3999-A633-1A3B638BA6E3> /usr/lib/objc/libobjcMsgSend18.dylib
       0x243e40000 -        0x243e40f2f  libobjcMsgSend19.dylib (973.1) <736F4D85-76F7-3B28-8D87-C07E8F7A0EF4> /usr/lib/objc/libobjcMsgSend19.dylib
       0x24be40000 -        0x24be40f2f  libobjcMsgSend20.dylib (973.1) <74E67C8B-6BCA-3184-A18E-A97F370052C6> /usr/lib/objc/libobjcMsgSend20.dylib
       0x253e40000 -        0x253e40f2f  libobjcMsgSend21.dylib (973.1) <CC0D732F-98E7-3888-9E15-70984DA2FB04> /usr/lib/objc/libobjcMsgSend21.dylib
       0x25be40000 -        0x25be40f2f  libobjcMsgSend22.dylib (973.1) <85A60286-5DE3-32BA-B18C-2A498B065C88> /usr/lib/objc/libobjcMsgSend22.dylib
       0x263e40000 -        0x263e40f2f  libobjcMsgSend23.dylib (973.1) <5452A0D2-6B19-39BE-ADDD-80B7BCDE3A98> /usr/lib/objc/libobjcMsgSend23.dylib
       0x26be40000 -        0x26be40f2f  libobjcMsgSend24.dylib (973.1) <94BBF2D6-722B-350D-8557-4D25A8E8D53A> /usr/lib/objc/libobjcMsgSend24.dylib
       0x273e40000 -        0x273e40f2f  libobjcMsgSend25.dylib (973.1) <35481387-5A8E-3AE4-86A6-94CEB3CC8726> /usr/lib/objc/libobjcMsgSend25.dylib
       0x28be40000 -        0x28be40f2f  libobjcMsgSend26.dylib (973.1) <9E0C8664-E7F4-39D1-AAFC-BD92B255E4E8> /usr/lib/objc/libobjcMsgSend26.dylib
       0x293e40000 -        0x293e40f2f  libobjcMsgSend27.dylib (973.1) <FD424935-55A9-3650-955A-EED3441A1D19> /usr/lib/objc/libobjcMsgSend27.dylib
       0x29be40000 -        0x29be40f2f  libobjcMsgSend28.dylib (973.1) <09BA7B97-7DF7-3C7F-932A-B6847662FC49> /usr/lib/objc/libobjcMsgSend28.dylib
       0x2a3e40000 -        0x2a3e40f2f  libobjcMsgSend29.dylib (973.1) <36D5BA3F-2139-30B0-8558-556764BE9813> /usr/lib/objc/libobjcMsgSend29.dylib
       0x2abe40000 -        0x2abe40f2f  libobjcMsgSend30.dylib (973.1) <9F05564A-9D12-372C-98FC-E9F0E6BE4F04> /usr/lib/objc/libobjcMsgSend30.dylib
       0x2b0b5a000 -        0x2b0b60fe5  libRosetta.dylib (385) <E359944B-D230-33F9-A04E-0C3B17C3326E> /usr/lib/libRosetta.dylib
       0x2b1549000 -        0x2b154c75b  libsystem_darwindirectory.dylib (129.0.1) <61264923-2AA5-3658-B8C4-550C71E9D4B3> /usr/lib/system/libsystem_darwindirectory.dylib
       0x2b154d000 -        0x2b1557d9b  libsystem_eligibility.dylib (446.1.3) <EDDE8E9C-A2CF-3931-BBB3-321CB852EB30> /usr/lib/system/libsystem_eligibility.dylib
       0x2b1558000 -        0x2b156142b  libsystem_sanitizers.dylib (32) <7138ED99-7AA0-34EA-B35B-20EF6ADB1EED> /usr/lib/system/libsystem_sanitizers.dylib
       0x2b1562000 -        0x2b1562a13  libsystem_trial.dylib (511) <6AE48824-EC44-3A8C-B501-BE57DBE892E7> /usr/lib/system/libsystem_trial.dylib
       0x2b3e40000 -        0x2b3e40f2f  libobjcMsgSend31.dylib (973.1) <0985E20F-78C3-3466-A2B2-DBB95F7104A3> /usr/lib/objc/libobjcMsgSend31.dylib
       0x2bbe40000 -        0x2bbe40f2f  libobjcMsgSend32.dylib (973.1) <0D309D58-D576-3E5D-AD4B-6D55AB491702> /usr/lib/objc/libobjcMsgSend32.dylib
       0x2c3e40000 -        0x2c3e40f2f  libobjcMsgSend33.dylib (973.1) <346E0484-48FA-369B-8A64-93B5F5341CFE> /usr/lib/objc/libobjcMsgSend33.dylib
       0x2cbe40000 -        0x2cbe40f2f  libobjcMsgSend34.dylib (973.1) <6A31F809-BCBE-3E01-A367-E91FDACCE324> /usr/lib/objc/libobjcMsgSend34.dylib
