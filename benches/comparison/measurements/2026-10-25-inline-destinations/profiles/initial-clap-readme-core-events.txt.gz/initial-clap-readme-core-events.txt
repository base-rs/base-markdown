Analysis of sampling baseline (pid 9923) every 1 millisecond
Process:         baseline [9923]
Path:            /private/tmp/*/baseline
Load Address:    0x1046e4000
Identifier:      baseline
Version:         0
Code Type:       ARM64
Platform:        macOS
Parent Process:  python3.13 [9888]
Target Type:     live task

Date/Time:       2026-10-25 11:29:28.701 +1300
Launch Time:     2026-10-25 11:29:28.171 +1300
OS Version:      macOS 27.0.1 (26A434)
Report Version:  7
Analysis Tool:   /usr/bin/sample

Physical footprint:         1984K
Physical footprint (peak):  1984K
Idle exit:                  untracked
----

Call graph:
    2492 Thread_43524615   DispatchQueue_1: com.apple.main-thread  (serial)
      2492 start  (in dyld) + 6688  [0x1842f7e80]
        2492 main  (in baseline) + 52  [0x104707c20]
          2492 _RNvNtCs1coMeGJvsuS_3std2rt19lang_start_internal  (in baseline) + 936  [0x1047f6030]
            2492 _RNCINvNtCs1coMeGJvsuS_3std2rt10lang_startuE0CseVgRDH8534i_19markdown_comparison  (in baseline) + 16  [0x10471a6d4]
              2492 _RINvNtNtCs1coMeGJvsuS_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECseVgRDH8534i_19markdown_comparison  (in baseline) + 12  [0x10471b000]
                2483 _RNvCseVgRDH8534i_19markdown_comparison4main  (in baseline) + 1380  [0x104706264]
                + 1038 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 4088  [0x104703e70]
                + ! 525 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EECseVgRDH8534i_19markdown_comparison  (in baseline) + 2992  [0x1046ed164]
                + ! : 525 _RNvNtCs8seiryzelau_13core_markdown13inline_parser8resource  (in baseline) + 392,460,...  [0x1047a4450,0x1047a4494,...]
                + ! 215 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EECseVgRDH8534i_19markdown_comparison  (in baseline) + 396,1028,...  [0x1046ec740,0x1046ec9b8,...]
                + ! 77 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EECseVgRDH8534i_19markdown_comparison  (in baseline) + 4928  [0x1046ed8f4]
                + ! : 61 _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser6append  (in baseline) + 64  [0x1047a3e64]
                + ! : | 60 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in baseline) + 60  [0x104819084]
                + ! : | + 60 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x1048193c4]
                + ! : | +   57 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | +   ! 56 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | +   ! : 37 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | +   ! : | 19 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | +   ! : | + 19 mach_absolute_time  (in libsystem_kernel.dylib) + 108,16,...  [0x1846890f8,0x18468909c,...]
                + ! : | +   ! : | 12 _xzm_free  (in libsystem_malloc.dylib) + 564,80,...  [0x1844ec934,0x1844ec750,...]
                + ! : | +   ! : | 6 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 148,96,...  [0x1844ed718,0x1844ed6e4,...]
                + ! : | +   ! : 7 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | +   ! : | 5 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 92,244,...  [0x1844e8aa8,0x1844e8b40,...]
                + ! : | +   ! : | 2 _xzm_malloc  (in libsystem_malloc.dylib) + 0,276  [0x1844e7df4,0x1844e7f08]
                + ! : | +   ! : 7 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 64,80,...  [0x1844e5050,0x1844e5060,...]
                + ! : | +   ! : 4 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | +   ! : | 3 _platform_memmove  (in libsystem_platform.dylib) + 180,196  [0x1846d7e14,0x1846d7e24]
                + ! : | +   ! : | 1 DYLD-STUB$$_platform_memmove  (in libsystem_malloc.dylib) + 12  [0x18450a5ac]
                + ! : | +   ! : 1 _xzm_free  (in libsystem_malloc.dylib) + 976  [0x1844ecad0]
                + ! : | +   ! 1 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | +   2 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | +   ! 2 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 32,188  [0x1844e4324,0x1844e43c0]
                + ! : | +   1 _realloc  (in libsystem_malloc.dylib) + 412  [0x1844f532c]
                + ! : | 1 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in baseline) + 60  [0x104819084]
                + ! : 16 _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser6append  (in baseline) + 76,44,...  [0x1047a3e70,0x1047a3e50,...]
                + ! 39 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EECseVgRDH8534i_19markdown_comparison  (in baseline) + 3036  [0x1046ed190]
                + ! : 34 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser4LinkE8grow_oneBQ_  (in baseline) + 60  [0x10481914c]
                + ! : | 32 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x1048193c4]
                + ! : | + 29 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | + ! 28 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | + ! : 12 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | + ! : | 9 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | + ! : | + 8 mach_absolute_time  (in libsystem_kernel.dylib) + 108,112  [0x1846890f8,0x1846890fc]
                + ! : | + ! : | + 1 DYLD-STUB$$mach_absolute_time  (in libsystem_malloc.dylib) + 0  [0x18450a8a0]
                + ! : | + ! : | 3 _xzm_free  (in libsystem_malloc.dylib) + 200,564,...  [0x1844ec7c8,0x1844ec934,...]
                + ! : | + ! : 7 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 80,248,...  [0x1844e5060,0x1844e5108,...]
                + ! : | + ! : 5 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | + ! : | 4 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 256,0,...  [0x1844e8b4c,0x1844e8a4c,...]
                + ! : | + ! : | 1 _xzm_malloc  (in libsystem_malloc.dylib) + 208  [0x1844e7ec4]
                + ! : | + ! : 4 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | + ! :   4 _platform_memmove  (in libsystem_platform.dylib) + 180,204  [0x1846d7e14,0x1846d7e2c]
                + ! : | + ! 1 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 48  [0x1844f4ac8]
                + ! : | + 2 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | + ! 2 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 136,268  [0x1844e438c,0x1844e4410]
                + ! : | + 1 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 120  [0x1048193e0]
                + ! : | + 1 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 92  [0x1844ef9ec]
                + ! : | 1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 40  [0x104819390]
                + ! : 3 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser4LinkE8grow_oneBQ_  (in baseline) + 60,68  [0x10481914c,0x104819154]
                + ! : 2 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 168  [0x104819410]
                + ! 37 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EECseVgRDH8534i_19markdown_comparison  (in baseline) + 5704  [0x1046edbfc]
                + ! : 37 _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser6append  (in baseline) + 64  [0x1047a3e64]
                + ! :   37 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in baseline) + 60  [0x104819084]
                + ! :     37 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x1048193c4]
                + ! :       32 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! :       | 31 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! :       | + 11 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! :       | + ! 9 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! :       | + ! : 8 mach_absolute_time  (in libsystem_kernel.dylib) + 108,16  [0x1846890f8,0x18468909c]
                + ! :       | + ! : 1 DYLD-STUB$$mach_absolute_time  (in libsystem_malloc.dylib) + 12  [0x18450a8ac]
                + ! :       | + ! 2 _xzm_free  (in libsystem_malloc.dylib) + 28  [0x1844ec71c]
                + ! :       | + 9 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! :       | + ! 9 _platform_memmove  (in libsystem_platform.dylib) + 180,192  [0x1846d7e14,0x1846d7e20]
                + ! :       | + 7 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 400,24,...  [0x1844e51a0,0x1844e5028,...]
                + ! :       | + 2 _xzm_free  (in libsystem_malloc.dylib) + 968,972  [0x1844ecac8,0x1844ecacc]
                + ! :       | + 2 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! :       | +   2 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 88  [0x1844e8aa4]
                + ! :       | 1 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 100  [0x1844f4afc]
                + ! :       3 _realloc  (in libsystem_malloc.dylib) + 0,36,...  [0x1844f5190,0x1844f51b4,...]
                + ! :       1 _RNvCsjVqd8RsBhQu_7___rustc13___rdl_realloc  (in baseline) + 0  [0x1047e8b28]
                + ! :       1 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! :         1 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 460  [0x1844e44d0]
                + ! 37 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EECseVgRDH8534i_19markdown_comparison  (in baseline) + 7204  [0x1046ee1d8]
                + ! : 17 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_ECseVgRDH8534i_19markdown_comparison  (in baseline) + 836  [0x1046f2b1c]
                + ! : | 17 _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser12insert_after  (in baseline) + 88  [0x1047a29b4]
                + ! : |   15 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in baseline) + 60  [0x104819084]
                + ! : |   + 13 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x1048193c4]
                + ! : |   + ! 11 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : |   + ! : 10 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : |   + ! : | 3 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : |   + ! : | + 2 DYLD-STUB$$_platform_memmove  (in libsystem_malloc.dylib) + 12  [0x18450a5ac]
                + ! : |   + ! : | + 1 _platform_memmove  (in libsystem_platform.dylib) + 204  [0x1846d7e2c]
                + ! : |   + ! : | 3 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : |   + ! : | + 3 _xzm_free  (in libsystem_malloc.dylib) + 200,564,...  [0x1844ec7c8,0x1844ec934,...]
                + ! : |   + ! : | 3 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 400,764,...  [0x1844e51a0,0x1844e530c,...]
                + ! : |   + ! : | 1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : |   + ! : |   1 _xzm_malloc  (in libsystem_malloc.dylib) + 108  [0x1844e7e60]
                + ! : |   + ! : 1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1056  [0x1844e5430]
                + ! : |   + ! 1 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : |   + ! : 1 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 496  [0x1844e44f4]
                + ! : |   + ! 1 _realloc  (in libsystem_malloc.dylib) + 248  [0x1844f5288]
                + ! : |   + 2 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 8,36  [0x104819370,0x10481938c]
                + ! : |   1 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in baseline) + 60  [0x104819084]
                + ! : |   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 168  [0x104819410]
                + ! : 15 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_ECseVgRDH8534i_19markdown_comparison  (in baseline) + 32,1008,...  [0x1046f27f8,0x1046f2bc8,...]
                + ! : 2 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_ECseVgRDH8534i_19markdown_comparison  (in baseline) + 900  [0x1046f2b5c]
                + ! : | 2 _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser12insert_after  (in baseline) + 16,132  [0x1047a296c,0x1047a29e0]
                + ! : 2 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_ECseVgRDH8534i_19markdown_comparison  (in baseline) + 1148  [0x1046f2c54]
                + ! : | 2 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecjE8grow_oneCs5g3ZMj3eC3k_8markdown  (in baseline) + 60  [0x104818cdc]
                + ! : |   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs5g3ZMj3eC3k_8markdown  (in baseline) + 108  [0x104818d70]
                + ! : |   + 1 _RNvCsjVqd8RsBhQu_7___rustc35___rust_no_alloc_shim_is_unstable_v2  (in baseline) + 0  [0x10471e1f8]
                + ! : |   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs5g3ZMj3eC3k_8markdown  (in baseline) + 120  [0x104818d7c]
                + ! : |     1 _malloc_zone_malloc  (in libsystem_malloc.dylib) + 12  [0x1844f44fc]
                + ! : 1 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecjE8grow_oneCs5g3ZMj3eC3k_8markdown  (in baseline) + 80  [0x104818cf0]
                + ! 31 _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser6append  (in baseline) + 148,140,...  [0x1047a3eb8,0x1047a3eb0,...]
                + ! 27 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EECseVgRDH8534i_19markdown_comparison  (in baseline) + 5440  [0x1046edaf4]
                + ! : 27 _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser6append  (in baseline) + 76,100,...  [0x1047a3e70,0x1047a3e88,...]
                + ! 12 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EECseVgRDH8534i_19markdown_comparison  (in baseline) + 3120  [0x1046ed1e4]
                + ! : 12 _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser18suppress_autolinks  (in baseline) + 48,40,...  [0x1046f2dec,0x1046f2de4,...]
                + ! 12 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EECseVgRDH8534i_19markdown_comparison  (in baseline) + 3216  [0x1046ed244]
                + ! : 12 _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser6append  (in baseline) + 100,36,...  [0x1047a3e88,0x1047a3e48,...]
                + ! 7 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_ECseVgRDH8534i_19markdown_comparison  (in baseline) + 1232,1240  [0x1046f2ca8,0x1046f2cb0]
                + ! 5 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EECseVgRDH8534i_19markdown_comparison  (in baseline) + 5124  [0x1046ed9b8]
                + ! : 5 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser9DelimiterE8grow_oneBQ_  (in baseline) + 60  [0x104819278]
                + ! :   3 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 120  [0x1048193e0]
                + ! :   | 2 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 260,312  [0x1844efa94,0x1844efac8]
                + ! :   | 1 _malloc_zone_malloc  (in libsystem_malloc.dylib) + 44  [0x1844f451c]
                + ! :   2 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 40,100  [0x104819390,0x1048193cc]
                + ! 4 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EECseVgRDH8534i_19markdown_comparison  (in baseline) + 128  [0x1046ec634]
                + ! : 4 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in baseline) + 60  [0x104819084]
                + ! :   3 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 120  [0x1048193e0]
                + ! :   | 2 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 308  [0x1844efac4]
                + ! :   | 1 DYLD-STUB$$malloc  (in baseline) + 4  [0x10481f154]
                + ! :   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 108  [0x1048193d4]
                + ! :     1 _RNvCsjVqd8RsBhQu_7___rustc35___rust_no_alloc_shim_is_unstable_v2  (in baseline) + 0  [0x10471e1f8]
                + ! 3 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EECseVgRDH8534i_19markdown_comparison  (in baseline) + 1140  [0x1046eca28]
                + ! : 3 _RNvNtNtCs8seiryzelau_13core_markdown13inline_parser8autolink3web  (in baseline) + 24,536  [0x1047d3078,0x1047d3278]
                + ! 2 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EECseVgRDH8534i_19markdown_comparison  (in baseline) + 3092  [0x1046ed1c8]
                + ! : 2 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_ECseVgRDH8534i_19markdown_comparison  (in baseline) + 16  [0x1046f27e8]
                + ! 2 _RNvNtNtCs8seiryzelau_13core_markdown13inline_parser8autolink3web  (in baseline) + 1912,1928  [0x1047d37d8,0x1047d37e8]
                + ! 1 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EECseVgRDH8534i_19markdown_comparison  (in baseline) + 3708  [0x1046ed430]
                + ! : 1 _RNvNtNtCs8seiryzelau_13core_markdown4util4char8classify  (in baseline) + 104  [0x1047ce0c4]
                + ! 1 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EECseVgRDH8534i_19markdown_comparison  (in baseline) + 4956  [0x1046ed910]
                + ! : 1 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser4TickE8grow_oneBQ_  (in baseline) + 60  [0x1048191b0]
                + ! :   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 120  [0x1048193e0]
                + ! :     1 DYLD-STUB$$malloc  (in baseline) + 4  [0x10481f154]
                + ! 1 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown13inline_parser4LinkE8grow_oneBQ_  (in baseline) + 80  [0x104819160]
                + 636 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 332  [0x104702fc4]
                + ! 633 _RNvMNtCs8seiryzelau_13core_markdown12event_parserNtB2_11EventParser7prepare  (in baseline) + 44  [0x1047ca65c]
                + ! : 180 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 3688,768,...  [0x1047b7ea0,0x1047b7338,...]
                + ! : 78 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6664  [0x1047b8a40]
                + ! : | 66 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 76  [0x1047b65a8]
                + ! : | + 66 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4NodeE8grow_oneBQ_  (in baseline) + 60  [0x1048190e8]
                + ! : | +   66 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x1048193c4]
                + ! : | +     62 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : | +     ! 58 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : | +     ! : 25 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : | +     ! : | 25 _platform_memmove  (in libsystem_platform.dylib) + 180,0,...  [0x1846d7e14,0x1846d7d60,...]
                + ! : | +     ! : 23 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : | +     ! : | 18 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | +     ! : | + 18 mach_absolute_time  (in libsystem_kernel.dylib) + 108,112,...  [0x1846890f8,0x1846890fc,...]
                + ! : | +     ! : | 3 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 148,504,...  [0x1844ed718,0x1844ed87c,...]
                + ! : | +     ! : | 2 _xzm_free  (in libsystem_malloc.dylib) + 28,848  [0x1844ec71c,0x1844eca50]
                + ! : | +     ! : 6 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 24,996,...  [0x1844e5028,0x1844e53f4,...]
                + ! : | +     ! : 4 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : | +     ! :   2 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 456,536  [0x1844e8c14,0x1844e8c64]
                + ! : | +     ! :   1 _xzm_malloc  (in libsystem_malloc.dylib) + 488  [0x1844e7fdc]
                + ! : | +     ! :   1 _xzm_xzone_malloc_small_freelist  (in libsystem_malloc.dylib) + 92  [0x1844e8ea8]
                + ! : | +     ! 4 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 124,72  [0x1844f4b14,0x1844f4ae0]
                + ! : | +     2 _realloc  (in libsystem_malloc.dylib) + 248,252  [0x1844f5288,0x1844f528c]
                + ! : | +     1 _RNvCsjVqd8RsBhQu_7___rustc13___rdl_realloc  (in baseline) + 0  [0x1047e8b28]
                + ! : | +     1 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : | +       1 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 576  [0x1844e4544]
                + ! : | 12 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 156,60,...  [0x1047b65f8,0x1047b6598,...]
                + ! : 47 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6048  [0x1047b87d8]
                + ! : | 42 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10table_head  (in baseline) + 36  [0x1047b5b64]
                + ! : | + 18 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 72  [0x1047b60a8]
                + ! : | + ! 18 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 272,88,...  [0x1047d1414,0x1047d135c,...]
                + ! : | + 8 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 112  [0x1047b60d0]
                + ! : | + ! 8 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 4,12,...  [0x1047b55bc,0x1047b55c4,...]
                + ! : | + 7 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 400  [0x1047b61f0]
                + ! : | + ! 4 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 492  [0x1047d0bdc]
                + ! : | + ! : 4 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline) + 132,96,...  [0x1047d090c,0x1047d08e8,...]
                + ! : | + ! 3 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 148,52  [0x1047d0a84,0x1047d0a24]
                + ! : | + 7 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 40,112,...  [0x1047b6088,0x1047b60d0,...]
                + ! : | + 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 644  [0x1047b583c]
                + ! : | 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 436,428  [0x1047b6214,0x1047b620c]
                + ! : | 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10table_head  (in baseline) + 36  [0x1047b5b64]
                + ! : 37 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 7124  [0x1047b8c0c]
                + ! : | 19 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 72  [0x1047b60a8]
                + ! : | + 19 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 272,120,...  [0x1047d1414,0x1047d137c,...]
                + ! : | 6 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 112  [0x1047b60d0]
                + ! : | + 6 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 12,136,...  [0x1047b55c4,0x1047b5640,...]
                + ! : | 6 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 112,20,...  [0x1047b60d0,0x1047b6074,...]
                + ! : | 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 400  [0x1047b61f0]
                + ! : | + 3 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 20,64,...  [0x1047d0a04,0x1047d0a30,...]
                + ! : | + 1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 492  [0x1047d0bdc]
                + ! : | +   1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline) + 104  [0x1047d08f0]
                + ! : | 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 644  [0x1047b583c]
                + ! : 30 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 4640  [0x1047b8258]
                + ! : | 16 _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in baseline) + 168,636,...  [0x1047d4c58,0x1047d4e2c,...]
                + ! : | 11 _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in baseline) + 64  [0x1047d4bf0]
                + ! : | + 9 _RNvXNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fnINtB2_6FromFnNCNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB17_7Builder20definition_fragments0ENtNtNtB6_6traits8iterator8Iterator4nextB19_  (in baseline) + 280  [0x1047d8078]
                + ! : | + ! 9 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 272,280,...  [0x1047d1414,0x1047d141c,...]
                + ! : | + 2 _RNvXNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fnINtB2_6FromFnNCNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB17_7Builder20definition_fragments0ENtNtNtB6_6traits8iterator8Iterator4nextB19_  (in baseline) + 56  [0x1047d7f98]
                + ! : | 3 _RNvXNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fnINtB2_6FromFnNCNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB17_7Builder20definition_fragments0ENtNtNtB6_6traits8iterator8Iterator4nextB19_  (in baseline) + 688,684  [0x1047d8210,0x1047d820c]
                + ! : 26 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6712  [0x1047b8a70]
                + ! : | 26 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 12,68,...  [0x1047b55c4,0x1047b55fc,...]
                + ! : 25 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6620  [0x1047b8a14]
                + ! : | 25 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 272,120,...  [0x1047d1414,0x1047d137c,...]
                + ! : 22 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 656  [0x1047b72c8]
                + ! : | 22 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 4,72,...  [0x1047b55bc,0x1047b5600,...]
                + ! : 21 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 192,184,...  [0x1047b661c,0x1047b6614,...]
                + ! : 20 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 9276  [0x1047b9474]
                + ! : | 20 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown8document6NodeIdE8grow_oneBQ_  (in baseline) + 60  [0x104819340]
                + ! : |   19 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x1048193c4]
                + ! : |   + 10 _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
                + ! : |   + ! 7 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
                + ! : |   + ! : 3 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
                + ! : |   + ! : | 3 _xzm_malloc  (in libsystem_malloc.dylib) + 108,344  [0x1844e7e60,0x1844e7f4c]
                + ! : |   + ! : 2 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 280,896  [0x1844e5128,0x1844e5390]
                + ! : |   + ! : 1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
                + ! : |   + ! : | 1 DYLD-STUB$$_platform_memmove  (in libsystem_malloc.dylib) + 12  [0x18450a5ac]
                + ! : |   + ! : 1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
                + ! : |   + ! :   1 _xzm_free  (in libsystem_malloc.dylib) + 200  [0x1844ec7c8]
                + ! : |   + ! 2 _malloc_zone_realloc  (in libsystem_malloc.dylib) + 24,40  [0x1844f4ab0,0x1844f4ac0]
                + ! : |   + ! 1 xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1056  [0x1844e5430]
                + ! : |   + 7 _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
                + ! : |   + ! 7 xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 48,136,...  [0x1844e4334,0x1844e438c,...]
                + ! : |   + 2 _realloc  (in libsystem_malloc.dylib) + 20,412  [0x1844f51a4,0x1844f532c]
                + ! : |   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 36  [0x10481938c]
                + ! : 18 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5068  [0x1047b8404]
                + ! : | 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 564  [0x1047b6880]
                + ! : | + 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 40,68,...  [0x1047b55e0,0x1047b55fc,...]
                + ! : | 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 948  [0x1047b6a00]
                + ! : | + 4 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners23scan_closing_code_fence  (in baseline) + 20,64,...  [0x1047d17a0,0x1047d17cc,...]
                + ! : | 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 144  [0x1047b66dc]
                + ! : | + 3 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 120,156,...  [0x1047d137c,0x1047d13a0,...]
                + ! : | 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 276  [0x1047b6760]
                + ! : | + 2 _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in baseline) + 60  [0x104819084]
                + ! : | +   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 120  [0x1048193e0]
                + ! : | +   ! 1 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 0  [0x1844ef990]
                + ! : | +   1 _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 100  [0x1048193cc]
                + ! : | 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 376  [0x1047b67c4]
                + ! : | + 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 20,116  [0x1047b6570,0x1047b65d0]
                + ! : | 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 564,948  [0x1047b6880,0x1047b6a00]
                + ! : | 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 972  [0x1047b6a18]
                + ! : |   1 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 180  [0x1047d13b8]
                + ! : 17 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 8428  [0x1047b9124]
                + ! : | 17 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser4htmlNtB2_4Html6closed  (in baseline) + 1476  [0x1047c3aa0]
                + ! : |   14 _RNvNtCsglYb6d7nGNF_6memchr6memmem4find  (in baseline) + 184,252,...  [0x1047c3ef8,0x1047c3f3c,...]
                + ! : |   3 _RNvNtCsglYb6d7nGNF_6memchr6memmem4find  (in baseline) + 232  [0x1047c3f28]
                + ! : |     3 _RNvNtNtNtCsglYb6d7nGNF_6memchr4arch3all9rabinkarp12is_equal_raw  (in baseline) + 0,36  [0x10481a454,0x10481a478]
                + ! : 11 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 8468  [0x1047b914c]
                + ! : | 11 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 68,72,...  [0x1047b55fc,0x1047b5600,...]
                + ! : 10 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6516  [0x1047b89ac]
                + ! : | 10 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 20,116,...  [0x1047b6570,0x1047b65d0,...]
                + ! : 9 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 9336  [0x1047b94b0]
                + ! : | 9 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 20,116,...  [0x1047b6570,0x1047b65d0,...]
                + ! : 8 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 6488  [0x1047b8990]
                + ! : | 8 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline) + 24,244,...  [0x1047b5e08,0x1047b5ee4,...]
                + ! : 7 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 644,648  [0x1047b583c,0x1047b5840]
                + ! : 6 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5692  [0x1047b8674]
                + ! : | 6 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 156,0,...  [0x1047d13a0,0x1047d1304,...]
                + ! : 6 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 8160  [0x1047b9018]
                + ! : | 6 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 0,112,...  [0x1047d1304,0x1047d1374,...]
                + ! : 5 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 7264  [0x1047b8c98]
                + ! : | 5 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10interrupts  (in baseline) + 20,52,...  [0x1047b5884,0x1047b58a4,...]
                + ! : 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10table_head  (in baseline) + 356  [0x1047b5ca4]
                + ! : 4 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 1820  [0x1047b7754]
                + ! : | 2 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 492  [0x1047d0bdc]
                + ! : | + 2 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline) + 8,80  [0x1047d0890,0x1047d08d8]
                + ! : | 2 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 64,128  [0x1047d0a30,0x1047d0a70]
                + ! : 4 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5412  [0x1047b855c]
                + ! : | 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 20,116  [0x1047b6570,0x1047b65d0]
                + ! : 4 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5660  [0x1047b8654]
                + ! : | 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline) + 188,156,...  [0x1047b5eac,0x1047b5e8c,...]
                + ! : 4 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 7224  [0x1047b8c70]
                + ! : | 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10interrupts  (in baseline) + 348,388  [0x1047b59cc,0x1047b59f4]
                + ! : | 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15list_interrupts  (in baseline) + 72  [0x1047b5f7c]
                + ! : | + 1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 492  [0x1047d0bdc]
                + ! : | +   1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline) + 8  [0x1047d0890]
                + ! : | 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15list_interrupts  (in baseline) + 112  [0x1047b5fa4]
                + ! : 3 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 152  [0x1047b70d0]
                + ! : | 3 _RNvCsjVqd8RsBhQu_7___rustc35___rust_no_alloc_shim_is_unstable_v2  (in baseline) + 0  [0x10471e1f8]
                + ! : 3 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 164  [0x1047b70dc]
                + ! : | 3 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 92,144,...  [0x1844ef9ec,0x1844efa20,...]
                + ! : 3 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 10564  [0x1047b997c]
                + ! : | 2 _xzm_free_tc  (in libsystem_malloc.dylib) + 312,384  [0x1844f19b0,0x1844f19f8]
                + ! : | 1 DYLD-STUB$$free  (in baseline) + 4  [0x10481f124]
                + ! : 2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 128  [0x1047b70b8]
                + ! : | 1 _xzm_malloc_tc  (in libsystem_malloc.dylib) + 248  [0x1844efa88]
                + ! : | 1 _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 268  [0x1844e8b58]
                + ! : 2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5016  [0x1047b83d0]
                + ! : | 2 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners15scan_code_fence  (in baseline) + 120  [0x1047d1574]
                + ! : |   2 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 88  [0x1047d135c]
                + ! : 2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 5352  [0x1047b8520]
                + ! : | 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline) + 240,244  [0x1047b5ee0,0x1047b5ee4]
                + ! : 2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 7308  [0x1047b8cc4]
                + ! : | 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10interrupts  (in baseline) + 388  [0x1047b59f4]
                + ! : | 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15list_interrupts  (in baseline) + 72  [0x1047b5f7c]
                + ! : |   1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 180  [0x1047d0aa4]
                + ! : 2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 8384  [0x1047b90f8]
                + ! : | 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 60,116  [0x1047b6598,0x1047b65d0]
                + ! : 2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 9244  [0x1047b9454]
                + ! : | 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 20  [0x1047b6570]
                + ! : 2 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 10328  [0x1047b9890]
                + ! : | 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_html  (in baseline) + 68,156  [0x1047b5d18,0x1047b5d70]
                + ! : 1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser4htmlNtB2_4Html5start  (in baseline) + 1568  [0x1047c33c4]
                + ! : 1 _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 672  [0x1047d0c90]
                + ! : 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15list_interrupts  (in baseline) + 236  [0x1047b6020]
                + ! : 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline) + 436  [0x1047b6214]
                + ! : 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6fenced  (in baseline) + 1608  [0x1047b6c94]
                + ! : 1 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 2636  [0x1047b7a84]
                + ! : | 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 116  [0x1047b65d0]
                + ! : 1 _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners15scan_code_fence  (in baseline) + 232  [0x1047d15e4]
                + ! 2 _RNvMNtCs8seiryzelau_13core_markdown12event_parserNtB2_11EventParser7prepare  (in baseline) + 216,260  [0x1047ca708,0x1047ca734]
                + ! 1 _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline) + 10608  [0x1047b99a8]
                + 454 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 8480,524,...  [0x104704f98,0x104703084,...]
                + 133 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 572  [0x1047030b4]
                + ! 133 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown6stream9EventKindECseVgRDH8534i_19markdown_comparison  (in baseline) + 36,12,...  [0x104702600,0x1047025e8,...]
                + 113 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 3980  [0x104703e04]
                + ! 100 _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser7decoded  (in baseline) + 60  [0x1047a41a4]
                + ! : 79 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in baseline) + 320,228,...  [0x1047cec40,0x1047cebe4,...]
                + ! : 14 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in baseline) + 1100  [0x1047cef4c]
                + ! : | 14 _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in baseline) + 304,40,...  [0x1047ce6fc,0x1047ce5f4,...]
                + ! : 6 _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in baseline) + 832,828  [0x1047ce90c,0x1047ce908]
                + ! : 1 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in baseline) + 588  [0x1047ced4c]
                + ! :   1 _RNvNtNtCs8seiryzelau_13core_markdown4util19character_reference4scan  (in baseline) + 36  [0x1047d6c98]
                + ! 8 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in baseline) + 1176,1168  [0x1047cef98,0x1047cef90]
                + ! 5 _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser7decoded  (in baseline) + 8,12,...  [0x1047a4170,0x1047a4174,...]
                + 51 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 9312  [0x1047052d8]
                + ! 23 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown12event_parser11EventParserECseVgRDH8534i_19markdown_comparison  (in baseline) + 52  [0x10470227c]
                + ! : 17 _xzm_xzone_free_freelist  (in libsystem_malloc.dylib) + 720  [0x1844edef8]
                + ! : | 16 mach_absolute_time  (in libsystem_kernel.dylib) + 108,16  [0x1846890f8,0x18468909c]
                + ! : | 1 DYLD-STUB$$mach_absolute_time  (in libsystem_malloc.dylib) + 12  [0x18450a8ac]
                + ! : 4 _xzm_xzone_free_freelist  (in libsystem_malloc.dylib) + 348,56,...  [0x1844edd84,0x1844edc60,...]
                + ! : 1 _xzm_free_outlined  (in libsystem_malloc.dylib) + 192  [0x1844ecf6c]
                + ! : 1 _xzm_free_tc  (in libsystem_malloc.dylib) + 32  [0x1844f1898]
                + ! 12 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown13inline_parser12InlineParserECseVgRDH8534i_19markdown_comparison  (in baseline) + 44  [0x10470245c]
                + ! : 7 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | 7 mach_absolute_time  (in libsystem_kernel.dylib) + 108,16  [0x1846890f8,0x18468909c]
                + ! : 2 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 24,268  [0x1844ed69c,0x1844ed790]
                + ! : 2 _xzm_free_tc  (in libsystem_malloc.dylib) + 32,176  [0x1844f1898,0x1844f1928]
                + ! : 1 _free  (in libsystem_malloc.dylib) + 4  [0x1844f5114]
                + ! 9 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown13inline_parser12InlineParserECseVgRDH8534i_19markdown_comparison  (in baseline) + 148  [0x1047024c4]
                + ! : 7 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
                + ! : | 6 mach_absolute_time  (in libsystem_kernel.dylib) + 108,112,...  [0x1846890f8,0x1846890fc,...]
                + ! : | 1 DYLD-STUB$$mach_absolute_time  (in libsystem_malloc.dylib) + 12  [0x18450a8ac]
                + ! : 1 __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 124  [0x1844ed700]
                + ! : 1 _xzm_free_tc  (in libsystem_malloc.dylib) + 260  [0x1844f197c]
                + ! 3 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown13inline_parser12InlineParserECseVgRDH8534i_19markdown_comparison  (in baseline) + 120  [0x1047024a8]
                + ! : 2 DYLD-STUB$$free  (in baseline) + 4  [0x10481f124]
                + ! : 1 _xzm_free_tc  (in libsystem_malloc.dylib) + 312  [0x1844f19b0]
                + ! 2 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown13inline_parser12InlineParserECseVgRDH8534i_19markdown_comparison  (in baseline) + 96  [0x104702490]
                + ! : 1 _xzm_free_tc  (in libsystem_malloc.dylib) + 156  [0x1844f1914]
                + ! : 1 xzm_malloc_zone_try_free_default_tc  (in libsystem_malloc.dylib) + 0  [0x1844f0440]
                + ! 1 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown12event_parser11EventParserECseVgRDH8534i_19markdown_comparison  (in baseline) + 32  [0x104702268]
                + ! 1 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown13inline_parser12InlineParserECseVgRDH8534i_19markdown_comparison  (in baseline) + 68  [0x104702474]
                + !   1 free  (in libsystem_malloc.dylib) + 0  [0x1844b66f0]
                + 13 _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown6stream9EventKindECseVgRDH8534i_19markdown_comparison  (in baseline) + 96  [0x10470263c]
                + 12 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 624  [0x1047030e8]
                + ! 12 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser9separator  (in baseline) + 164,152,...  [0x1047ca9f0,0x1047ca9e4,...]
                + 7 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 2948  [0x1047039fc]
                + ! 4 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser5value  (in baseline) + 216  [0x1047ca84c]
                + ! : 4 _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in baseline) + 4,48,...  [0x1047ce5d0,0x1047ce5fc,...]
                + ! 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser5value  (in baseline) + 40,120,...  [0x1047ca79c,0x1047ca7ec,...]
                + 4 _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser7decoded  (in baseline) + 152  [0x1047a4200]
                + 3 _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EECseVgRDH8534i_19markdown_comparison  (in baseline) + 7336  [0x1046ee25c]
                + 3 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 360  [0x104702fe0]
                + ! 3 _platform_memmove  (in libsystem_platform.dylib) + 180,204  [0x1846d7e14,0x1846d7e2c]
                + 3 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 3292  [0x104703b54]
                + ! 2 _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in baseline) + 56,320  [0x1047ceb38,0x1047cec40]
                + ! 1 _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in baseline) + 828  [0x1047ce908]
                + 3 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser17document_boundary  (in baseline) + 172  [0x1048194c4]
                + 2 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 392  [0x104703000]
                + ! 2 _platform_memmove  (in libsystem_platform.dylib) + 180  [0x1846d7e14]
                + 2 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 3244  [0x104703b24]
                + ! 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser5value  (in baseline) + 216  [0x1047ca84c]
                + ! : 1 _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in baseline) + 40  [0x1047ce5f4]
                + ! 1 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser5value  (in baseline) + 40  [0x1047ca79c]
                + 2 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 6304  [0x104704718]
                + ! 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser9separator  (in baseline) + 36,100  [0x1047ca970,0x1047ca9b0]
                + 2 _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline) + 8700  [0x104705074]
                + ! 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser17document_boundary  (in baseline) + 0,16  [0x104819418,0x104819428]
                + 2 _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser5value  (in baseline) + 304  [0x1047ca8a4]
                9 _RNvCseVgRDH8534i_19markdown_comparison4main  (in baseline) + 1348  [0x104706244]
                  8 _RNvMNtCs1coMeGJvsuS_3std4timeNtB2_7Instant7elapsed  (in baseline) + 28  [0x1047e8d9c]
                  ! 8 _RNvMNtNtNtNtCs1coMeGJvsuS_3std3sys3pal4unix4timeNtB2_8Timespec3now  (in baseline) + 24  [0x1047e96bc]
                  !   8 clock_gettime  (in libsystem_c.dylib) + 60  [0x184564100]
                  !     8 clock_gettime_nsec_np  (in libsystem_c.dylib) + 384  [0x1845561ac]
                  !       8 mach_absolute_time  (in libsystem_kernel.dylib) + 108,16  [0x1846890f8,0x18468909c]
                  1 _RNvMNtCs1coMeGJvsuS_3std4timeNtB2_7Instant7elapsed  (in baseline) + 0  [0x1047e8d80]

Total number in stack (recursive counted multiple, when >=5):
        9       _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline) + 0  [0x1047b55b8]
        9       _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline) + 0  [0x1047b655c]
        9       _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline) + 0  [0x1047d1304]
        8       _xzm_free  (in libsystem_malloc.dylib) + 0  [0x1844ec700]
        8       mach_absolute_time  (in libsystem_kernel.dylib) + 0  [0x18468908c]
        8       xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 0  [0x1844e5010]
        7       _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 0  [0x104819368]
        7       _platform_memmove  (in libsystem_platform.dylib) + 0  [0x1846d7d60]
        6       _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 92  [0x1048193c4]
        6       __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib) + 424  [0x1844ed82c]
        6       _malloc_zone_realloc  (in libsystem_malloc.dylib) + 148  [0x1844f4b2c]
        6       _realloc  (in libsystem_malloc.dylib) + 0  [0x1844f5190]
        6       _realloc  (in libsystem_malloc.dylib) + 252  [0x1844f528c]
        6       _realloc  (in libsystem_malloc.dylib) + 456  [0x1844f5358]
        6       _xzm_free_tc  (in libsystem_malloc.dylib) + 0  [0x1844f1878]
        6       _xzm_malloc_tc  (in libsystem_malloc.dylib) + 0  [0x1844ef990]
        6       xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 1028  [0x1844e5414]
        6       xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 896  [0x1844e5390]
        6       xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib) + 996  [0x1844e53f4]
        6       xzm_malloc_zone_size  (in libsystem_malloc.dylib) + 0  [0x1844e4304]
        5       _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in baseline) + 0  [0x1047ce5cc]
        5       _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline) + 0  [0x1047d09f0]
        5       _RNvMs4_NtCs3vUkWdPtNor_5alloc7raw_vecINtB5_6RawVecNtNtCs8seiryzelau_13core_markdown12block_parser4CodeE8grow_oneBQ_  (in baseline) + 60  [0x104819084]
        5       _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline) + 120  [0x1048193e0]
        5       _malloc_zone_realloc  (in libsystem_malloc.dylib) + 0  [0x1844f4a98]
        5       _xzm_malloc  (in libsystem_malloc.dylib) + 0  [0x1844e7df4]
        5       _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib) + 0  [0x1844e8a4c]

Sort by top of stack, same collapsed (when >= 5):
        _RNvNtCs8seiryzelau_13core_markdown13inline_parser8resource  (in baseline)        525
        _RNCNvCseVgRDH8534i_19markdown_comparison8renderers_0B3_  (in baseline)        454
        _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser7prepareKb0_Kb1_INtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNCNvMs0_NtB7_12event_parserNtB2s_11EventParser10next_event00EECseVgRDH8534i_19markdown_comparison  (in baseline)        218
        _RNvMs_NtCs8seiryzelau_13core_markdown12block_parserNtB4_6Blocks5parse  (in baseline)        181
        _RINvNtCs9nEiEE0E2Vj_4core3ptr9drop_glueNtNtCs8seiryzelau_13core_markdown6stream9EventKindECseVgRDH8534i_19markdown_comparison  (in baseline)        146
        mach_absolute_time  (in libsystem_kernel.dylib)        90
        _RNvNtCs8seiryzelau_13core_markdown13value_builder6decode  (in baseline)        89
        _RNvNtNtCs8seiryzelau_13core_markdown12block_parser8scanners13scan_nextline  (in baseline)        89
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10containers  (in baseline)        88
        _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser6append  (in baseline)        86
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder6append  (in baseline)        63
        _platform_memmove  (in libsystem_platform.dylib)        47
        xzm_malloc_zone_malloc_type_realloc  (in libsystem_malloc.dylib)        34
        _RNvMNtCs8seiryzelau_13core_markdown13value_builderNtB2_12ValueBuilder6append  (in baseline)        26
        _xzm_free  (in libsystem_malloc.dylib)        26
        _RINvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB5_12InlineParser9attentionKb1_ECseVgRDH8534i_19markdown_comparison  (in baseline)        24
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder15table_delimiter  (in baseline)        18
        _RINvNtNtCs8seiryzelau_13core_markdown12block_parser10definition4scanINtNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fn6FromFnNCNvMs0_B4_NtB4_7Builder20definition_fragments0EEB6_  (in baseline)        16
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder11finish_list  (in baseline)        14
        _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser9separator  (in baseline)        14
        _RNvNtCsglYb6d7nGNF_6memchr6memmem4find  (in baseline)        14
        _xzm_xzone_malloc_tiny  (in libsystem_malloc.dylib)        14
        xzm_malloc_zone_size  (in libsystem_malloc.dylib)        14
        _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser18suppress_autolinks  (in baseline)        12
        __xzm_xzone_free_to_freelist_chunk  (in libsystem_malloc.dylib)        12
        _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart28scan_list_marker_with_indent  (in baseline)        10
        _RNvMs5_NtCs3vUkWdPtNor_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs8seiryzelau_13core_markdown  (in baseline)        10
        _realloc  (in libsystem_malloc.dylib)        10
        _xzm_malloc_tc  (in libsystem_malloc.dylib)        10
        _RNvMs_NtCs8seiryzelau_13core_markdown13inline_parserNtB4_12InlineParser7decoded  (in baseline)        9
        _malloc_zone_realloc  (in libsystem_malloc.dylib)        9
        _RNvMNtNtCs8seiryzelau_13core_markdown12block_parser8scannersNtB2_9LineStart18finish_list_marker  (in baseline)        8
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10interrupts  (in baseline)        8
        _xzm_free_tc  (in libsystem_malloc.dylib)        8
        _xzm_malloc  (in libsystem_malloc.dylib)        8
        _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser5value  (in baseline)        6
        _RNvCsjVqd8RsBhQu_7___rustc35___rust_no_alloc_shim_is_unstable_v2  (in baseline)        5
        _RNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB5_7Builder10table_head  (in baseline)        5
        _RNvMs0_NtCs8seiryzelau_13core_markdown12event_parserNtB5_11EventParser17document_boundary  (in baseline)        5
        _RNvNtNtCs8seiryzelau_13core_markdown13inline_parser8autolink3web  (in baseline)        5
        _RNvXNtNtNtCs9nEiEE0E2Vj_4core4iter7sources7from_fnINtB2_6FromFnNCNvMs0_NtCs8seiryzelau_13core_markdown12block_parserNtB17_7Builder20definition_fragments0ENtNtNtB6_6traits8iterator8Iterator4nextB19_  (in baseline)        5

Binary Images:
       0x1046e4000 -        0x1048aa66f +baseline (0) <769F5531-DB9E-306E-999A-643EE6A203C3> /tmp/*/baseline
       0x184244000 -        0x1842935f7  libobjc.A.dylib (973.1) <C0680DF6-9900-3C29-A071-95A031686EF8> /usr/lib/libobjc.A.dylib
       0x184294000 -        0x18429e23f  libsharedcache.dylib (0) <BBF95357-BEBF-3D89-8900-2BBB14A667C5> /usr/lib/libsharedcache.dylib
       0x18429f000 -        0x1842c5d3b  libdyld.dylib (27062) <62863BCA-DD60-3D32-A9DB-89099BA6F3D7> /usr/lib/system/libdyld.dylib
       0x1842c6000 -        0x1843856e3  dyld (1.0.0 - 27062) <D341DDCB-7969-3A9C-8E03-0CF4751398A9> /usr/lib/dyld
       0x184386000 -        0x18438901f  libsystem_blocks.dylib (98.1) <6F304731-D95D-3501-B4AD-F2934F7F2446> /usr/lib/system/libsystem_blocks.dylib
       0x18438a000 -        0x1843df0df  libxpc.dylib (3298.1.1) <0791121F-B5FC-3F84-BF04-115E86D2D882> /usr/lib/system/libxpc.dylib
       0x1843e0000 -        0x1843ffc13  libsystem_trace.dylib (1966.1.1) <B48A8E3E-A12A-3342-8321-428B555E965E> /usr/lib/system/libsystem_trace.dylib
       0x184400000 -        0x1844b4f27  libcorecrypto.dylib (2109.0.22) <807AA6C9-5D8A-3CA5-B4CE-FACE5296EF6A> /usr/lib/system/libcorecrypto.dylib
       0x1844b5000 -        0x18450ac5f  libsystem_malloc.dylib (886.0.8) <2339CB57-FE5A-3154-A206-A76059C749EB> /usr/lib/system/libsystem_malloc.dylib
       0x18450b000 -        0x18455119f  libdispatch.dylib (1605.0.2) <022BF08F-0B3A-3225-9E65-16D1553CE90D> /usr/lib/system/libdispatch.dylib
       0x184552000 -        0x184554d2b  libsystem_featureflags.dylib (108) <20C1CAB2-1F13-3426-8146-9CAE9FF2A33D> /usr/lib/system/libsystem_featureflags.dylib
       0x184555000 -        0x1845d7ca3  libsystem_c.dylib (1786.0.3) <FBA7B23E-AA60-3A90-9AA4-A7A2E0AD63EE> /usr/lib/system/libsystem_c.dylib
       0x1845d8000 -        0x18466d033  libc++.1.dylib (2200.27) <1E9BA4AA-B5DA-3CF3-80AC-4B880049573F> /usr/lib/libc++.1.dylib
       0x18466e000 -        0x184687eff  libc++abi.dylib (2200.27) <A21743EE-6E1C-3E74-97EA-7AF793DE4BDF> /usr/lib/libc++abi.dylib
       0x184688000 -        0x1846c69ab  libsystem_kernel.dylib (13432.1.9) <F63BF418-8F75-34A4-AAF1-8CAF2B9B6A05> /usr/lib/system/libsystem_kernel.dylib
       0x1846c7000 -        0x1846d391b  libsystem_pthread.dylib (553.0.1) <5A1828C3-CBC2-3B85-BD07-C8ED10021A41> /usr/lib/system/libsystem_pthread.dylib
       0x1846d4000 -        0x1846dd4f3  libsystem_platform.dylib (402.0.1.0.1) <080E4444-A0FB-3913-9756-4E470015F32F> /usr/lib/system/libsystem_platform.dylib
       0x1846de000 -        0x18470c903  libsystem_info.dylib (603) <BC387AEB-1CEF-3513-92D7-D7F913596711> /usr/lib/system/libsystem_info.dylib
       0x188836000 -        0x18883fb13  libsystem_darwin.dylib (1786.0.3) <4E66C888-993C-3E6A-A8DA-A949C01C5B67> /usr/lib/system/libsystem_darwin.dylib
       0x188c90000 -        0x188ca1b8b  libsystem_notify.dylib (368) <58FD36D8-37A7-311C-80F2-8E64DD8710CF> /usr/lib/system/libsystem_notify.dylib
       0x18aded000 -        0x18ae07d93  libsystem_networkextension.dylib (2340.1.2) <22E1D190-486F-324F-ABA4-F36AB841BFE9> /usr/lib/system/libsystem_networkextension.dylib
       0x18ae95000 -        0x18aeac247  libsystem_asl.dylib (409) <B4D449B7-A821-3A9A-8019-E917B291F10A> /usr/lib/system/libsystem_asl.dylib
       0x18be40000 -        0x18be40f2f  libobjcMsgSend.dylib (973.1) <41179EDE-DC97-3BBE-8848-6400D12C1436> /usr/lib/objc/libobjcMsgSend.dylib
       0x18cf8c000 -        0x18cf93edf  libsystem_symptoms.dylib (2394.0.4) <60EE7884-9F4E-3184-A6AC-FA40A7A0297D> /usr/lib/system/libsystem_symptoms.dylib
       0x191324000 -        0x19135eaeb  libsystem_containermanager.dylib (833.0.8.0.1) <08A57205-555D-3792-8931-9D5B585AF326> /usr/lib/system/libsystem_containermanager.dylib
       0x192977000 -        0x19297b317  libsystem_configuration.dylib (1446) <F3EB66A7-7A24-3AE5-B6E8-9A37BB00F119> /usr/lib/system/libsystem_configuration.dylib
       0x19297c000 -        0x192982e03  libsystem_sandbox.dylib (3051.0.52) <1E892B56-092E-3832-BDE3-DCE356D7A4FA> /usr/lib/system/libsystem_sandbox.dylib
       0x193e40000 -        0x193e40f2f  libobjcMsgSend1.dylib (973.1) <B40D9B2A-E1EE-37ED-8004-711A1F263DE1> /usr/lib/objc/libobjcMsgSend1.dylib
       0x194560000 -        0x194562f93  libquarantine.dylib (217.0.4) <7FD4AE22-86EF-382B-83F5-ADF9336C1160> /usr/lib/system/libquarantine.dylib
       0x194c72000 -        0x194c781e7  libsystem_coreservices.dylib (203) <57248E07-11A5-3857-918E-4A3A63B69FE8> /usr/lib/system/libsystem_coreservices.dylib
       0x19523a000 -        0x195277b27  libsystem_m.dylib (3326.0.1) <A3FB340F-3ED5-30F4-8B64-9D5860F64D35> /usr/lib/system/libsystem_m.dylib
       0x195279000 -        0x19527c4f7  libmacho.dylib (27062) <50DEADEC-3E99-3519-AFC3-4A3FEB3F14C3> /usr/lib/system/libmacho.dylib
       0x195296000 -        0x1952a2707  libcommonCrypto.dylib (600041) <41C99F45-C5E6-39DB-B1F2-A1BEA9D242A4> /usr/lib/system/libcommonCrypto.dylib
       0x1952a3000 -        0x1952acc87  libunwind.dylib (2200.5) <3070AB81-B082-39E8-8A00-EF88DDE9AC47> /usr/lib/system/libunwind.dylib
       0x1952b4000 -        0x1952be7eb  libcopyfile.dylib (260.0.3) <72D95AF9-BF5E-3A84-81A6-BCC5BDB99857> /usr/lib/system/libcopyfile.dylib
       0x1952bf000 -        0x1952c28bf  libcompiler_rt.dylib (103.4) <DFB5CE7F-A36E-36AA-BECE-1392D3D43607> /usr/lib/system/libcompiler_rt.dylib
       0x1952c3000 -        0x1952c8077  libsystem_collections.dylib (1786.0.3) <1E8022D4-5A37-3A7A-8936-603E6FA88358> /usr/lib/system/libsystem_collections.dylib
       0x1952c9000 -        0x1952cbf1f  libsystem_secinit.dylib (182) <DE037464-4C5D-3E96-A33F-2A4557CC6A20> /usr/lib/system/libsystem_secinit.dylib
       0x1952cc000 -        0x1952ce97f  libremovefile.dylib (96) <E6E6DFCF-6B2C-3F30-A59D-816CAB1190CE> /usr/lib/system/libremovefile.dylib
       0x1952cf000 -        0x1952cfe27  libkeymgr.dylib (31) <5EC997EF-3ADA-360B-9FCD-5F940C83FA4E> /usr/lib/system/libkeymgr.dylib
       0x1952d0000 -        0x1952d8af7  libsystem_dnssd.dylib (3111.0.5.0.1) <DE22096F-1E5B-3D6E-8164-771582DD6391> /usr/lib/system/libsystem_dnssd.dylib
       0x1952d9000 -        0x1952ddf1b  libcache.dylib (95) <80BAE197-E285-3F6E-A1EE-B77FE37D7E5D> /usr/lib/system/libcache.dylib
       0x1952de000 -        0x1952df8f3  libSystem.B.dylib (1359) <4FDC9AA6-B344-37FE-B8C6-A4C94A038F57> /usr/lib/libSystem.B.dylib
       0x19be40000 -        0x19be40f2f  libobjcMsgSend2.dylib (973.1) <BD27A84B-C9AE-3282-BBEA-3B6119837B5A> /usr/lib/objc/libobjcMsgSend2.dylib
       0x1a3e40000 -        0x1a3e40f2f  libobjcMsgSend3.dylib (973.1) <C0860D68-DDFC-3BD7-8B06-DB0645CBBED4> /usr/lib/objc/libobjcMsgSend3.dylib
       0x1abe40000 -        0x1abe40f2f  libobjcMsgSend4.dylib (973.1) <A6153BF5-622B-3B01-81B6-F64A365EF613> /usr/lib/objc/libobjcMsgSend4.dylib
       0x1b3e40000 -        0x1b3e40f2f  libobjcMsgSend5.dylib (973.1) <3913A71C-B29A-3AEA-820B-BEC40AC1861A> /usr/lib/objc/libobjcMsgSend5.dylib
       0x1bbe40000 -        0x1bbe40f2f  libobjcMsgSend6.dylib (973.1) <9BC523A3-E167-3F6C-8CAE-0F3EBA671791> /usr/lib/objc/libobjcMsgSend6.dylib
       0x1c3e40000 -        0x1c3e40f2f  libobjcMsgSend7.dylib (973.1) <248B7BCE-5B4C-34C7-A340-43D5228628C5> /usr/lib/objc/libobjcMsgSend7.dylib
       0x1cbe40000 -        0x1cbe40f2f  libobjcMsgSend8.dylib (973.1) <3E041BAD-A8E8-3069-B741-78CD1A45B176> /usr/lib/objc/libobjcMsgSend8.dylib
       0x1d3e40000 -        0x1d3e40f2f  libobjcMsgSend9.dylib (973.1) <34A67969-21A0-39D6-BB81-8FDA5A2409DB> /usr/lib/objc/libobjcMsgSend9.dylib
       0x1dbe40000 -        0x1dbe40f2f  libobjcMsgSend10.dylib (973.1) <678186C0-8EAD-3B35-8CBB-00285B41E4A0> /usr/lib/objc/libobjcMsgSend10.dylib
       0x1e3e40000 -        0x1e3e40f2f  libobjcMsgSend11.dylib (973.1) <E05CB08C-E956-36FA-8967-AE8E346A8D2C> /usr/lib/objc/libobjcMsgSend11.dylib
       0x20be40000 -        0x20be40f2f  libobjcMsgSend12.dylib (973.1) <10AB03AA-FF1F-3FDC-9DFB-BFC40042C501> /usr/lib/objc/libobjcMsgSend12.dylib
       0x213e40000 -        0x213e40f2f  libobjcMsgSend13.dylib (973.1) <ABF53427-FA6F-3D0D-8F9D-7AD795CA5C92> /usr/lib/objc/libobjcMsgSend13.dylib
       0x21be40000 -        0x21be40f2f  libobjcMsgSend14.dylib (973.1) <9A844C46-A6DA-34D4-8EBF-2AD775C30684> /usr/lib/objc/libobjcMsgSend14.dylib
       0x223e40000 -        0x223e40f2f  libobjcMsgSend15.dylib (973.1) <7C995666-2B2D-3284-AA0A-EBF7C922838E> /usr/lib/objc/libobjcMsgSend15.dylib
       0x22be40000 -        0x22be40f2f  libobjcMsgSend16.dylib (973.1) <B6C0E14B-53AE-3E22-9ED5-1729C49F46F2> /usr/lib/objc/libobjcMsgSend16.dylib
       0x233e40000 -        0x233e40f2f  libobjcMsgSend17.dylib (973.1) <07B4CF85-251B-301B-832B-20B315A59E19> /usr/lib/objc/libobjcMsgSend17.dylib
       0x23be40000 -        0x23be40f2f  libobjcMsgSend18.dylib (973.1) <43E575B7-04DB-3999-A633-1A3B638BA6E3> /usr/lib/objc/libobjcMsgSend18.dylib
       0x243e40000 -        0x243e40f2f  libobjcMsgSend19.dylib (973.1) <736F4D85-76F7-3B28-8D87-C07E8F7A0EF4> /usr/lib/objc/libobjcMsgSend19.dylib
       0x24be40000 -        0x24be40f2f  libobjcMsgSend20.dylib (973.1) <74E67C8B-6BCA-3184-A18E-A97F370052C6> /usr/lib/objc/libobjcMsgSend20.dylib
       0x253e40000 -        0x253e40f2f  libobjcMsgSend21.dylib (973.1) <CC0D732F-98E7-3888-9E15-70984DA2FB04> /usr/lib/objc/libobjcMsgSend21.dylib
       0x25be40000 -        0x25be40f2f  libobjcMsgSend22.dylib (973.1) <85A60286-5DE3-32BA-B18C-2A498B065C88> /usr/lib/objc/libobjcMsgSend22.dylib
       0x263e40000 -        0x263e40f2f  libobjcMsgSend23.dylib (973.1) <5452A0D2-6B19-39BE-ADDD-80B7BCDE3A98> /usr/lib/objc/libobjcMsgSend23.dylib
       0x26be40000 -        0x26be40f2f  libobjcMsgSend24.dylib (973.1) <94BBF2D6-722B-350D-8557-4D25A8E8D53A> /usr/lib/objc/libobjcMsgSend24.dylib
       0x273e40000 -        0x273e40f2f  libobjcMsgSend25.dylib (973.1) <35481387-5A8E-3AE4-86A6-94CEB3CC8726> /usr/lib/objc/libobjcMsgSend25.dylib
       0x28be40000 -        0x28be40f2f  libobjcMsgSend26.dylib (973.1) <9E0C8664-E7F4-39D1-AAFC-BD92B255E4E8> /usr/lib/objc/libobjcMsgSend26.dylib
       0x293e40000 -        0x293e40f2f  libobjcMsgSend27.dylib (973.1) <FD424935-55A9-3650-955A-EED3441A1D19> /usr/lib/objc/libobjcMsgSend27.dylib
       0x29be40000 -        0x29be40f2f  libobjcMsgSend28.dylib (973.1) <09BA7B97-7DF7-3C7F-932A-B6847662FC49> /usr/lib/objc/libobjcMsgSend28.dylib
       0x2a3e40000 -        0x2a3e40f2f  libobjcMsgSend29.dylib (973.1) <36D5BA3F-2139-30B0-8558-556764BE9813> /usr/lib/objc/libobjcMsgSend29.dylib
       0x2abe40000 -        0x2abe40f2f  libobjcMsgSend30.dylib (973.1) <9F05564A-9D12-372C-98FC-E9F0E6BE4F04> /usr/lib/objc/libobjcMsgSend30.dylib
       0x2b0b5a000 -        0x2b0b60fe5  libRosetta.dylib (385) <E359944B-D230-33F9-A04E-0C3B17C3326E> /usr/lib/libRosetta.dylib
       0x2b1549000 -        0x2b154c75b  libsystem_darwindirectory.dylib (129.0.1) <61264923-2AA5-3658-B8C4-550C71E9D4B3> /usr/lib/system/libsystem_darwindirectory.dylib
       0x2b154d000 -        0x2b1557d9b  libsystem_eligibility.dylib (446.1.3) <EDDE8E9C-A2CF-3931-BBB3-321CB852EB30> /usr/lib/system/libsystem_eligibility.dylib
       0x2b1558000 -        0x2b156142b  libsystem_sanitizers.dylib (32) <7138ED99-7AA0-34EA-B35B-20EF6ADB1EED> /usr/lib/system/libsystem_sanitizers.dylib
       0x2b1562000 -        0x2b1562a13  libsystem_trial.dylib (511) <6AE48824-EC44-3A8C-B501-BE57DBE892E7> /usr/lib/system/libsystem_trial.dylib
       0x2b3e40000 -        0x2b3e40f2f  libobjcMsgSend31.dylib (973.1) <0985E20F-78C3-3466-A2B2-DBB95F7104A3> /usr/lib/objc/libobjcMsgSend31.dylib
       0x2bbe40000 -        0x2bbe40f2f  libobjcMsgSend32.dylib (973.1) <0D309D58-D576-3E5D-AD4B-6D55AB491702> /usr/lib/objc/libobjcMsgSend32.dylib
       0x2c3e40000 -        0x2c3e40f2f  libobjcMsgSend33.dylib (973.1) <346E0484-48FA-369B-8A64-93B5F5341CFE> /usr/lib/objc/libobjcMsgSend33.dylib
       0x2cbe40000 -        0x2cbe40f2f  libobjcMsgSend34.dylib (973.1) <6A31F809-BCBE-3E01-A367-E91FDACCE324> /usr/lib/objc/libobjcMsgSend34.dylib
